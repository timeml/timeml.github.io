
$task_ab_dir = "taskAB";
$task_a_dir = "taskA";
$task_b_dir = "taskB";

opendir DIR, "taskAB" or die;

@files = grep /tml$/, readdir DIR;

foreach $file (@files) {
    open IN, "$task_ab_dir/$file" or die; 
    open OUT_A, ">  $task_a_dir/$file" or die;
    open OUT_B, ">  $task_b_dir/$file" or die;
    print "$file\n";
    while (<IN>) {
        if (/^<TLINK .* task="A"\/>/) {
            print OUT_A;
        } elsif (/^<TLINK .* task="B"\/>/) {
            print OUT_B;
        } else {
            print OUT_A;
            print OUT_B;
        }
    }
}

