echo "# -------------------------------------------------------------------------"
echo "# results for 15.CU-TMP"
echo "# -------------------------------------------------------------------------"
echo

perl scoreTLINKS.pl -s ../../participants/15.CU-TMP/taskA ../data/taskA
perl scoreTLINKS.pl -r ../../participants/15.CU-TMP/taskA ../data/taskA
perl scoreTLINKS.pl -s ../../participants/15.CU-TMP/taskB ../data/taskB
perl scoreTLINKS.pl -r ../../participants/15.CU-TMP/taskB ../data/taskB
perl scoreTLINKS.pl -s ../../participants/15.CU-TMP/taskC ../data/taskC
perl scoreTLINKS.pl -r ../../participants/15.CU-TMP/taskC ../data/taskC


echo "# -------------------------------------------------------------------------"
echo "# results for 15.LCC-TE-15.ResultsFromLCC"
echo "# -------------------------------------------------------------------------"
echo

perl scoreTLINKS.pl -s ../../participants/15.LCC-TE-15.ResultsFromLCC/taskA ../data/taskA
perl scoreTLINKS.pl -r ../../participants/15.LCC-TE-15.ResultsFromLCC/taskA ../data/taskA
perl scoreTLINKS.pl -s ../../participants/15.LCC-TE-15.ResultsFromLCC/taskB ../data/taskB
perl scoreTLINKS.pl -r ../../participants/15.LCC-TE-15.ResultsFromLCC/taskB ../data/taskB
perl scoreTLINKS.pl -s ../../participants/15.LCC-TE-15.ResultsFromLCC/taskC ../data/taskC
perl scoreTLINKS.pl -r ../../participants/15.LCC-TE-15.ResultsFromLCC/taskC ../data/taskC


echo "# -------------------------------------------------------------------------"
echo "# results for 15.NAIST.japan-15"
echo "# -------------------------------------------------------------------------"
echo

perl scoreTLINKS.pl -s ../../participants/15.NAIST.japan-15/taskA ../data/taskA
perl scoreTLINKS.pl -r ../../participants/15.NAIST.japan-15/taskA ../data/taskA
perl scoreTLINKS.pl -s ../../participants/15.NAIST.japan-15/taskB ../data/taskB
perl scoreTLINKS.pl -r ../../participants/15.NAIST.japan-15/taskB ../data/taskB
perl scoreTLINKS.pl -s ../../participants/15.NAIST.japan-15/taskC ../data/taskC
perl scoreTLINKS.pl -r ../../participants/15.NAIST.japan-15/taskC ../data/taskC


echo "# -------------------------------------------------------------------------"
echo "# results for 15.TimeBandits-15.USFD_results"
echo "# -------------------------------------------------------------------------"
echo

perl scoreTLINKS.pl -s ../../participants/15.TimeBandits-15.USFD_results/taskA ../data/taskA
perl scoreTLINKS.pl -r ../../participants/15.TimeBandits-15.USFD_results/taskA ../data/taskA
perl scoreTLINKS.pl -s ../../participants/15.TimeBandits-15.USFD_results/taskB ../data/taskB
perl scoreTLINKS.pl -r ../../participants/15.TimeBandits-15.USFD_results/taskB ../data/taskB
perl scoreTLINKS.pl -s ../../participants/15.TimeBandits-15.USFD_results/taskC ../data/taskC
perl scoreTLINKS.pl -r ../../participants/15.TimeBandits-15.USFD_results/taskC ../data/taskC


echo "# -------------------------------------------------------------------------"
echo "# results for 15.WVALI"
echo "# -------------------------------------------------------------------------"
echo

perl scoreTLINKS.pl -s ../../participants/15.WVALI/taskA ../data/taskA
perl scoreTLINKS.pl -r ../../participants/15.WVALI/taskA ../data/taskA
perl scoreTLINKS.pl -s ../../participants/15.WVALI/taskB ../data/taskB
perl scoreTLINKS.pl -r ../../participants/15.WVALI/taskB ../data/taskB
perl scoreTLINKS.pl -s ../../participants/15.WVALI/taskC ../data/taskC
perl scoreTLINKS.pl -r ../../participants/15.WVALI/taskC ../data/taskC


echo "# -------------------------------------------------------------------------"
echo "# results for 15.XRCE-T-15.XRCE-T-15"
echo "# -------------------------------------------------------------------------"
echo

perl scoreTLINKS.pl -s ../../participants/15.XRCE-T-15.XRCE-T-15/taskA ../data/taskA
perl scoreTLINKS.pl -r ../../participants/15.XRCE-T-15.XRCE-T-15/taskA ../data/taskA
perl scoreTLINKS.pl -s ../../participants/15.XRCE-T-15.XRCE-T-15/taskB ../data/taskB
perl scoreTLINKS.pl -r ../../participants/15.XRCE-T-15.XRCE-T-15/taskB ../data/taskB
perl scoreTLINKS.pl -s ../../participants/15.XRCE-T-15.XRCE-T-15/taskC ../data/taskC
perl scoreTLINKS.pl -r ../../participants/15.XRCE-T-15.XRCE-T-15/taskC ../data/taskC


