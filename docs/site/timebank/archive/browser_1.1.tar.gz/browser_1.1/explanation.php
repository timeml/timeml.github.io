<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?php readfile("topnav.php"); ?>

<h2>TimeBank 1.1 Browser - Huh?</h2>
<p>TimeBank can currently be browsed in the following ways:</p>
<ol>
  <li>View the <a href="displayArticles.php">list
  of articles</a>. Each article
  can be viewed. All events, timexes and signals are displayed. The events, timexes
  and signals
    in the document
    are clickable (as long as you have Javascipt enabled). Clicking one of those
  tags leads you to an exhaustive list of occurrence for the instance. From the
  article view, you can launch another window with all links for the article.
  Click a
  link
  in that new window and see it highlighted in the article view.</li>
  <li>View the list of <a href="displayTags.php?tagtype=event">events</a>. Events
    can be sorted alphabetically or on frequency. For each event, all sentences
    in which it occurs can be retrieved, and for each
    occurrence
    it is possible to see the wider
    context (that is, the whole article, the events will be highlighted).</li>
  <li>View the list of <a href="displayTags.php?tagtype=timex">timexes</a>. This
    is similar to viewing the events</li>
  <li>View the list of <a href="displayTags.php?tagtype=signal">signals</a>. This is similar to viewing the events.</li>
  <li>View all <a href="slinks/index.html">SLinks</a>. The SLinks are indexed
    by their governing event and are presented in their local context, there
    is also a link to the article in which the SLink occurs.</li>
  <li>Search for <a href="findAlinks.php">ALinks</a>, <a href="findSlinks.php">SLinks</a> or <a href="findTlinks.php">TLinks</a>.
    Search parameters are relation type of link and the tokens of the two related
    elements. Events can also be restricted for class, tense, and aspect values,
    timexes can be restricted for type and value. The search will never return
    more than 250 matches (scrolling result pages need to be added).</li>
</ol>
<p>There is also a page with <a href="tb_statistics.html">general statistics</a>.</p>
<p>The lists of articles and events are dynamic and taken from the database.
  The SLinks list is static html but quite recent (that is, updated for TimeBank
  1.1 version
  20040212).
  The
  statistics
  page is also static html, but created by a perl script that queries the database.  </p>
<p>Some functionality that may be added: (i) dynamic pages for
  SLink browser, (ii)
  regular KWIC displays, (iii) display links from
    and
    to an event
    or timex, (iv) incorporate Tango browser as an applet, and (v) sorting  of
  link tables.</p>
<p>The version of TimeBank in the database is TimeBank 1.1 version 20040212,
  with only a few modifications:</p>
<ol>
  <li>Three articles were ignored, they broke the perl extraction scripts.</li>
  <li>Some &lt;s&gt; tags were added inside &lt;leadpara&gt;, &lt;lp&gt; and &lt;headline&gt; tags,
    these contained many events and the scripts only extracted TimeML tags from
    sentences.</li>
  <li>A few dozen duplicate links were ignored.</li>
  <li>A dozen TLinks were skipped because they were incomplete.</li>
  <li>All data outside of &lt;s&gt; tags, except for timexes in the document head,
    are ignored.</li>
</ol>
<p>Marc Verhagen, 2004/02/25</p>
</body>
</html>
