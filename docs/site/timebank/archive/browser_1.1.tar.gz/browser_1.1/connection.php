<?php
$hostname = "69.5.6.130";
$hostname = "MySQL.timeml.org";
$db = 'xtimeml';
$username = 'xtimeml'; 
$password = "store4time";
?>