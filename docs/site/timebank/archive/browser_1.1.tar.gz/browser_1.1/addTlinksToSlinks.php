<?php

// Connect and select
$db_conn = mysql_connect('localhost','banzai','get!stuffed?');
mysql_select_db('banzai_timebank', $db_conn);
if (mysql_errno()) { echo mysql_errno() . ": " . mysql_error(). "\n<p><hr><p>\n\n"; }

// get next slink where checked is not equal to 'no'
function selectNextSLink() {
	global $db_conn;
	$query = "SELECT * FROM slinksGen WHERE checked = 'no' limit 0,1";
	$result = mysql_query($query, $db_conn);
	if (mysql_errno()) {
		printMySqlErrors($query,"addTlinksToSlinks.php:13"); }
	else {
	  // may want to add a check whether there was a row
	  $row = mysql_fetch_assoc($result);
	  return $row; }}

function getSentenceID($file,$eid) {
	global $db_conn;
	$query = "SELECT sentid FROM events WHERE tmlfile = '$file' AND eid = '$eid'";
	$result = mysql_query($query, $db_conn);
	if (mysql_errno()) {
		printMySqlErrors($query,$_SERVER['SCRIPT_NAME'] . ":" . __LINE__); }
	else {
	  $row = mysql_fetch_assoc($result);
	  return $row['sentid']; }}

// debug utility
function printMySqlErrors($query,$caller) {
	if (mysql_errno()) {
    	echo 'MySQL Error:' . mysql_errno() . ": " . mysql_error(). "\n";
		echo "<p>Query: $query<p>Caller: $caller<p><hr><p>\n\n"; }}

// Two functions taken from utils.php, but with minor changes:
//    echoSentence: added capability of dealing with an array of ids
//    echoSentenceRows: remove clickability of events and timexes

function echoSentence ($file,$sentid,$ids) 
{
  global $db_conn;
  $query = "select * from sentences where tmlfile='$file' and sentid='$sentid' order by sentid, offset";
  $result = mysql_query($query, $db_conn);
  if (mysql_errno()) {
	printMySqlErrors($query,"echoSentence($file,$sentid,$id)"); }
  else {
    $rows = Array();
	while ($row = mysql_fetch_row($result)) {
	  $rows[] = $row; }}
  $ar = Array();
  foreach ($ids as $id) {
	$ar[$id] = 1; }
  echoSentenceRows($rows,$ar,'');
}

function echoSentenceRows ($rows, $highlightIDs, $sep) 
{
  $printID = 1;
  foreach ($rows as $row) { 
	if ($row[2] == 0) { echo "\n$sep\n"; $printID = 1; }
	// strip the | from the varchar field
	$text = substr($row[3],0,-1);
	$tag = $row[4];
	$id = $row[5];
	if ($printID) {
	  $sentid = $row[1];
	  echo "$sentid: ";
	  $printID = 0; }
	$highlight = $highlightIDs[$id];
	if ($tag) {
	  echo "<span id=$id>";
	  if ($tag == 'EVENT') { echo "<span class=event>"; } 
	  elseif ($tag == 'TIMEX3') { echo "<span class=timex>"; } 
	  else  { echo " <span class=signal>"; }
	  if ($highlight) { echo '<strong>'; }
	  if ($id{0} == 'e') { $tagtype = 'event'; }
	  elseif ($id{0} == 't') { $tagtype = 'timex'; }
	  elseif ($id{0} == 's') { $tagtype = 'signal'; }
	  echo $text;
	  if ($highlight) { echo '</strong>'; }
	  echo '</span><sup>'.$id.'</sup>'; 
	  echo "</span>";
	}
	else {
	  echo $text; }
  }
}

// Also from utils.php
function allRowsForDocument($doc) {
	global $db_conn;
	$query = "SELECT * FROM sentences WHERE tmlfile = '$doc' order by sentid, offset";
	$result = mysql_query($query, $db_conn);
	if (mysql_errno()) {
		printMySqlErrors($query,"displayArticle.php:10"); }
	else {
		while ($row = mysql_fetch_row($result)) {
			$rows[] = $row; }}
	return $rows; }


function filterRows($rows,$sentid) {
  $context = 5;
  $filteredRows = Array();
  foreach ($rows as $row) {
	if ($row[1] < $sentid + $context && $row[1] > $sentid - $context  ) {
	  $filteredRows[] = $row; }}
  return $filteredRows; }




// get data of previous slink
$file = $HTTP_GET_VARS['tmlfile'];
$eiid1 = $HTTP_GET_VARS['eiid1'];
$eiid2 = $HTTP_GET_VARS['eiid2'];

// wrong slink
if ($HTTP_GET_VARS['checked'] == 'wrong') {
  $qu = "UPDATE slinksGen SET checked='wrong' WHERE tmlfile='$file' AND eiid1='$eiid1' AND eiid2='$eiid2' LIMIT 1";
  mysql_query($qu, $db_conn);  
  if (mysql_errno()) {
	printMySqlErrors($query,$_SERVER['SCRIPT_NAME'] . ":" . __LINE__); }}

// skip slink
if ($HTTP_GET_VARS['checked'] == 'skip') {
  $qu = "UPDATE slinksGen SET checked='skip' WHERE tmlfile='$file' AND eiid1='$eiid1' AND eiid2='$eiid2' LIMIT 1";
  mysql_query($qu, $db_conn);  
  if (mysql_errno()) {
	printMySqlErrors($query,$_SERVER['SCRIPT_NAME'] . ":" . __LINE__); }}

// add tlink
if ($HTTP_GET_VARS['checked'] == 'ok') {
  $tlink = $HTTP_GET_VARS['tlink'];
  $qu = "UPDATE slinksGen SET checked='ok', tlink='$tlink' WHERE tmlfile='$file' AND eiid1='$eiid1' AND eiid2='$eiid2' LIMIT 1";
  mysql_query($qu, $db_conn);  
  if (mysql_errno()) {
	printMySqlErrors($query,$_SERVER['SCRIPT_NAME'] . ":" . __LINE__); }
  //printf ("Records deleted: %d<hr><p>\n", mysql_affected_rows());
}


// collecting data for current slink
$row = selectNextSLink();
$file = $row['tmlfile'];
$eiid1 = $row['eiid1'];
$eiid2 = $row['eiid2'];
$str1 = $row['str1'];
$eid1 = $row['eid1'];
$reltype = $row['reltype'];
$str2 = $row['str2'];
$eid2 = $row['eid2'];
$sentid1 = getSentenceID($file,$eid1);
$sentid2 = getSentenceID($file,$eid2);


// find corresponding tlink if there is one
$qtl = "SELECT reltype FROM tlinks WHERE tmlfile='$file' AND eiid1='$eiid1' AND eiid2='$eiid2' LIMIT 1";
$result = mysql_query($qtl, $db_conn);  
if (mysql_errno()) {
  printMySqlErrors($query,$_SERVER['SCRIPT_NAME'] . ":" . __LINE__); }
$hits = mysql_num_rows($result);
if ($hits == 1) {
  $row = mysql_fetch_assoc($result);
  $existing_tlink = $row['reltype']; }
else {
  $existing_tlink = ''; }

?>
<!doctype html public "-//W3C//DTD HTML 4.0 //EN"> 
<html>
<head>
<title><?php echo $title; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="timebank.css" rel="stylesheet" type="text/css">

<script language="JavaScript1.2" src="mm_menu.js">
function MM_jumpMenu(targ,selObj,restore){ //v3.0
  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");
  if (restore) selObj.selectedIndex=0; }
//-->
</script>

<title>Add TLinks (<?php echo $_SERVER['SERVER_NAME'] ?>)</title>

</head>

<body>


<table cellpadding=0>
<tr>
  <td>
  <form action="<?php echo $_SERVER['PHP_SELF'] ?>">
    <input type=submit value="Skip SLink">
    <input name="checked" type="hidden" value="skip">
    <input name="tmlfile" type="hidden" value="<?php echo $file ?>">
    <input name="eiid1" type="hidden" value="<?php echo $eiid1?>">
    <input name="eiid2" type="hidden" value="<?php echo $eiid2?>">
  </form>
  </td>

  <td>&nbsp;</td>

  <td>
  <form action="<?php echo $_SERVER['PHP_SELF'] ?>">
    <input type=submit value="Wrong SLink">
    <input name="checked" type="hidden" value="wrong">
    <input name="tmlfile" type="hidden" value="<?php echo $file ?>">
    <input name="eiid1" type="hidden" value="<?php echo $eiid1?>">
    <input name="eiid2" type="hidden" value="<?php echo $eiid2?>">
  </form>
  </td>
</tr>

</table>

<form action=<?php echo $_SERVER['PHP_SELF'] ?>>

<table bgcolor='#ddffdd' cellpadding=5>

<tr>
<td>
  <strong>
  <?php 
  echo "<strong class=event>$str1<sup>$eid1</sup></strong>";
  echo " $reltype ";
  echo "<strong class=event>$str2<sup>$eid2</sup></strong>";
  if ($existing_tlink) {
	echo "<br>\n";
	echo "<strong class=event>$str1<sup>$eid1</sup></strong>";
	echo " $existing_tlink ";
	echo "<strong class=event>$str2<sup>$eid2</sup></strong>"; }
  ?>
  </strong>
</td>
</tr>

<tr>
<td>
  <?php 
  if ($sentid1 == $sentid2) {
	echoSentence($file,$sentid1,Array($eid1,$eid2)); }
  else {
	echoSentence($file,$sentid1,Array($eid1,$eid2)); 
	echo "<br>";
	echoSentence($file,$sentid2,Array($eid1,$eid2)); }
  ?>
</td>
</tr>

<tr>
<td>
  TLink from <span class=event><?php echo $str1 ?></span> to 
  <span class=event><?php echo $str2 ?></span>: 
  <select name="tlink">
  <option<?php if ($existing_tlink == "") { echo " selected"; } ?> value="UNKNOWN">UNKNOWN</option>
  <option<?php if ($existing_tlink == "BEFORE") { echo " selected"; } ?> value="BEFORE">BEFORE</option>
  <option<?php if ($existing_tlink == "AFTER") { echo " selected"; } ?> value="AFTER">AFTER</option>
  <option<?php if ($existing_tlink == "INCLUDES") { echo " selected"; } ?> value="INCLUDES">INCLUDES</option>
  <option<?php if ($existing_tlink == "IS_INCLUDED") { echo " selected"; } ?> value="IS_INCLUDED">IS_INCLUDED</option>
  <option<?php if ($existing_tlink == "IDENTITY") { echo " selected"; } ?> value="IDENTITY">IDENTITY</option>
  <option<?php if ($existing_tlink == "SIMULTANEOUS") { echo " selected"; } ?> value="SIMULTANEOUS">SIMULTANEOUS</option>
  <option<?php if ($existing_tlink == "BEGINS") { echo " selected"; } ?> value="BEGINS">BEGINS</option>
  <option<?php if ($existing_tlink == "ENDS") { echo " selected"; } ?> value="ENDS">ENDS</option>
  <option<?php if ($existing_tlink == "BEGUN_BY") { echo " selected"; } ?> value="BEGUN_BY">BEGUN_BY</option>
  <option<?php if ($existing_tlink == "ENDED_BY") { echo " selected"; } ?> value="ENDED_BY">ENDED_BY</option>
  <option<?php if ($existing_tlink == "IBEFORE") { echo " selected"; } ?> value="IBEFORE">IBEFORE</option>
  <option<?php if ($existing_tlink == "IAFTER") { echo " selected"; } ?> value="IAFTER">IAFTER</option>
  </select>
  <input type=submit value="OK">
  <input name="checked" type="hidden" value="ok">
  <input name="tmlfile" type="hidden" value="<?php echo $file ?>">
  <input name="eiid1" type="hidden" value="<?php echo $eiid1?>">
  <input name="eiid2" type="hidden" value="<?php echo $eiid2?>">
</td>
</tr>

</table>
</form>

<p>

<?php 
//foreach ($HTTP_GET_VARS as $key => $field) {
//  echo "$key => $field<br>\n"; }
?>

<table bgcolor='#ddffdd' cellpadding=5>
<tr>
<td>

<a href=<?php echo "displayArticle.php?file=$file&highlight=$eid1,$eid2&target=_blank" ?>><?php echo $file ?></a>
<br>
<?php
$allrows = allRowsForDocument($file);
$allrows = filterRows($allrows,$sentid1);
$hlArr = Array();
$hlArr[$eid1] = 1;
$hlArr[$eid2] = 2;
echoSentenceRows($allrows,$hlArr,'<br>'); 
?>

</td>
</tr>
</table>

</body>
</html>
