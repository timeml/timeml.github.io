<?php

require('utils.php');

// get next the $num-th training slink
function selectNextSLink($num) {
	global $db_conn;
	$num2 = $num + 1;
	$query = "SELECT * FROM slinksGen WHERE status='training' LIMIT $num,$num2";
	$result = mysql_query($query, $db_conn);
	if (mysql_errno()) {
		printMySqlErrors($query,"addTlinksToSlinks.php:13"); }
	else {
	  // may want to add a check whether there was a row
	  $row = mysql_fetch_assoc($result);
	  return $row; }}

function getSentenceID($file,$eid) {
	global $db_conn;
	$query = "SELECT sentid FROM events WHERE tmlfile = '$file' AND eid = '$eid'";
	$result = mysql_query($query, $db_conn);
	if (mysql_errno()) {
		printMySqlErrors($query,$_SERVER['SCRIPT_NAME'] . ":" . __LINE__); }
	else {
	  $row = mysql_fetch_assoc($result);
	  return $row['sentid']; }}

function filterRows($rows,$sentid) {
  $context = 5;
  $filteredRows = Array();
  foreach ($rows as $row) {
	if ($row[1] < $sentid + $context && $row[1] > $sentid - $context  ) {
	  $filteredRows[] = $row; }}
  return $filteredRows; }


// collecting data for current slink
$HTTP_GET_VARS['num'] ? ($num = $HTTP_GET_VARS['num']) : ($num = 0);
if ($num < 0) $num = 0;
$row = selectNextSLink($num);
$file = $row['tmlfile'];
$eiid1 = $row['eiid1'];
$eiid2 = $row['eiid2'];
$str1 = $row['str1'];
$eid1 = $row['eid1'];
$reltype = $row['reltype'];
$tlink = $row['tlink'];
$str2 = $row['str2'];
$eid2 = $row['eid2'];
$sentid1 = getSentenceID($file,$eid1);
$sentid2 = getSentenceID($file,$eid2);

?>
<!doctype html public "-//W3C//DTD HTML 4.0 //EN"> 
<html>
<head>
<title><?php echo $title; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="timebank.css" rel="stylesheet" type="text/css">

<script language="JavaScript" type="text/JavaScript">
<!--
function openChangeWindow() {
  var newurl = <?php echo "\"changeTlink.php?file=$file&eiid1=$eiid1&eiid2=$eiid2\"" ?>;
  var w = window.open(newurl,"change","width=500,height=180"); 
}
//-->
</script>

<style type="text/css">
<!--
.button { 
	background-color: #ddddff;
	font-weight: bold; }
</style>

<title>SLinks (<?php echo $_SERVER['SERVER_NAME'] ?>)</title>

</head>

<body>

<table cellpadding=0>
<tr>

  <td>
  <form action="<?php echo $_SERVER['PHP_SELF'] ?>">
    Select SLink:
    <input name="num" size=4 value=<?php echo $num ?>>
  </form>
  </td>

  <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
  <td>
  <form class=event action="<?php echo $_SERVER['PHP_SELF'] ?>">
    <input class=button type=submit value="Previous">
    <input name="num" type="hidden" value=<?php echo $num - 1 ?>>
  </form>
  </td>

  <td>&nbsp;</td>
  <td>
  <form action="<?php echo $_SERVER['PHP_SELF'] ?>">
    <input class=button type=submit value="Next">
    <input name="num" type="hidden" value=<?php echo $num + 1 ?>>
  </form>
  </td>

<?php
$printChange = false;
if ($_SERVER['REMOTE_ADDR'] == '127.0.0.1') { $printChange = true; }
if (preg_match("/adsl.xs4all.nl$/",$_SERVER['REMOTE_HOST']) > 0) { $printChange = true; }
if ($printChange) {
?>
  <td>&nbsp;</td>
  <td>
  <form action=javascript:openChangeWindow()>
    <input class=button type=submit value="Change TLink">
    <input name="tmlfile" type="hidden" value="<?php echo $file ?>">
    <input name="eiid1" type="hidden" value="<?php echo $eiid1?>">
    <input name="eiid2" type="hidden" value="<?php echo $eiid2?>">
  </form>
  </td>
<?php } ?>

</tr>
</table>

<form action=<?php echo $_SERVER['PHP_SELF'] ?>>

<table bgcolor='#ddffdd' cellpadding=5>

<tr>
<td>
  <strong>
  <?php 
  echo "<strong class=event>$str1<sup>$eid1</sup></strong>";
  echo " $reltype ";
  echo "<strong class=event>$str2<sup>$eid2</sup></strong>";
  if ($row['checked'] == 'skip') { echo "&nbsp;&nbsp;(skipped)"; }
  if ($row['checked'] == 'wrong') { echo "&nbsp;&nbsp;(wrong)"; }
  if ($tlink) {
	echo "<br>\n";
	echo "<strong class=event>$str1<sup>$eid1</sup></strong>";
	echo " $tlink ";
	echo "<strong class=event>$str2<sup>$eid2</sup></strong>"; }
  ?>
  </strong>
</td>
</tr>

<tr>
<td>
  <?php 
  if ($sentid1 == $sentid2) {
	echoSentence2($file,$sentid1,Array($eid1,$eid2)); }
  else {
	echoSentence2($file,$sentid1,Array($eid1,$eid2)); 
	echo "<br>";
	echoSentence2($file,$sentid2,Array($eid1,$eid2)); }
  ?>
</td>
</tr>

</table>
</form>

<p>

<table bgcolor='#ddffdd' cellpadding=5>
<tr>
<td>

<a href=<?php echo "displayArticle.php?file=$file&highlight=$eid1,$eid2&target=_blank" ?>><?php echo $file ?></a>
<br>
<?php
$allrows = allRowsForDocument($file);
$allrows = filterRows($allrows,$sentid1);
$hlArr = Array();
$hlArr[$eid1] = 1;
$hlArr[$eid2] = 2;
echoSentenceRows2($allrows,$hlArr,'<br>'); 
?>

</td>
</tr>
</table>

</body>
</html>
