<?php 

require('utils.php');

$tagType = $HTTP_GET_VARS['tagtype'];
$text = $HTTP_GET_VARS['text'];

if ($tagType == 'event') {
	$table = 'events'; 
	$idtype = 'eid';
	$header = 'Event';
} elseif ($tagType == 'timex') {
	$table = 'timexes';
	$idtype = 'tid';
	$header = 'Timex';
} elseif ($tagType == 'signal') {
	$table = 'signals';
	$idtype = 'sid';
	$header = 'Signal';
}

$title = "TimeBank 1.1 $header &nbsp;&#8212;&nbsp; $text";

$query = "SELECT tmlfile,sentid, $idtype FROM $table where text='$text' order by tmlfile";
//echo "$query<br>";
$result = mysql_query($query, $db_conn);
if (mysql_errno()) {
  printMySqlErrors($query,"displayTag.php:8"); }
else {
  $rows = Array();
  while ($row = mysql_fetch_row($result)) {
	$rows[] = $row; }}

$locations = Array();
foreach ($rows as $data) {
  $id = $data[2];
  $sentid = $data[1];
  $file = $data[0];
  $locations[$file]['ids'][] = $id;
  $locations[$file]['sentids'][] = $sentid; } 

?>
<!doctype html public "-//W3C//DTD HTML 4.0 //EN"> 
<html>
<head>
<title><?= $title ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script language="JavaScript" type="text/JavaScript">
<!--
function MM_goToURL() { //v3.0
  var i, args=MM_goToURL.arguments; document.MM_returnValue = false;
  for (i=0; i<(args.length-1); i+=2) eval(args[i]+".location='"+args[i+1]+"'");
}
//-->
</script>
<style type="text/css">
<!--
.event { 
	color: #CC0000; }
.timex { 
	color: #0000CC; }
.signal { 
	color: #33CC00; }
.highlight {
	font-weight: bold; }
sup { 
	font-size: 10px; }
-->
</style>
</head>

<body>

<?php readfile("topnav.php"); ?>

<h2><?= $title ?></h2>


<ulx>

<table cellpadding=7>

<?php

foreach ($locations as $file => $locs) 
{ 
  $getvalue = implode(",",$locs['ids']);
  echo "<tr>\n";
  echo "<td valign=top>\n";
  echo "  <a href=displayArticle.php?file=$file&highlight=$getvalue><img src=inline004.gif border=0></a>\n";
  echo "<td>\n";
  for ($i = 0 ; $i < count($locs['ids']) ; $i++) { 
	echoSentence2($file,$locs['sentids'][$i],Array($locs['ids'][$i]));
	echo "<br>"; }
}


?>

</table>
</ulx>

</body>
</html>
