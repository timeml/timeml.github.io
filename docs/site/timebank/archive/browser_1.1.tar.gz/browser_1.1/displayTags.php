<?php 

require('utils.php');

$tagType = $HTTP_GET_VARS['tagtype'];

$treshold = 10;
if (isset($HTTP_GET_VARS['treshold'])) {
  $treshold = $HTTP_GET_VARS['treshold']; }

$sortType = "alpha";
if (isset($HTTP_GET_VARS['sort'])) {
  $sortType = $HTTP_GET_VARS['sort']; }

if ($tagType == 'event') {
	$table = 'events'; 
	$header = 'Events';
} elseif ($tagType == 'timex') {
	$table = 'timexes';
	$header = 'Timexes';
} elseif ($tagType == 'signal') {
	$table = 'signals';
	$header = 'Signals';
}


$query = "SELECT text,count(*) FROM $table group by text";
$result = mysql_query($query, $db_conn);
if (mysql_errno()) {
  printMySqlErrors($query,"displayTags.php:8"); }
else {
  while ($row = mysql_fetch_row($result)) {
	$rows[] = $row; }}

if ($sortType == "freq") {
  function freq_cmp ($a,$b) {
	if ($a[1] == $b[1]) return 0;
	return ($a[1] > $b[1]) ? -1 : 1; }
  usort($rows, "freq_cmp"); }

?>
<!doctype html public "-//W3C//DTD HTML 4.0 //EN"> 
<html>
<head>
<title>TimeBank 1.1 <?php echo $header ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>

<?php readfile("topnav.php"); ?>

<h2>TimeBank 1.1 <?php echo $header ?></h2>

<form action=displayTags.php>
<table bgcolor=#ccffff cellpadding=5>
<tr>
  <td valign=center>
  List only <?php echo $table ?> with frequency over: 
    <input type=text name=treshold value=<?= $treshold ?> size=3>&nbsp;
  <input type=submit value=Go>
  <input name="tagtype" type="hidden" value="<?php echo $tagType ?>">
  <input name="sort" type="hidden" value="<?php echo $sortType ?>">
  </td>
</tr>
<tr>
  <td>
  <a href=displayTags.php?tagtype=<?php echo $tagType ?>&treshold=<?php echo $treshold ?>&sort=freq>sort by frequency</a> |
  <a href=displayTags.php?tagtype=<?php echo $tagType ?>&treshold=<?php echo $treshold ?>&>sort alphabetically</a>
  </td>
</tr>
</table>
</form>

<p>
<table border=0>
<?php
foreach ($rows as $row) {
  if ($row[1] > $treshold) {
	$str1 = strtolower($row[0]);			// for display in list
    $str2 = str_replace(" ","%20",$str1);	// for use in link
	//$str = preg_replace("/\n/","%0D",$str);
?>
  <tr>
     <td align=right><?php echo $row[1] ?></td>
     <td>&nbsp;</td>
     <td align=left>
	   <a href=displayTag.php?tagtype=<?php echo $tagType ?>&text=<?php echo $str2 ?>><?php echo $str1 ?></a>
	 </td>
  </tr> 
<?
}}
?>
</table>
</body>
</html>
