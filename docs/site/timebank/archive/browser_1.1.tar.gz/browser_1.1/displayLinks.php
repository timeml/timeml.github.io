<?php 

require('utils.php');

$fileName = $HTTP_GET_VARS['file'];
$linkType = $HTTP_GET_VARS['linktype'];

if ($linkType == "ALinks") {
  $title = "$linkType in $fileName";
  $nodeType = "event";
  $rows = allLinkRowsForDocument($fileName,"alinks"); }
if ($linkType == "SLinks") {
  $title = "$linkType in $fileName";
  $nodeType = "event";
  $rows = allLinkRowsForDocument($fileName,"slinks"); }
if ($linkType == "TLinks") {
  $title = "$linkType in $fileName";
  $nodeType = "event/timex";
  $rows = allLinkRowsForDocument($fileName,"tlinks"); }
if ($linkType == "all") {
  $title = "All Links in $fileName";
  $nodeType = "event/timex";
  $rows = allLinkRowsForDocument($fileName,"all"); }


?>
<!doctype html public "-//W3C//DTD HTML 4.0 //EN"> 
<html>
<head>
<title><?php echo $title; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="timebank.css" rel="stylesheet" type="text/css">

<script src='setPointer.js' language="JavaScript" type="text/JavaScript"></script>

<script language="JavaScript" type="text/JavaScript">
<!--

var browser;
if (navigator.appName == "Netscape"){
   	browser="NN"; } 
else if (navigator.userAgent.indexOf("MSIE")!= -1){
    browser="IE"; } 
else {
    browser="Unknown"; }

function setStatus (win,eid1,eiid1,tid1,rel,eid2,eiid2,tid2,str1,str2) {
  var tleft, tright;
  if (eid1) { tleft = str1 + " [" + eid1 + " " + eiid1 + "]"; }
  else { tleft = str1 + " [" + tid1 + "]"; }
  if (eid2) { tright = str2 + " [" + eid2 + " " + eiid2 + "]"; }
  else { tright = str2 + " [" + tid2 + "]"; }
  var statusText = tleft + " -- " + rel + " --> " + tright; 
  win.status = statusText;
  var element = window.opener.document.getElementById("linkdata");
  element.setAttribute("value",statusText);
}

function rowOver (sender) {
  setPointer(sender,'over','#dddddd','#ccffcc','#ffcc99');
}

function rowOut (sender) {
  setPointer(sender,'out','#dddddd','#ccffcc','#ffcc99'); 
}

function rowClick (sender,ids,eid1,eiid1,tid1,rel,eid2,eiid2,tid2,str1,str2) {
  setStatus(window,eid1,eiid1,tid1,rel,eid2,eiid2,tid2,str1,str2);
  highlightTags(ids);
  //setPointer(sender,'click','#dddddd','#ccffcc','#ffcc99');
}

function highlightTags (ids) 
{
	var savedTag, element;
	
	//var debugWin = window.open("","debug","width=400,height=200,scrollbars=yes,resizable=yes");
	//debugWin.document.open();
	//debugWin.document.write("highlightTags(" + ids + ")<br>\n");
	//debugWin.document.write("&nbsp;&nbsp;browser=" + browser + "<br>\n");

	//debugWin.document.write("&nbsp;&nbsp;removing highlights from \n");
	//debugWin.document.write("[" + window.opener.savedTags.toString() + "]<br>\n");
  	for (var i = 0; i < window.opener.savedTags.length; i++) {
		savedTag = window.opener.savedTags[i];
		if (browser == 'IE') {
			element = window.opener.document.all[savedTag]; 
			element.style.backgroundColor = '#ffffff'; }
		else {
			element = window.opener.document.getElementById(savedTag);
			element.setAttribute("class","None"); }
		//debugWin.document.write("&nbsp;&nbsp;&nbsp;&nbsp;tag=" + element.innerHTML + "<br>\n"); 
	}

	//debugWin.document.write("&nbsp;&nbsp;resetting savedTags array<br>\n");
  	window.opener.savedTags = new Array();

	//debugWin.document.write("&nbsp;&nbsp;adding highlights<br>\n");
  	for (var i = 0; i < ids.length; i++) {
		// do not use push(ids[i]) or even concat(ids[i]) for IE5
		window.opener.savedTags[window.opener.savedTags.length] = ids[i];
		if (browser == 'IE') {
			element = window.opener.document.all[ids[i]]; 
			element.style.backgroundColor = '#cccccc'; }
		else {
			element = window.opener.document.getElementById(ids[i]); 
			element.setAttribute("class","highlight"); }
		//debugWin.document.write("&nbsp;&nbsp;&nbsp;&nbsp;tag=" + element.innerHTML + "<br>\n"); 
	}
	//debugWin.document.close();
}

//-->
</script>

</head>

<body>

<h2><?php echo $title; ?></h2>

<!--
<a href=javascript:openLinks("all")>all links</a> |
<a href=javascript:openLinks("ALinks")>alinks</a> |
<a href=javascript:openLinks("SLinks")>slinks</a> |
<a href=javascript:openLinks("TLinks")>tlinks</a>
<p>
-->

<table cellpadding="5">

<tr>
	<th bgcolor="#CCCCCC"><?php echo $nodeType ?></td>
	<th bgcolor="#CCCCCC">reltype</td>
	<th bgcolor="#CCCCCC"><?php echo $nodeType ?></td>
	<th bgcolor="#CCCCCC">signal</td>
</tr>

<?php
foreach ($rows as $row) 
{
	if ($row['eiid1']) { 
	  $sup1 = $row['eid1'];
	  $str1display = "<span class=event>" . $row['str1'] . "</span>"; }
	else { 
	  $sup1 = $row['tid1']; 
	  $str1display = "<span class=timex>" . $row['str1'] . "</span>"; }
	if ($row['eiid2']) { 
	  $sup2 = $row['eid2']; 
	  $str2display = "<span class=event>" . $row['str2'] . "</span>"; }
	else { 
	  $sup2 = $row['tid2']; 
	  $str2display = "<span class=timex>" . $row['str2'] . "</span>"; }

	$str3display = "<span class=signal>" . $row['str3'] . "</span>"; 


	$eid1 = '"'.$row['eid1'].'"';
	$eiid1 = '"'.$row['eiid1'].'"';
	$tid1 = '"'.$row['tid1'].'"';
	$str1 = '"'.$row['str1'].'"';
	$rel = '"'.$row['reltype'].'"';
	$eid2 = '"'.$row['eid2'].'"';
	$eiid2 = '"'.$row['eiid2'].'"';
	$tid2 = '"'.$row['tid2'].'"';	
	$str2 = '"'.$row['str2'].'"';

	$str1 = str_replace(" ","&nbsp;",$str1);
	$str2 = str_replace(" ","&nbsp;",$str2);

	$sid = $row['signalid'];
	if ($sid) { $tags = "[\"$sup1\",\"$sup2\",\"$sid\"]"; }
	else { $tags = "[\"$sup1\",\"$sup2\"]"; }

?>

  <tr 
	onmouseover=javascript:rowOver(this)
	onmouseout=javascript:rowOut(this)
	onclick=javascript:rowClick(this,<?php echo "$tags,$eid1,$eiid1,$tid1,$rel,$eid2,$eiid2,$tid2,$str1,$str2"; ?>)>
	<td valign=bottom bgcolor="#dddddd"><?php echo $str1display ?><sup><?php echo $sup1 ?></sup></td>
	<td valign=bottom bgcolor="#dddddd"><?php echo strtolower($row['reltype']) ?></td>
	<td valign=bottom bgcolor="#dddddd"><?php echo $str2display ?><sup><?php echo $sup2 ?></sup></td>
	<td valign=bottom bgcolor="#dddddd"><?php echo $str3display ?><sup><?php echo $sid ?></sup></td>
</tr>
<?php
}
?>
</table>

</body>
</html>
