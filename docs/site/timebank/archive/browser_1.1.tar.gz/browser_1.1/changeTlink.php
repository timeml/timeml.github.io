<?php

// Connect and select
$db_conn = mysql_connect('localhost','banzai','get!stuffed?');
mysql_select_db('banzai_timebank', $db_conn);
if (mysql_errno()) { echo mysql_errno() . ": " . mysql_error(). "\n<p><hr><p>\n\n"; }

// debug utility
function printMySqlErrors($query,$caller) {
	if (mysql_errno()) {
    	echo 'MySQL Error:' . mysql_errno() . ": " . mysql_error(). "\n";
		echo "<p>Query: $query<p>Caller: $caller<p><hr><p>\n\n"; }}

// get link data
$file = $HTTP_GET_VARS['file'];
$eiid1 = $HTTP_GET_VARS['eiid1'];
$eiid2 = $HTTP_GET_VARS['eiid2'];
$changed = $HTTP_GET_VARS['changed'];
$tlink = $HTTP_GET_VARS['tlink'];

// update tlink
if ($HTTP_GET_VARS['changed'] == 'yes') {
  $q = "UPDATE slinksGen SET checked='ok', tlink='$tlink' WHERE tmlfile='$file' AND eiid1='$eiid1' AND eiid2='$eiid2' LIMIT 1";
  mysql_query($q, $db_conn);  
  if (mysql_errno()) { printMySqlErrors($query,$_SERVER['SCRIPT_NAME'] . ":" . __LINE__); }
  // printf ("Records updated: %d<hr><p>\n", mysql_affected_rows());
}

?>
<!doctype html public "-//W3C//DTD HTML 4.0 //EN"> 
<html>
<head>
<title><?php echo $title; ?></title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="timebank.css" rel="stylesheet" type="text/css">
<title>Change TLink (<?php echo $_SERVER['SERVER_NAME'] ?>)</title>
</head>

<body>

<?php echo "file: $file<br>eiid1: $eiid1<br>eiid2: $eiid2<br>changed: $changed<br>tlink: $tlink<p>\n" ?>

<form action=<?php echo $_SERVER['PHP_SELF'] ?>>
<table bgcolor='#ddffdd' cellpadding=5>
<tr>
<td>
  Change TLink to:
  <select name="tlink">
  <option<?php if ($existing_tlink == "") { echo " selected"; } ?> value="UNKNOWN">UNKNOWN</option>
  <option<?php if ($existing_tlink == "BEFORE") { echo " selected"; } ?> value="BEFORE">BEFORE</option>
  <option<?php if ($existing_tlink == "AFTER") { echo " selected"; } ?> value="AFTER">AFTER</option>
  <option<?php if ($existing_tlink == "INCLUDES") { echo " selected"; } ?> value="INCLUDES">INCLUDES</option>
  <option<?php if ($existing_tlink == "IS_INCLUDED") { echo " selected"; } ?> value="IS_INCLUDED">IS_INCLUDED</option>
  <option<?php if ($existing_tlink == "IDENTITY") { echo " selected"; } ?> value="IDENTITY">IDENTITY</option>
  <option<?php if ($existing_tlink == "SIMULTANEOUS") { echo " selected"; } ?> value="SIMULTANEOUS">SIMULTANEOUS</option>
  <option<?php if ($existing_tlink == "BEGINS") { echo " selected"; } ?> value="BEGINS">BEGINS</option>
  <option<?php if ($existing_tlink == "ENDS") { echo " selected"; } ?> value="ENDS">ENDS</option>
  <option<?php if ($existing_tlink == "BEGUN_BY") { echo " selected"; } ?> value="BEGUN_BY">BEGUN_BY</option>
  <option<?php if ($existing_tlink == "ENDED_BY") { echo " selected"; } ?> value="ENDED_BY">ENDED_BY</option>
  <option<?php if ($existing_tlink == "IBEFORE") { echo " selected"; } ?> value="IBEFORE">IBEFORE</option>
  <option<?php if ($existing_tlink == "IAFTER") { echo " selected"; } ?> value="IAFTER">IAFTER</option>
  </select>
  <input type=submit value="OK">
  <input name="changed" type="hidden" value="yes">
  <input name="file" type="hidden" value="<?php echo $file ?>">
  <input name="eiid1" type="hidden" value="<?php echo $eiid1?>">
  <input name="eiid2" type="hidden" value="<?php echo $eiid2?>">
</td>
</tr>
</table>
</form>

</body>
</html>
