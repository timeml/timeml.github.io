<?php

# connection variables
require("connection.php");

#$debugging = true;
$debugging = false;

# table names
$LOGIN_TABLE = 'login';
$DOCUMENTS_TABLE = 'documents';
$JUDGEMENTS_TABLE = 'judgements';
$EVENTS_TABLE = 'tb_events';
$INSTANCES_TABLE = 'tb_instances';
$SENTENCES_TABLE = 'tb_sentences';


// Connect to host and select database

$db_conn = mysql_connect($hostname, $username, $password);
if (mysql_errno()) {
	echo "<b><font color=#ff0000>There is a problem with the database connection, try again later.</font></b>";
	echo "<p>Please send an email to marc@cs.brandeis.edu if the problem persists.<hr>";
	exit;
    echo mysql_errno() . ": " . mysql_error(). "\n<p><hr><p>\n\n";
}
mysql_select_db($db, $db_conn);
if (mysql_errno()) {
    echo mysql_errno() . ": " . mysql_error(). "\n<p><hr><p>\n\n";
}


function printVars()
{
	global $debugging, $HTTP_GET_VARS, $HTTP_POST_VARS;
	if ($debugging) {
		foreach ($HTTP_GETT_VARS as $var => $value) {
			echo "\$HTTP_GETT_VARS['$var'] => '$value'<br>\n"; }
		foreach ($HTTP_POST_VARS as $var => $value) {
			echo "\$HTTP_POST_VARS['$var'] => '$value'<br>\n"; }
	}
}


function checkLogin($name)
{
	// Is $name on the list of allowed logins?

	global $LOGIN_TABLE;
	$query = "SELECT * FROM $LOGIN_TABLE WHERE name = '$name'";
	$rows = select($query,'checkLogin()');
	if ($rows and count($rows) > 0) {return true; } else { return false; }
}


function getDocumentTitle($fileName)
{
	global $db_conn, $DOCUMENTS_TABLE;
	$query = "SELECT title FROM $DOCUMENTS_TABLE WHERE id = '$fileName'";
	$result = select($query,'getDocumentTitle');
	$firstRow = $result[0];
	return $firstRow[0];
}


function numberOfArticlesAnnotated($name) 
{
	global $debugging, $db_conn, $DOCUMENTS_TABLE;
	$query = "SELECT COUNT(*) FROM $DOCUMENTS_TABLE WHERE ann1 = '$name' OR ann2 = '$name'";
	if ($debugging) 
		echo $query . "<br>\n";
	$result = mysql_query($query, $db_conn);
	if (mysql_errno()) {
		printMySqlErrors($query,"utils.php::numberOfArticlesAnnotated()"); }
	else {
		$row = mysql_fetch_row($result);
		return $row[0];
	}
}


function articlesAnnotated($name) 
{
	global $db_conn, $DOCUMENTS_TABLE;
	$query = "SELECT * FROM $DOCUMENTS_TABLE WHERE ann1 = '$name' OR ann2 = '$name'";
	$rows = select($query,'articlesAnnotated');
	return $rows;
}


function selectNewFile($name)
{
	global $db_conn, $DOCUMENTS_TABLE;
	$query = "SELECT * FROM $DOCUMENTS_TABLE WHERE (ann1 = '' and ann2 != '$name') OR (ann2 = '' and ann1 != '$name') order by id";
	$rows = select($query,'selectNewFile');
	$firstRow = $rows[0];
	$newFile = $firstRow[0];
	$ann1 = $firstRow[2];
	$ann2 = $firstRow[7];
	if ($ann1) {
		$setStatement = "ann2='$name'"; 
	} else {
		$setStatement = "ann1='$name'"; 
	}
	$query = "UPDATE $DOCUMENTS_TABLE SET $setStatement WHERE id = '$newFile';";
	update($query,'selectNewFile()');
	return $newFile;
}


function setDocumentJudgements($login, $file, $notrelevant, $topic, $comment)
{
	global $debugging, $db_conn, $DOCUMENTS_TABLE;
	$query = "SELECT * FROM $DOCUMENTS_TABLE where id='$file';";
	if ($debugging)
		echo $query . "<br>\n";
	$result = mysql_query($query, $db_conn);
	if (mysql_errno()) {
		printMySqlErrors($query,"utils.php::setDocumentJudgements()"); }
	else {
		$row = mysql_fetch_row($result);
		$ann1 = $row[2];
		$ann2 = $row[7];
		if ($ann1 == $login) {
			$doneField = 'ann1Done';
			$notrelevantField = 'ann1Relevant';
			$topicField = 'ann1Topic';
			$commentField = 'ann1Comment';
		} elseif ($ann2 == $login) {
			$doneField = 'ann2Done';
			$notrelevantField = 'ann2Relevant';
			$topicField = 'ann2Topic';
			$commentField = 'ann2Comment';
		} else {
			echo "WARNING: something's wrong (setDocumentJudgements)<br>";
		}
		$protectedComment = addslashes($comment);
		$query = "UPDATE $DOCUMENTS_TABLE SET $doneField='yes', $topicField='$topic', $commentField='$protectedComment' WHERE id='$file';";
		update($query,'setDocumentJudgements()');
		if ($notrelevant) {
			$query = "UPDATE $DOCUMENTS_TABLE SET $notrelevantField='no' WHERE id='$file';";
			update($query,'setDocumentJudgements()');
		}
	}

}

function resetEventJudgements($login,$file) 
{
	global $debugging, $db_conn, $JUDGEMENTS_TABLE;
	$query = "DELETE FROM $JUDGEMENTS_TABLE WHERE docID='$file' and annotator='$login';";
	if ($debugging)
		echo $query."<br>";
	$result = mysql_query($query, $db_conn);
	if (mysql_errno()) {
		printMySqlErrors($query,"utils2.php::deleteJudgements($file)"); }
	
}

function addJudgement($login, $file, $event, $verdict)
{
	global $debugging, $db_conn, $JUDGEMENTS_TABLE;
	$query = "INSERT INTO $JUDGEMENTS_TABLE VALUES ('$file', '$login', '$event', '$verdict');";
	if ($debugging)
		echo "$query<br>\n";
	$result = mysql_query($query, $db_conn);
	if (mysql_errno()) {
		printMySqlErrors($query,"utils2.php::addJudgement($file,$event,$verdict)"); }
}



function allRowsForDocument($doc)
{
	// return all rows from sentences for tmlfile $doc
	
	global $db_conn, $SENTENCES_TABLE;
	$query = "SELECT * FROM $SENTENCES_TABLE WHERE tmlfile = '$doc' order by sentid, offset";
	$rows = select($query,'allRowsForDocument');
	return $rows;
}


function echoDocument ($fileName,$highlightIDs,$sep,$login)
{
	// Echo a document
	
	$rows = allRowsForDocument($fileName);
	$events = relevantEventsForDocument($login,$fileName);
	echoSentenceRows($rows,$highlightIDs,$sep,true,$events); 
}

function comment($login,$file) 
{
	global $DOCUMENTS_TABLE;
	$query = "SELECT * FROM $DOCUMENTS_TABLE WHERE id='$file';";
	$result = select($query,'comment');
	$firstRow = $result[0]; 
	if ($firstRow[2] == $login) {	
		return stripslashes($firstRow[6]);
	} elseif  ($firstRow[7] == $login) {	
		return stripslashes($firstRow[11]);
	} else {
		echo "WARNING: something wrong in comment<br>\n";
	}
}

function echoNotrelevant($login,$file)
{
	global $DOCUMENTS_TABLE;
	$query = "SELECT * FROM $DOCUMENTS_TABLE WHERE id='$file';";
	$result = select($query,'notrelevant');
	$firstRow = $result[0]; 
	if ($firstRow[2] == $login) {	
		$val = $firstRow[4];
	} elseif  ($firstRow[7] == $login) {	
		$val = $firstRow[9];
	} else {
		echo "WARNING: something wrong in notrelevant<br>\n";
	}
	if ($val != yes) {
		echo 'checked'; }
}

function echoTopics ()
{
	echo "The topic of this document is:&nbsp;\n";
	echo "<SELECT name=topic>\n";
	echo "<OPTION>terrorism</OPTION>\n";
	echo "<OPTION>strategic research</OPTION>\n";
	echo "<OPTION>political statements</OPTION>\n";
	echo "<OPTION>...</OPTION>\n";
	echo "</SELECT>\n";
}

function relevantEventsForDocument($login, $fileName)
{
	global $JUDGEMENTS_TABLE;
	$query = "SELECT eventID FROM $JUDGEMENTS_TABLE WHERE docID='$fileName' and annotator='$login';";
	$rows = select($query, 'relevantEventsForDocument');
	$events = array();
	foreach ($rows as $row) {
		$event = $row[0];
		#echo $event."<br>";
		$events[$event] = true;
	}
	return $events;
}

function echoSentenceRows ($rows, $highlightIDs, $sep, $markObjects,$events) 
{
   // Echo rows from $SENTENCES_TABLE, insert breaks just before every
   // first token of a sentence. The $printID variable is used to
   // print sentence numbers. May need to add parameters to control
   // whether and how numbers are printed.

  	$printID = 1;
	echo "<table cellpadding=5>\n";
  	foreach ($rows as $row) {
		if ($row[2] == 1) { 
			#echo "\n$sep\n"; 
			$printID = 1; }
		// strip the | from the varchar field
		$text = substr($row[3],0,-1);
		$tag = $row[4];
		$id = $row[5];
		if ($printID) {
			$sentid = $row[1];
		  	echo "<tr><td valign=\"top\">";
		        $printID = 0; 
		}
		if ($tag) {
			echoTag($id,$tag,$highlightIDs[$id],$text,$markObjects,$events);
			echo "\n";
		} else {
	  		echo $text; 
			echo "\n";
		}
	}
	echo "</table>\n";
}


function echoTag ($id,$tag,$highlight,$text,$markObjects,$events)
{
  	// Echo a tag, printing highlights and markings if requested
	
  	if ($tag == 'EVENT') { 
    		echo "[<span class=event>"; 
		if ($events[$id]) {
   			echo "<input type=checkbox name=$id checked>";
		} else {
   			echo "<input type=checkbox name=$id>";
		}
	} 
  	echo $text;
  	if ($tag == 'EVENT') { 
    		echo "</input>";
    		echo "</span>]"; 
  	}
}



// DATABASE FUNCTIONS

function select($query,$caller)
{
	global $db_conn, $debugging;
	if ($debugging)
		echo $query."<br>\n";
	$result = mysql_query($query, $db_conn);
	if (mysql_errno()) {
		printMySqlErrors($query,$caller); 
		return false;
	}
	else {
		while ($row = mysql_fetch_row($result)) { $rows[] = $row; }
		return $rows;
	}
}

function update($query,$caller)
{
	global $db_conn, $debugging;
	if ($debugging)
		echo $query."<br>\n";
	$result = mysql_query($query, $db_conn);
	if (mysql_errno()) {
		printMySqlErrors($query,$caller); 
		return false;
	} else {
		return true;
	}
}


// Debug utility
function printMySqlErrors($query,$caller) {
	if (mysql_errno()) {
    	echo 'MySQL Error:' . mysql_errno() . ": " . mysql_error(). "\n";
		echo "<p>Query: $query<p>Caller: $caller<p><hr><p>\n\n"; }}

?>
