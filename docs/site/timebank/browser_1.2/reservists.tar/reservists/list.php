<?php 

require("connection.php");
require("utils.php");

printVars();

$login = $HTTP_POST_VARS['login'];
$articles = articlesAnnotated($login);


?>
<!doctype html public "-//W3C//DTD HTML 4.0 //EN"> 
<html>
<head>
<title>Event Annotator</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="timebank.css" rel="stylesheet" type="text/css">
</head>

<body>

<h2>Event Annotator - Previously annotated documents</h2>

<hr>

<p>List of previously annotated articles for <?php echo $login; ?>:</p>

<blockquote>

<?php
$count = 0;
foreach ($articles as $article) 
{
	$count++;
	$id = $article[0];
	$title = $article[1];
?>
	<form action="article.php" method="post">
	<input type="hidden" name="login" value="<?php echo $login; ?>" />
	<input type="hidden" name="file" value="<?php echo $id; ?>" />
	<input type="submit" value="<?php echo $count.': '.$title; ?>" />
	</form>
	<br>
<?php
}
?>

</blockquote>

<hr>

<table>
<tr>
<td>
<form action="home.php" method="post">
    <input type="hidden" name="login" value="<?php echo $login; ?>" />
    <input type="submit" value="Home" />
</form>
<td>
<form action="article.php" method="post">
<input type="hidden" name="login" value="<?php echo $login; ?>" />
<input type="submit" value="Annotate new document" />
</form>
<td>
<form action="index.php" method="post">
<input type="submit" value="Logout" />
</form>
</table>

</body>
</html>
