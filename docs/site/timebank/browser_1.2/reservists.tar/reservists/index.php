<!doctype html public "-//W3C//DTD HTML 4.0 //EN"> 
<html>
<head>
<title>Topic Annotator</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="timebank.css" rel="stylesheet" type="text/css">	
</head>

<body>

<h2>Event Annotator - Login</h2>

<hr>

Please enter your login name:&nbsp; 

<blockquote>
<FORM action="home.php" method="post">
<input type="text" name="login" />
<input class="highlight" type="submit" value="Login" />
</FORM>
<blockquote>

</body>
</html>



