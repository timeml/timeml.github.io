<?php 

require("connection.php");

function printMySqlErrors($query,$caller) {
  if (mysql_errno()) {
    echo 'MySQL Error:' . mysql_errno() . ": " . mysql_error(). "\n";
    echo "<p>Query: $query<p>Caller: $caller<p><hr><p>\n\n"; }
}

$SENTENCES_TABLE = 'tb_sentences';

// Connect to host and select database
$db_conn = mysql_connect($hostname, $username, $password);
if (mysql_errno()) {
	echo "<hr><h2>Topic Annotator</h2>";
	echo "<b><font color=#ff0000>There is a problem with the database connection, try again later.</font></b>";
	echo "<p>Please send an email to marc@cs.brandeis.edu if the problem persists.<hr>";
	exit;
    echo mysql_errno() . ": " . mysql_error(). "\n<p><hr><p>\n\n";
}
mysql_select_db($db, $db_conn);
if (mysql_errno()) {
    echo mysql_errno() . ": " . mysql_error(). "\n<p><hr><p>\n\n";
}


$query = "SELECT distinct tmlfile FROM $SENTENCES_TABLE";
$result = mysql_query($query, $db_conn);
if (mysql_errno()) {
  printMySqlErrors($query,"displayArticles.php:8"); }
else {
  while ($row = mysql_fetch_row($result)) {
    $files[] = $row[0]; }}

?>
<!doctype html public "-//W3C//DTD HTML 4.0 //EN"> 
<html>
<head>
<title>Topic Annotator</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>

<h2>Topic Annotator</h2>

<ol>

<?php
foreach ($files as $file) {
  echo '<li><a href=article.php?file='.$file.'>'.$file."</a>\n";
}
?>

</ol>
</body>
</html>
