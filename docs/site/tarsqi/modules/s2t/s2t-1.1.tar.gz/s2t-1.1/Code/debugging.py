

"""==============================

      DEBUGGING UTILITIES

=============================="""



debugFlag = 0
logFlag = 0


if debugFlag:
    debugFile = open('debugOUT', 'w')

if logFlag:
    logFile = open('logOUT', 'w')



def debug(inputString): 
    if debugFlag:
        debugFile.write(inputString)
        debugFile.write("\n")

        
def log(inputString):
    if logFlag:
        logFile.write(inputString)
