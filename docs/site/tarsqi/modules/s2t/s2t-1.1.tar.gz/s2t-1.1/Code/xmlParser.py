#!/usr/bin/python

import sys, re, os, xml.parsers.expat
from sys import stdout
from types import *   
from Chunk import Chunk, NounChunk, VerbChunk, Token, AdjectiveToken
from Document import *
from Sentence import *
from Tag import *
from timeMLspec import *
from debugging import debug, log


currentDoc = None
currentSentence = None
currentChunk = None
currentEvent = None
currentToken = None
currentTimex = None
finishedEventInChunk = 0  #needed for VerbChunks conatining an EVENT followed by some other particle.
timexWithinChunk = 0
chunkWithinTimex = 0
parser = None

# Dictionaries for holding event and instance information
allEvents = {}
allInstances = {}
allSlinks = {}
allAlinks = {}  # a2t
allTlinks = {}  # a2t
newTlinks = {}

def readFileWithEvents(fileName):
    global currentDoc
    global parser
    global allEvents
    allEvents = {}
    global allInstances
    global allSlinks
    allSlinks = {}
    #print "CURRENT SLINK DICTIONARY:"
    #print allSlinks.keys()
    global allAlinks
    allAlinks = {}
    #print "in a2tParser.py"

    initializeParsingEvents()

    currentDoc = Document(fileName)
    if os.path.exists(fileName):
        #try:
            file = open(fileName, 'r')
            #log("FILE:",fileName)
            parser.ParseFile(file)
            file.close()
        #except:
        #    print "WARNING: file could not be processed:", fileName
    currentDoc.allEvents = allEvents
    currentDoc.allInstances = allInstances
    currentDoc.allSlinks = allSlinks
    currentDoc.allAlinks = allAlinks # A2T
    currentDoc.allTlinks = allTlinks # A2T
    currentDoc.newTlinks = newTlinks
    return currentDoc



def initializeParsingEvents():
    global currentDoc
    global currentSentence
    global currentChunk
    global currentToken
    global currentEvent
    global currentTimex
    global finishedEventInChunk
    global timexWithinChunk
    global chunkWithinTimex
    global parser
    
    parser = xml.parsers.expat.ParserCreate()
    parser.StartElementHandler = start_element
    parser.EndElementHandler = end_element
    parser.CharacterDataHandler = charData
    parser.XmlDeclHandler = xmlDec
    parser.DefaultHandler = default
    currentDoc = None
    currentSentence = None
    currentChunk = None
    currentToken = None
    currentEvent = None
    currentTimex = None
    finishedEventInChunk = 0
    timexWithinChunk = 0
    chunkWithinTimex = 0
    

def start_element(name, attrs):
    log("\n============\nNAME: "+str(name)+"\n============\n")
    #log("ATTRS: "+str(attrs)+"\n")
    if name == SENTENCE:
        procSentStart()
    elif CHUNK.match(name): 
        procChunkStart(name)
    elif name == TOKEN:
        if attrs.has_key(POS):
            pos = attrs[POS]
        else:
            pos = "PUNCT"
        procTokStart(pos)
    elif name == CHUNKHEAD:
        procChunkHeadStart()
    elif CHUNKVERBAL.match(name):
        procChunkVerbalStart()
    elif name == CHUNKPOSS:
        procPOSStart()
    elif name == EVENT:
        procEventStart(attrs)
    elif name == INSTANCE:
        procInstanceStart(attrs)
    elif name == TIMEX:
        procTimexStart(attrs)
    elif name == SLINK:
        procSlinkStart(attrs)
    elif name == ALINK:
        procAlinkStart(attrs)
    elif name == TLINK:
        procTlinkStart(attrs)
    

    if name in EMPTY_TAGS:
        currentDoc.addDocNode(emptyContentString(name, attrs))
    elif name == TIMEML:
        pass
    else:
        currentDoc.addDocNode(startElementString(name, attrs))

def end_element(name):
    if name == SENTENCE:
        procSentEnd()
    elif CHUNK.match(name):
        procChunkEnd(name)
    elif name == TOKEN:
        procTokEnd()
    elif CHUNKVERBAL.match(name):
        procChunkVerbalEnd()
    elif name == EVENT:
        procEventEnd()
    elif name == TIMEX:
        procTimexEnd()
    elif name == CHUNKHEAD:
        procChunkHeadEnd()

    if name in EMPTY_TAGS:    #Hacking, but anyway!
        pass
    elif name == TIMEML:
        pass 
    else:
        currentDoc.addDocNode(endElementString(name))

def charData(string):
    #log("This is STRING")
    """If string is event expression (i.e., within EVENT tag),
       add form into currentDoc.taggedEventDict"""
    if currentEvent is not None and currentToken is not None:
        #log("TOKEN STRING into EVENT space")
        eid = currentEvent.attrs[EID]
        #log(">>> STORING VALUES:"+str(eid)+"  "+str(string))
        currentDoc.storeEventValues({EID:eid, FORM: string})
    
    """Regardless whether the string is an event expression,
       add it into the Document object """
    if currentToken is not None:
        #log("TOKEN STRING into TOKEN space")
        if currentToken.textIdx:
            #log("\tTOKEN 1")
            currentDoc.nodeList[-1] = currentDoc.nodeList[-1] + string
        else:
            #log("\tTOKEN 2")
            currentToken.setTextNode(currentDoc.nodeCounter)
            currentDoc.addDocNode(string)
    else:
        currentDoc.addDocNode(string)
        

def default(string):
    currentDoc.addDocNode(string)

def xmlDec(version, encoding, standalone):
    pass

def procSentStart():
    global currentSentence
    currentSentence = Sentence()

def procSentEnd():
    global currentSentence
    currentDoc.addSentence(currentSentence)
    currentSentence = None

def procEventStart(attrs):
    global currentEvent
    #log("This is an EVENT tag")
    if currentTimex is not None or currentEvent is not None:
        log("WARNING: <EVENT> within <TIMEX3> or another <EVENT> tag")
        currentSentence.trackEmbedding(EVENT)
    else:
        currentEvent = EventTag(attrs)
        
def getEventLocation():
    if currentSentence is not None:
        position = currentChunk.position
        #log("\nEVENT tag is within a Chunk\nPosition: "+str(position))
        return position
    else:
        raise "ERROR: no position for current Event"

def procEventEnd():
    global currentEvent
    global finishedEventInChunk
    global allEvents

    """Not setting currentEvent to None here,
    but in procChunkEnd instead, since:
    a) EVENT is always within a Chunk,
    b) there should be no more than ONE EVENT tag per chunk,
    c) EventTag object needs info of chunk location,
    which is only available once Chunk
    is added to its Sentence object"""
    log("Closing EVENT")
    if currentSentence.hasEmbedded(EVENT):
        #log("EVENT was embedded")
        currentSentence.removeEmbedded(EVENT)
    else:
        if currentChunk is not None:
            #log("Adding EVENT into Chunk")
            currentChunk.addToken(currentEvent)
        else:
            #log("Adding EVENT into Sentence")
            currentSentence.add(currentEvent)
    finishedEventInChunk = 1
    allEvents[currentEvent.eid] = currentEvent

def procInstanceStart(attrs):
    global allInstances
    
    #log("This is an INSTANCE tag")
    currentInstance = InstanceTag(attrs)
    #print "INSTANCE attrs:", attrs
    currentDoc.storeEventValues(currentInstance.attrs)
    allInstances[currentInstance.attrs['eiid']] = currentInstance
    
def procTimexStart(attrs):
    global currentSentence
    global currentTimex
    global currentChunk
    global timexWithinChunk

    log("\nStarting a TIMEX3 tag: "+str(attrs))
    if currentTimex is not None or currentEvent is not None:
        log("WARNING: <TIMEX3> tag within <EVENT> or another <TIMEX3> tag")
        currentSentence.trackEmbedding(TIMEX)
    else:
        currentTimex = TimexTag(attrs)
    
def procTimexEnd():
    global currentTimex
    global currentChunk
    global currentSentence
    global currentDoc

    log("\tEnding a TIMEX3 tag")    

    if currentSentence is not None and currentSentence.hasEmbedded(TIMEX):
        #log("TIMEX was embedded")
        currentSentence.removeEmbedded(TIMEX)
    else:
        if currentChunk is not None:
            #log("Adding Timex into Chunk")
            currentChunk.addToken(currentTimex)
        elif currentSentence is not None:
            #log("Adding Timex into Sentence")
            currentSentence.add(currentTimex)
        else:
            currentDoc.addTimex(currentTimex)
        currentTimex = None
    
def procTokStart(pos):
    global currentSentence
    global currentToken
    
    if currentToken is not None:
        raise "ERROR: currentToken is not None"
    currentToken = newToken(currentDoc, pos)

def procTokEnd():
    global currentSentence
    global currentToken
    global currentChunk
    global currentEvent
    global currentTimex
    global currentSentence
    global finishedEventInChunk

    if currentEvent is not None and not finishedEventInChunk:
        currentEvent.addTokenInfo(currentToken)
    elif currentTimex is not None:
        currentTimex.add(currentToken)
    elif currentChunk is not None:
        currentChunk.addToken(currentToken)
    elif currentSentence is not None:
        currentSentence.add(currentToken)
    else:
        #log("Missed token:"+str(currentToken.getText()))
        pass
    currentToken = None
        
def newToken(currentDoc,pos):
    if pos == 'JJ':
        return AdjectiveToken(currentDoc,pos)
    else:
        return Token(currentDoc, pos)

def procChunkStart(name):
    global currentSentence
    global currentTimex
    global currentChunk

    if currentEvent is not None:
        log("WARNING: Chunk is contained within an <EVENT>")
        currentSentence.trackEmbedding(name)
    elif currentTimex is not None or currentChunk is not None:
        log("---STARTING Chunk (2), type:"+str(name))
        currentSentence.trackEmbedding(name)
    else:
        log("\n---STARTING Chunk (1), type:"+str(name))
        currentChunk = newChunk(name)
    
def procChunkEnd(name):
    global currentSentence
    global currentChunk
    global currentEvent
    global chunkWithinTimex
    global finishedEventInChunk

    if currentSentence.hasEmbedded(name):
        log("---ENDING Chunk (2), type"+str(name))
        currentSentence.removeEmbedded(name)
    else:
        log("---ENDING Chunk (1), type"+str(name))
        currentSentence.add(currentChunk)
        """The following part needs to take place after
        having inserted the chunk within the Sentence""" 
        if currentEvent is not None and finishedEventInChunk:
            """EVENT tag always within chunk """
            eventLoc = getEventLocation()
            currentSentence.storeEventLocation(eventLoc, currentEvent.attrs[EID])
            currentDoc.storeEventValues(currentEvent.attrs)
            currentChunk.setEventInfo(currentEvent.attrs[EID])
            #print "EVENT attrs:", currentEvent.attrs
            log("---ENDING EVENT")
            currentEvent = None
            finishedEventInChunk = 0
        currentChunk = None

def procChunkHeadStart():
    if type(currentChunk) is NoneType:
        pass
    else:
        currentChunk.startHead()

def procChunkHeadEnd():
    pass
    #print "\tEnding head"

    
def procChunkVerbalStart():
    if type(currentChunk) is NoneType:
        #print "---STARTING SubChunk (2), type:", 
        pass
    else:
       # print "---STARTING SubChunk (1), type:",
        currentChunk.startVerbs()

def procChunkVerbalEnd():
    if type(currentChunk) is NoneType:
        #print "---ENDING SubChunk (2), type:", 
        pass
    else:
        #print "---ENDING SubChunk (1), type:", 
        currentChunk.endVerbs()

def procPOSStart():
    if currentChunk is not None:  #R   #BK if we get a POS node with no current chunk, something is broken.
        currentChunk.startPOSS()   #we should probably raise an exception

def newChunk(name):
    if name.startswith("V"):     # use VG???
        return VerbChunk(name)
    elif name.startswith("N"):   # use NG???
        return NounChunk(name)
    else:
        return Chunk(name)


def endElementString(name):
    return '</'+name+'>'

def startElementString(name, attrs):
    string = '<'+name
    for att in attrs.items():
        name = att[0]
        value = att[1]
        if not (name is None or value is None):
            string = string+' '+name+'="'+value+'"'
    string = string+'>' 
    return string

def emptyContentString(name, attrs):
    #global allSlinks
    string = '<'+name
    #if name == "SLINK":
    #    currentSlink = SlinkTag(attrs)
    #    allSlinks[currentEvent.attrs['lid']] = currentSlink
    for att in attrs.items():
        name = att[0]
        value = att[1]
        if not (name is None or value is None):
            string =string+' '+name+'="'+value+'"' 
    string = string+'/>'
    return string

def procSlinkStart(attrs):
    global allSlinks
    currentSlink = SlinkTag(attrs)
    #print currentSlink
    allSlinks[currentSlink.attrs['lid']] = currentSlink
    #print "SLINK attrs:", attrs

def procAlinkStart(attrs): # AT2
    global allAlinks
    currentAlink = AlinkTag(attrs)
    #print "IN a2tParser.py"
    #print currentAlink
    allAlinks[currentAlink.attrs['lid']] = currentAlink

def procTlinkStart(attrs):
    #global newTlinks
    global allTlinks # A2T
    currentTlink = TlinkTag(attrs)
    allTlinks[currentTlink.attrs['lid']] = currentTlink




class Error(Exception):
    def __init__(self, text):
        self.text = text

    def __str__(self):
        return self.text
