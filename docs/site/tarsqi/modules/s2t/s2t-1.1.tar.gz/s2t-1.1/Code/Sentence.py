import sys
from debugging import debug

class Sentence:
    def __init__(self):
        self.chunkList = []
        self.chunkIndex = 0
        """Storing tuples (eLoc, eID) of each tagged event in Sent:"""
        self.eventList = [] 
        self.position = None
        self.positionCount = 0
        self.parent = None
        """ Using stacks to keep track of all currently open elements,
        in order to deal with multiple embedding of the same
        element type; e.g.,
        <T3><Chk><T3><Chk> ... </Chk></T3></Chk></T3>"""
        self.embeddedTags =[]
        
    def __len__(self):
        return len(self.chunkList)

    def __getitem__(self, index):
        if index is None:
            debug("WARNING: event index is None")
            return None
        else:
            return self.chunkList[index]

    def __getslice__(self, i, j):
        return self.chunkList[i:j]

    def document(self):
        return self.parent.document()

    def add(self, chunkOrToken):
        chunkOrToken.setParent(self)
        self.chunkList.append(chunkOrToken)
        self.positionCount += 1

    def setParent(self, parent):
        self.parent = parent
        self.position = parent.positionCount

    def storeEventLocation(self, evLoc, eid):
        self.eventList.append((evLoc, eid))

    def trackEmbedding(self, tag):
        self.embeddedTags.append(tag)

    def hasEmbedded(self, tag):
        if self.embeddedTags and self.embeddedTags[-1] == tag:
            return 1
        else:
            return 0

    def removeEmbedded(self, tag):
        self.embeddedTags = self.embeddedTags[:-1]
        
    def getTokens(self):
        tokenList = []
        for chunkOrToken in self.chunkList:
            if chunkOrToken.isToken():
                tokenList += [chunkOrToken]
            elif chunkOrToken.isChunk():
                tokenList += chunkOrToken.tokenList
            else:
                raise Exception("not a chunk or token in sentence")
        return tokenList

    def lookRight(self,sentPos,chunkDescriptions):
        """Find chunks (or tokens) to the right of the chunk with
        sentence position sentPos. Seeks for a sequence of chunks that
        match the grammatical features in *chunkDescriptions. The
        sequence can be discontinuous. Returns None if there is no
        match, returns the list of matched chunks if there is a
        match. Needs to set the eventCreationAttempted variable on all
        chunks that are spanned by a succesfull match. """
        currentPos = sentPos + 1
        foundChunks = []
        while chunkDescriptions:
            for chunkDescription in chunkDescriptions:
                chunk = self._findChunk(currentPos,chunkDescription)
                if not chunk:
                    self._resetAttemptFlag(sentPos)
                    return None
                else:
                    foundChunks.append(chunk)
                    currentPos = chunk.position + 1
        return foundChunks
    
    def _findChunk(self,sentPos,chunkDescription):
        """Find a chunk matching chunkDescription. Start at position
        sentPos and match. If failed, increment sentPos by one and try
        again. Continue till out of bounds or succeed. Return None or
        the found chunk."""
        currentPos = sentPos
        while self._containsPos(currentPos):
            chunk = self[currentPos]
            if chunk._matchChunk(chunkDescription):
                return chunk
            currentPos = currentPos + 1

    def _containsPos(self,position):
        return position < len(self) 
    
    def _resetAttemptFlag(self,sentPos):
        """Reset the value of eventCreationAttempted to 0 for all
        chunks following sentPos."""
        pass

       

        
