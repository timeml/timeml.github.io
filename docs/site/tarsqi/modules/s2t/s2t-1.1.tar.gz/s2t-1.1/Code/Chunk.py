import string, sys
import forms
#from chunkAnalyzer import GramNChunk, GramVChunk, GramAChunk, NOM_CONTEXT_TR
from types import ListType, TupleType, StringType
#from patterns import HAVE_FSAs, BE_FSAs, GOINGto_FSAs, MODAL_FSAs, USEDto_FSAs, DO_FSAs
from timeMLspec import *
from debugging import debug, log


class Constituent:
    """An abstract class that contains some methods that are identical
    for Chunks and Tokens plus a couple of default methods."""
    
    def setParent(self, parent):
        self.parent = parent
        self.position = parent.positionCount

    def document(self):
        return self.parent.document()
    
    def isToken(self): return 0
    def isChunk(self): return 0
    def isVerbChunk(self): return 0
    def isNounChunk(self): return 0
    def isTimex(self): return 0
    def isNChHead(self): return 0

    def __getattr__(self, name):
        """Used by node._matchChunk. Needs cases for all instance
        variables used in the pattern matching phase."""
        if name == 'nodeType':
            return self.__class__.__name__
        else:
            raise AttributeError, name
            
##    def setFlagCheckedForEvents(self):
##        if self.parent.__class__.__name__ == 'Sentence':
##            if not self.flagCheckedForEvents:
##                self.flagCheckedForEvents = 1
##        else:
##            self.parent.setFlagCheckedForEvents()

    def getText(self):
        pass
        
    def nextNode(self):
        """Works only dreamily when called on Sentence elements. If
        called on a token that is embedded in a chunk, then it should
        really look into the next chunk is self is a chunk-final
        token."""
        try:
            return self.parent[self.position+1]
        except IndexError:
            return ''

#    def gramChunk(self):
#        """Use a cache to increase speed for the code that checks
#        patterns (Sentence.lookRight). That patterns code breaks
#        because this method appears to return None is certain
#        ill-understood cases."""
#        if not self.cachedGramChunk:
#            self._createGramChunk()
#        return self.cachedGramChunk

#    def _createGramChunk(self):
#        self.cachedGramChunk = 0

    def _hackToSolveProblemsInValue(self, value):
        if type(value) is ListType:
            if len(value) == 2 and value[0] == '' and value[1] == '':
                return [',']
            else:
                return value
        elif type(value) is StringType:
            if value == '':
                return '"'
            else:
                return value
        else:
            return value

    def _matchChunk(self, chunkDescription): 
        """Match the chunk instance to the patterns in chunkDescriptions.
        chunkDescription is a dictionary with keys-values pairs that
        match instance variables and their values on GramChunks.

        The value in key-value pairs can be:
        - an atomic value. E.g., {..., 'headForm':'is', ...} 
        - a list of possible values. E.g., {..., headForm': forms.have, ...}   
        In this case, _matchChunk checks whether the chunk feature is
        included within this list.
        - a negated value. It is done by introducing it as
        a second constituent of a 2-position tuple whose initial position
        is the caret symbol: '^'. E.g., {..., 'headPos': ('^', 'MD') ...}
        
        This method is also implemented in the chunkAnalyzer.GramChunk class """
        #sys.stderr.write("......entering _matchChunk()\n")
        #log("\nNEW PATTERN")
        for feat in chunkDescription.keys():
            #sys.stderr.write("......PAIR <"+feat+" "+str(chunkDescription[feat])+">")
            value = chunkDescription[feat]
            #log("\n\t\tPAIR <"+feat+"> <"+str(value)+">")
            #log("\t\t   and MY VALUE:"+str(self.__getattr__(feat)))
            if type(value) is TupleType:
                #print "\t\t......TUPLE TYPE"
                if value[0] == '^':
                    value = self._hackToSolveProblemsInValue(value[1])
                    #print "AQUI!\tVALUE:", type(value), "\tFEAT:", feat, "\tVAL:", self.__getattr__(feat)
                    #for item in value:
                        #print "\t\tIT>>"+str(item)+"<<"
                    if self.__getattr__(feat) in value or self.__getattr__(feat) == value:
                        #log("\t\t\tMIS")
                        return 0
                else:
                    raise "ERROR specifying description of pattern" 
            elif type(value) is ListType:
                #print "\t\t......LIST TYPE, for:", self.__getattr__(feat)
                if self.__getattr__(feat) not in value:
                    #sys.stderr.write("FEAT "+feat+" does not match (01)")
                    #log("\t\t\tMIS")
                    return 0
            else:
                #print "VALUE before", value
                value = self._hackToSolveProblemsInValue(value)
                #print "AQUI!\tVALUE:>>"+str(value)+"<<"+str(type(value))+"\tFEAT:"+str(feat)+"\tVAL:"+str(self.__getattr__(feat))
                #print "\t\t......ELSE TYPE:\tVALUE>"+value+"< FEAT FSA>"+str(self.__getattr__(feat))+"<"
                if self.__getattr__(feat) != value:#R: if chunk.__getattr__(feat) != chunkDescription[feat]:
                    #sys.stderr.write("FEAT "+feat+" does not match (02)")
                    #log("\t\t\tMIS")
                    return 0

        #log("\n\tPIECE: "+str(self.getText())+"<<")
        #log("\t\tATTRS: "+str(chunkDescription.keys()))
        #log("\t\tVALS: "+str(chunkDescription.values()))
        #log("\t\t\tMATCH")
        return 1        

class Chunk(Constituent):

    def __init__(self, phraseType):
        self.phraseType = phraseType
        self.tokenList = []
        self.tokenIndex = 0
        self.positionCount = 0
        self.position = None
        self.parent = None
        self.cachedGramChunk = 0
        self.event = None
        self.eid = None
        self.isEmbedded = 0
        self.createdLexicalSlink = 0
        
    def __len__(self):
        return len(self.tokenList)

    def __getitem__(self, index):
        return self.tokenList[index]

    def __getslice__(self, i, j):
        return self.tokenList[i:j]

    def __getattr__(self, name):
        """Used by Sentence._match. Needs cases for all instance
        variables used in the pattern matching phase."""
        if name == 'nodeType':
            return self.__class__.__name__
        elif name == 'nodeName':
            return self.phraseType
        elif name in ['eventStatus', 'text', FORM, STEM, POS, TENSE, ASPECT, NF_MORPH, MOD, POL, EVENTID, EIID, CLASS]:
            if not self.event:
                return None
            else:
                doc = self.parent.document()
                if name == 'eventStatus':
                    return '1'
                elif name == TENSE:
                    return doc.taggedEventsDict[self.eid][TENSE]
                elif name == ASPECT:
                    return doc.taggedEventsDict[self.eid][ASPECT]
                elif name == NF_MORPH:
                    return doc.taggedEventsDict[self.eid][NF_MORPH]
                elif name == MOD:
                    try: mod = doc.taggedEventsDict[self.eid][MOD]
                    except: mod = 'NONE'
                    return mod
                elif name == POL:
                    try: pol = doc.taggedEventsDict[self.eid][POL]
                    except: pol = 'POS'
                    return pol
                elif name == EVENTID:
                    return doc.taggedEventsDict[self.eid][EVENTID]
                elif name == EIID:
                    return doc.taggedEventsDict[self.eid][EIID]
                elif name == CLASS:
                    return doc.taggedEventsDict[self.eid][CLASS]
                elif name == 'text' or name == FORM:
                    return doc.taggedEventsDict[self.eid][FORM] 
                elif name == STEM:
                    return doc.taggedEventsDict[self.eid][STEM] 
                elif name == POS:
                    try:
                        return doc.taggedEventsDict[self.eid][POS] #self.token.pos
                    except:
                        return 'NONE'
        else:
            raise AttributeError, name

##    def _createMultiChunk(self, multiChunkEnd): # *** MUST GO to Chunk??
##        """Create multi-chunk: """
##        multiChunkInit = self.getTokens(self)
##        return multiChunkInit + multiChunkEnd

##    def _processEventInChunk(self, gramChunk):
##        doc = self.document()
##        if (gramChunk.head and
##            gramChunk.head.getText() not in forms.be and
##            gramChunk.evClass):
##            doc.addEvent(Event(gramChunk))
     
    def _printSequence(self, sequence, depth):          # DEBUGGING method
        """Given a sentence or a piece of it,
        print the list of chunks and tokens it contains.
        'depth' establishes the number of tabs to be printed
        for each item, in order to display it in a hierarchical manner.
        """
        for item in sequence:
            #log("ITEM type"+str(item.nodeType))
            if item.nodeType[-5:] == 'Token':
                try:
                    debug("\n"+depth*"\t"+"TOKEN: "+item.getText()+"\t"+item.pos)   # DEBUGGING
                    log(depth*"\t"+"TOKEN: "+item.getText()+"\t"+item.pos)
                except:
                    log("WARNING: possibly a NoneType here. (1)")
            elif item.nodeType[-5:] == 'Chunk':
                try:
                    debug("\n"+depth*"\t"+"CHUNK: "+item.nodeType+"\t\tEvent:"+str(item.event))    # DEBUGGING
                    log(depth*"\t"+"CHUNK: "+item.nodeType+"\t\tEvent:"+str(item.event))
                    #log(depth*"\t===>"+str(len(item)))
                    self._printSequence(item, depth+1)
                except:
                    log("WARNING: possibly a NoneType here. (2)")
            elif item.nodeType == EVENT:
                try:
                    debug("\n"+depth*"\t"+"EVENT: "+item.token.getText()+"\t"+item.token.pos)
                    log(depth*"\t"+"EVENT: "+item.text+"\t"+item.pos)
                except:
                    log("WARNING: possibly a NoneType here. (3)")
            elif item.nodeType == TIMEX:
                try:
                    debug("\n"+depth*"\t"+"TIMEX: "+item.getText())
                    log("\n"+depth*"\t"+"TIMEX: "+item.getText())
                except:
                    log("WARNING: possibly a NoneType here. (4)")
            else:
                raise "ERROR: unknown item type: "+item.nodeType


    def setEmbedded(self):
        """Keeping track of chunks embedded
        within other chunks, for parsing purposes"""
        self.isEmbedded = 1

    def resetEmbedded(self):
        self.isEmbedded = 0
        
    def startHead(self):
        pass

    def startVerbs(self):
        pass

    def endVerbs(self):
        pass
    
    def addToken(self, token):
        token.setParent(self)
        self.tokenList.append(token)
        self.positionCount += 1

    def setEventInfo(self, eid):
        self.event = 1
        self.eid = eid
        
    def getText(self):
        string = ""
        for token in self.tokenList:
            string = string+' '+str(token.getText())
        return string

    def getToken(self, sequence):
        """Given a sentence or a piece of it,
        de-chunk it and return a list of plain tokens.
        Used for mapping sentences into RegEx-based patterns.
        """
        tokensList = []
        for item in sequence:
            if item.nodeType[-5:] == 'Token':
                tokensList.append(item)
            elif item.nodeType[-5:] == 'Chunk':
                chunkTokens = self.getTokens(item)
                tokensList = tokensList + chunkTokens
            elif item.nodeType == 'EVENT':
                tokensList.append(item)
            else:
                raise "ERROR: unknown item type: "+item.nodeType
        return tokensList
    
    def _identifySubstringInSentence(self, tokenSentence, FSAset):
        fsaCounter=-1  # DEBUGGING purposes
        for fsa in FSAset:
            fsaCounter = fsaCounter + 1
            log("FSA:\n"+str(fsa))
            lenSubstring = fsa.acceptsShortestSubstringOf(tokenSentence)
            if lenSubstring:
                return (lenSubstring, fsaCounter)
        else:
            return (0, fsaCounter)

    def _lookForSlink(self, restSentence, FSA_set):
        # Eventually, if we want to merge EVITA and SLINKET common stuff,
        # this method should call self._lookForStructuralPattern(FSA_set)
        # But careful: _lookForSlink MUST return also fsaNum
        # and that will have effects on Evita code. 
        lenSubstring, fsaNum = self._identifySubstringInSentence(restSentence, FSA_set) #tokenSentence, FSA_set)
        if lenSubstring: 
            return (lenSubstring, fsaNum)   #return (tokenSentence[:lenSubstring], fsaNum)
        else:
            return 0

    def _extractQuotation(self, fragment):
        for idx in range(len(fragment)):
            if (fragment[idx].getText() == "''" and
                (fragment[idx-1].getText() == "," or
                 fragment[idx+1].getText() == ",")):
                return fragment[1:idx]
        else:
            return None
        
    def createForwardSlink(self, forwardSlinks):
        slinkedEventContext = self.parent[self.position+1:] # chunks following the currEvent
        self.createSlink(slinkedEventContext, forwardSlinks[0], forwardSlinks[1]) # forwardSlinks[0]:pattern name, forwardSlinks[1]: relType

    def createBackwardSlink(self, backwardSlinks):
        """Backward Slinks also check for the adequacy (e.g., in terms of TENSE
        or ASPECT) of the Subordinating Event. For cases such as
        'the <EVENT>transaction</EVENT> has been <EVENT>approved</EVENT>'
        """
        debug("TRYING backward slink")
        slinkedEventContext = self.parent[:self.position+1]
        slinkedEventContext.reverse()
        self.createSlink(slinkedEventContext, backwardSlinks[0], backwardSlinks[1]) 
        
    def createReportingSlink(self, reportingSlink):
        """Reporting Slinks are applied to reporting predicates ('say', 'told', etc)
        that link an event in a preceeding quoted sentence which is
        separated from the clause of the reporting event by a comma; e.g.,
            ``I <EVENT>want</EVENT> a referendum,'' Howard <EVENT class='REPORTING'>said</EVENT>.
        Slinket assumes that these quoted clauses always initiate the main sentence.
        Therefore, the first item in the sentence are quotation marks.
        """
        sentenceBeginning = self.parent[:self.position]
        if len(sentenceBeginning) > 0 and sentenceBeginning[0].getText() == "``":
            """quotation does not contain quotation marks"""
            quotation = self._extractQuotation(sentenceBeginning)
            if quotation is not None:
                log("TRYING reporting slink")
                debug("TRYING reporting slink")
                self.createSlink(quotation, reportingSlink[0], reportingSlink[1])
        
    def createSlink(self, slinkedEventContext, syntaxPatternLists, relTypeList):
        for i in range(len(syntaxPatternLists)):
            self._printSequence(slinkedEventContext, 1)   # DEBUGGING method
            substring = self._lookForSlink(slinkedEventContext, syntaxPatternLists[i])
            if substring:
                #debug("substring\n"+str(substring)+"\n")
                substringLength = substring[0]
                subpatternNum = substring[1]
                relType = relTypeList[i]
                #patterns = syntaxPatternLists[i]  # should be ith nested list in syntaxPatternLists
                #patternName = patterns[subpatternNum] # should be subpatternNumth item in the list
                patternName = syntaxPatternLists[i][subpatternNum]
                #print "PATTERNNAME: ", patternName.fsaname
                
                debug("\n"+21*"."+"ACCEPTED SLINK!!! LENGTH: "+str(substringLength)+" "+str(relType)+
                                " || FSA: "+str(i)+"."+str(subpatternNum)+" PatternName: "+patternName.fsaname)                                     # DEBUGGING
                log("\n"+21*"."+"ACCEPTED SLINK!!! LENGTH: "+str(substringLength)+" "+str(relType)+
                      " || FSA: "+str(i)+"."+str(subpatternNum))                                               # DEBUGGING

                debug("\n"+70*"*"+"\n")                                                              # DEBUGGING
                log(70*"*"+"\n")                                                                             # DEBUGGING
                self.document().addSlink(relType, self.eiid, slinkedEventContext[substringLength-1].eiid, patternName.fsaname)
                self.createdLexicalSlink = 1
                break    
            else:
                debug("\n.....................REJECTED SLINK by FSA: "+str(i)+".?")  #DEBUGGING
                log("\n.....................REJECTED SLINK by FSA: "+str(i)+".?")            # DEBUGGING
                debug("\n"+70*"*"+"\n")                                              # DEBUGGING
                log(70*"*"+"\n")                                                             # DEBUGGING

    def isChunk(self):
        return 1

    def isTimex(self):
        if self.phraseType and self.phraseType[:5] == 'TIMEX':
            return 1
        else: return 0

    def isNChHead(self):
        if self.phraseType and self.phraseType[:4] == 'HEAD':
            return 1
        else: return 0


    
class NounChunk(Chunk):

    def __init__(self, phraseType):
        Chunk.__init__(self, phraseType)
        self.head = -1
        self.poss = None

    def getHead(self):
        return self.tokenList[self.head]

    def getPoss(self):
        return self.tokenList[self.poss]

    def startHead(self):
        self.head = len(self.tokenList)

    def startPOSS(self):
        if self.tokenList:
            self.poss = len(self.tokenList)
        else:
            self.poss = 0

    def isNounChunk(self): return 1

#    def _createGramChunk(self):
#        self.cachedGramChunk = GramNChunk(self)

    def isDefinite(self):
        for token in self.tokenList[:self.head]:
            if token.pos == 'POS' or token.pos == 'PRP$':
                return True
            elif token.pos == 'DET' and token.getText() in ['the', 'this', 'that', 'these', 'those']:
                return True
            else:
                return False

        
##    def createEvent(self):
##        GramNCh = self.gramChunk()
##        GramNCh.printNChunk('(1)')
##        # Even if preceded by a BE or a HAVE form,
##        # only tagging N Chunks headed by an eventive noun
##        # E.g., "was an intern" will NOT be tagged
##        if GramNCh.isEventCandidate_Syn() and GramNCh.isEventCandidate_Sem():
##            self._processEventInChunk(GramNCh)
##
##        # some initial testing for the look ahead code
##        #descs = []
##        #descs.append({'class':"OCCURRENCE"})
##        #self.parent.lookRight(self.position,descs)

        
class VerbChunk(Chunk):

    def __init__(self, phraseType):
        Chunk.__init__(self, phraseType)
        self.verbs = [-1,-1]
        
    def getVerbs(self):
        return self.tokenList[self.verbs[0]:self.verbs[1]]

    def startVerbs(self):
        self.verbs[0] = len(self.tokenList)
        
    def endVerbs(self):
        self.verbs[1] = len(self.tokenList) -1

    def isVerbChunk(self): return 1

#    def _createGramChunk(self):
#        self.cachedGramChunk = GramVChunk(self)

    def _updatePositionInSentence(self, endPosition):
        pass

##    def _updateFlagCheckedForEvents(self, multiChunkEnd):
##        """Update Position in sentence, by marking as already checked for EVENT
##        upcoming Tokens and Chunks that are included in multi-chunk """
##        for item in multiChunkEnd:
##            item.setFlagCheckedForEvents()
                
##    def _lookForMultiChunk(self, FSA_set):
##        tokenSentence = self.getTokens(self.parent[self.position+1:])
##        for item in tokenSentence: print "\t "+item.getText()+"\t"+item.pos     # DEBUGGING
##        lenSubstring, fsaNum = self._identifySubstringInSentence(tokenSentence, FSA_set)
##        if lenSubstring: 
##            print "\n.....................ACCEPTED!!! LENGTH:", lenSubstring, "FSA:", fsaNum  # DEBUGGING
##            print 70*"*", "\n"
##            return tokenSentence[:lenSubstring]
##        else:
##            print "\n.....................REJECTED by FSA:", fsaNum  #DEBUGGING
##            print 70*"*", "\n"
##            return 0
            
####    def _lookForMultiChunk(self, FSA_set):
####        return self._lookForStructuralPattern(FSA_set)
        
####    def _lookForStructuralPattern(self, FSA_set):
####        tokenSentence = self.getTokens(self.parent[self.position+1:])
####        for item in tokenSentence: print "\t "+item.getText()+"\t"+item.pos     # DEBUGGING
####        lenSubstring, fsaNum = self._identifySubstringInSentence(tokenSentence, FSA_set)
####        if lenSubstring: 
####            print "\n.....................ACCEPTED!!! LENGTH:", lenSubstring, "FSA:", fsaNum  # DEBUGGING
####            print 70*"*", "\n"
####            return tokenSentence[:lenSubstring]
####        else:
####            print "\n.....................REJECTED by FSA:", fsaNum  #DEBUGGING
####            print 70*"*", "\n"
####            return 0
            
##    def _processEventInMultiVChunk(self, substring):   # *** There should be a version for NounMultiChunk as well
##        GramMultiVChunk = GramVChunk(self._createMultiChunk(substring))
##        GramMultiVChunk.printVChunk('3')  # DEBUGGING
##        self._processEventInChunk(GramMultiVChunk)  #*** make processEventInChunk in GramChunks???
##        self._updateFlagCheckedForEvents(substring)
        
##    def createEvent(self):
##        GramVCh = self.gramChunk()
##        if GramVCh.nodeIsNotEventCandidate():
##            pass
        
##        elif GramVCh.nodeIsModalForm(self.nextNode()): 
##            print "\nEntering checking for modal pattern............\n"
##            substring = self._lookForMultiChunk(MODAL_FSAs)
##            if substring:
##                self._processEventInMultiVChunk(substring)

##        elif GramVCh.nodeIsBeForm(self.nextNode()): 
##            print "\nEntering checking for toBe pattern............\n"
##            substring = self._lookForMultiChunk(BE_FSAs)
##            if substring:
##                self._processEventInMultiVChunk(substring)
            
##        elif GramVCh.nodeIsHaveForm():
##            print "\nEntering checking for toHave pattern............\n"
##            substring = self._lookForMultiChunk(HAVE_FSAs)
##            if substring:
##                self._processEventInMultiVChunk(substring)
##            else:
##                self._processEventInChunk(GramVCh)
            
##        elif GramVCh.nodeIsFutureGoingTo(): 
##            print "\nEntering checking for futureGoingTo pattern............\n"
##            substring = self._lookForMultiChunk(GOINGto_FSAs)
##            if substring:
##                self._processEventInMultiVChunk(substring)
##            else:
##                self._processEventInChunk(GramVCh)

##        elif GramVCh.nodeIsPastUsedTo(): 
##            print "\nEntering checking for pastUsedTo pattern............\n"
##            substring = self._lookForMultiChunk(USEDto_FSAs)
##            if substring:
##                self._processEventInMultiVChunk(substring)
##            else:
##                self._processEventInChunk(GramVCh)
                
##        elif GramVCh.nodeIsDoAuxiliar(): 
##            print "\nEntering checking for doAuxiliar pattern............\n"
##            substring = self._lookForMultiChunk(DO_FSAs)
##            if substring:
##                self._processEventInMultiVChunk(substring)
##            else:
##                self._processEventInChunk(GramVCh)
##        else:
##            GramVCh.printVChunk('(1)')      # DEBUGGING
##            self._processEventInChunk(GramVCh)
        
            
class Token(Constituent):
    
    def __init__(self, document, pos):
        self.pos = pos
        self.textIdx = []
        self.document = document
        self.position = None
        self.parent = None
        self.cachedGramChunk = 0
        
    def __getitem__(self, index):
        if index == 0:
            return self
        else:
            raise IndexError("list index out of range")
            
    def __len__(self):
        return 1

    def __getattr__(self, name):
        """Used by Sentence._match. Needs cases for all instance
        variables used in the pattern matching phase."""
        if name == 'nodeType':
            return self.__class__.__name__
        elif name == 'text':
            return self.getText()
        elif name == 'pos':
            return self.pos
        elif name in ['eventStatus', FORM, STEM, TENSE, ASPECT, NF_MORPH, MOD, POL, EVENTID, EIID, CLASS]:
            return None
        else:
            raise AttributeError, name

    def setTextNode(self, docLoc):
        self.textIdx = docLoc
        
    def getText(self):
        return self.document.nodeList[self.textIdx]

    def document(self):
        """For some reason, tokens have a document variable. Use this
        variable and avoid looking all the way up the tree"""
        return self.document
    
    def isToken(self): return 1

                
class AdjectiveToken(Token):

    def createEvent(self):
        pass    ##
##        """ only for tokens that are not in a chunk"""
##        if not self.parent.__class__.__name__ == 'Sentence':
##            return


