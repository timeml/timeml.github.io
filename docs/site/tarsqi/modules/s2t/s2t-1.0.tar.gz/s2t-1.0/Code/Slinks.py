from debugging import debug, log
from xmlParser import allSlinks, allEvents, allInstances, newTlinks, allAlinks, allTlinks


class Slinks:
    def __init__(self, doc, idx, attrs):
        self.doc = doc
        self.index = idx
        self.attrs = attrs
        self.eventInstance = allInstances[self.attrs['eventInstanceID']]
        self.subEventInstance = allInstances[self.attrs['subordinatedEventInstance']]



    def lookForStlinks(self, index):
        """Examine each slink in the document.  If candidateForStlinking is true, call createStlink."""
        if candidateForStlinking(self):
            debug("STLINK!")
            createStlink(self)
        else:
            debug("Not a stlink Candidate")


def candidateForStlinking(stlinkCandidate):
    """Returns true if relType is either EVIDENTIAL or FACTIVE"""
    if stlinkCandidate.attrs['relType'] == 'EVIDENTIAL':
        return 1
    elif stlinkCandidate.attrs['relType'] == 'FACTIVE':
        return 1
    elif stlinkCandidate.attrs['relType'] == 'MODAL':
        return 1
    else:
        return 0


def createStlink(slink):
    """Calls createTlink based on the tense/aspect of the events in the slink"""
    debug("SLINK relType: " + slink.attrs['relType'])
    #debug("SLINK syntax: " + slink.attrs['syntax'])
    debug("Event Information:")
    debug("   ID: " + slink.attrs['eventInstanceID'])
    debug("   Event Tense: " + slink.eventInstance.attrs['tense'])
    debug("   Event Aspect: " + slink.eventInstance.attrs['aspect'])
    debug("   Event Morphology: " + slink.eventInstance.attrs['pos'])
    debug("   Event Polarity: " + slink.eventInstance.attrs['polarity'])
    if 'modality' in slink.eventInstance.attrs:
        debug("   Event Modality: " + slink.eventInstance.attrs['modality'])
    debug("Subevent Information:")
    debug("   ID: " + slink.attrs['subordinatedEventInstance'])
    debug("   Subevent Tense: " + slink.subEventInstance.attrs['tense'])
    debug("   Subevent Aspect: " + slink.subEventInstance.attrs['aspect'])
    debug("   Subevent Morphology: " + slink.subEventInstance.attrs['pos'])
    debug("   Subevent Polarity: " + slink.subEventInstance.attrs['polarity'])
    if 'modality' in slink.subEventInstance.attrs:
        debug("   Subevent Modality: " + slink.subEventInstance.attrs['modality'])
###
    if slink.eventInstance.attrs['tense'] == 'PAST' and slink.subEventInstance.attrs['tense'] == 'PRESENT':
        createTlink(slink, 1) # BEFORE
    elif slink.eventInstance.attrs['tense'] == 'PAST' and slink.subEventInstance.attrs['tense'] == 'FUTURE':
        createTlink(slink, 2) # BEFORE
    elif slink.eventInstance.attrs['tense'] == 'PAST' and slink.subEventInstance.attrs['tense'] == 'PAST':
        createTlink(slink, 3) # AFTER
    elif slink.eventInstance.attrs['tense'] == 'PRESENT' and slink.subEventInstance.attrs['tense'] == 'PRESENT' and slink.subEventInstance.attrs['aspect'] == 'PERFECTIVE':
        createTlink(slink, 4) # AFTER
    elif slink.eventInstance.attrs['tense'] == 'PRESENT' and slink.eventInstance.attrs['aspect'] == 'PERFECTIVE' and slink.subEventInstance.attrs['tense'] == 'FUTURE':
        createTlink(slink, 5) # BEFORE
    elif slink.eventInstance.attrs['tense'] == 'PRESENT' and slink.subEventInstance.attrs['tense'] == 'PAST':
        createTlink(slink, 6) # AFTER
    elif slink.eventInstance.attrs['tense'] == 'PRESENT' and slink.subEventInstance.attrs['tense'] == 'FUTURE':
        createTlink(slink, 7) # BEFORE
    elif slink.eventInstance.attrs['tense'] == 'PRESENT' and slink.subEventInstance.attrs['tense'] == 'PRESENT' and slink.subEventInstance.attrs['aspect'] == 'PROGRESSIVE':
        createTlink(slink, 8) # BEFORE
    elif slink.attrs['relType'] == 'FACTIVE':
        createTlink(slink, 9) # AFTER (default for Factive)
    elif slink.attrs['relType'] == 'MODAL':
        createTlink(slink, 10) # BEFORE (default for Modal)
    elif slink.subEventInstance.attrs['aspect'] == 'PERFECTIVE':
        createTlink(slink, 11) # AFTER
    elif not ((slink.eventInstance.attrs['tense'] == 'NONE' and slink.eventInstance.attrs['aspect'] == 'NONE') or (slink.subEventInstance.attrs['tense'] == 'NONE' and slink.subEventInstance.attrs['aspect'] == 'NONE')):
        debug("EXAMINE")
    else:
        debug("DO NOTHING")

def createTlink(slink, ruleNum):
    #print "ALLSLINKS: " + str(allSlinks.keys())
    #print "NEWTLINKS: " + str(newTlinks.keys())
    if ruleNum == 1:
        #debug(slink.attrs)
        debug("Rule Number: " + str(ruleNum))
        debug("CREATE A TLINK WITH THE FOLLOWING:")
        debug("reltype: BEFORE ")
        debug("eventInstanceID: " + slink.attrs['eventInstanceID'])
        debug(" relatedToEventInstance: " + slink.attrs['subordinatedEventInstance'])
        slink.doc.document().addTlink('BEFORE', slink.attrs['eventInstanceID'], slink.attrs['subordinatedEventInstance'], allAlinks, allSlinks, allTlinks, 'S2T')
    elif ruleNum == 2:
        debug("Rule Number: " + str(ruleNum))
        debug("CREATE A TLINK WITH THE FOLLOWING:")
        debug("reltype: BEFORE ")
        debug("eventInstanceID: " + slink.attrs['eventInstanceID'])
        debug(" relatedToEventInstance: " + slink.attrs['subordinatedEventInstance'])
        slink.doc.document().addTlink('BEFORE', slink.attrs['eventInstanceID'], slink.attrs['subordinatedEventInstance'], allAlinks, allSlinks, allTlinks, 'S2T')
    elif ruleNum == 3:
        debug("RuleNumber: " + str(ruleNum))
        debug("CREATE A TLINK WITH THE FOLLOWING:")
        debug("reltype: AFTER ")
        debug("eventInstanceID: " + slink.attrs['eventInstanceID'])
        debug(" relatedToEventInstance: " + slink.attrs['subordinatedEventInstance'])
        slink.doc.document().addTlink('AFTER', slink.attrs['eventInstanceID'], slink.attrs['subordinatedEventInstance'], allAlinks, allSlinks, allTlinks, 'S2T')
    elif ruleNum == 4:
        debug("RuleNumber: " + str(ruleNum))
        debug("CREATE A TLINK WITH THE FOLLOWING:")
        debug("reltype: AFTER ")
        debug("eventInstanceID: " + slink.attrs['eventInstanceID'])
        debug(" relatedToEventInstance: " + slink.attrs['subordinatedEventInstance'])
        slink.doc.document().addTlink('AFTER', slink.attrs['eventInstanceID'], slink.attrs['subordinatedEventInstance'], allAlinks, allSlinks, allTlinks, 'S2T')
    elif ruleNum == 5:
        debug("Rule Number: " + str(ruleNum))
        debug("CREATE A TLINK WITH THE FOLLOWING:")
        debug("reltype: BEFORE ")
        debug("eventInstanceID: " + slink.attrs['eventInstanceID'])
        debug(" relatedToEventInstance: " + slink.attrs['subordinatedEventInstance'])
        slink.doc.document().addTlink('BEFORE', slink.attrs['eventInstanceID'], slink.attrs['subordinatedEventInstance'], allAlinks, allSlinks, allTlinks, 'S2T')
    elif ruleNum == 6:
        debug("RuleNumber: " + str(ruleNum))
        debug("CREATE A TLINK WITH THE FOLLOWING:")
        debug("reltype: AFTER ")
        debug("eventInstanceID: " + slink.attrs['eventInstanceID'])
        debug(" relatedToEventInstance: " + slink.attrs['subordinatedEventInstance'])
        slink.doc.document().addTlink('AFTER', slink.attrs['eventInstanceID'], slink.attrs['subordinatedEventInstance'], allAlinks, allSlinks, allTlinks, 'S2T')
    elif ruleNum == 7:
        debug("RuleNumber: " + str(ruleNum))
        debug("CREATE A TLINK WITH THE FOLLOWING:")
        debug("reltype: BEFORE ")
        debug("eventInstanceID: " + slink.attrs['eventInstanceID'])
        debug(" relatedToEventInstanc: " + slink.attrs['subordinatedEventInstance'])
        slink.doc.document().addTlink('BEFORE', slink.attrs['eventInstanceID'], slink.attrs['subordinatedEventInstance'], allAlinks, allSlinks, allTlinks, 'S2T')
    elif ruleNum == 8:
        debug("RuleNumber: " + str(ruleNum))
        debug("CREATE A TLINK WITH THE FOLLOWING:")
        debug("reltype: BEFORE ")
        debug("eventInstanceID: " + slink.attrs['eventInstanceID'])
        debug(" relatedToEventInstanc: " + slink.attrs['subordinatedEventInstance'])
        slink.doc.document().addTlink('BEFORE', slink.attrs['eventInstanceID'], slink.attrs['subordinatedEventInstance'], allAlinks, allSlinks, allTlinks, 'S2T')
    elif ruleNum == 9:
        debug("RuleNumber: " + str(ruleNum))
        debug("CREATE A TLINK WITH THE FOLLOWING:")
        debug("reltype: AFTER ")
        debug("eventInstanceID: " + slink.attrs['eventInstanceID'])
        debug(" relatedToEventInstanc: " + slink.attrs['subordinatedEventInstance'])
        slink.doc.document().addTlink('BEFORE', slink.attrs['eventInstanceID'], slink.attrs['subordinatedEventInstance'], allAlinks, allSlinks, allTlinks, 'S2T')
    elif ruleNum == 10:
        debug("RuleNumber: " + str(ruleNum))
        debug("CREATE A TLINK WITH THE FOLLOWING:")
        debug("reltype: BEFORE ")
        debug("eventInstanceID: " + slink.attrs['eventInstanceID'])
        debug(" relatedToEventInstanc: " + slink.attrs['subordinatedEventInstance'])
        slink.doc.document().addTlink('BEFORE', slink.attrs['eventInstanceID'], slink.attrs['subordinatedEventInstance'], allAlinks, allSlinks, allTlinks, 'S2T')
    elif ruleNum == 11:
        debug("RuleNumber: " + str(ruleNum))
        debug("CREATE A TLINK WITH THE FOLLOWING:")
        debug("reltype: AFTER ")
        debug("eventInstanceID: " + slink.attrs['eventInstanceID'])
        debug(" relatedToEventInstance: " + slink.attrs['subordinatedEventInstance'])
        slink.doc.document().addTlink('AFTER', slink.attrs['eventInstanceID'], slink.attrs['subordinatedEventInstance'], allAlinks, allSlinks, allTlinks, 'S2T')
    else:
        pass










