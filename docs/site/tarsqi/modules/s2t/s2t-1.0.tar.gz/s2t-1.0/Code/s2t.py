import os, sys, string, time
from debugging import debug, log
import xmlParser
from Alinks import Alinks
from Slinks import Slinks

# set this to the empty string if you want no extension added
FILE_EXTENSION = '.s2t'

def process(fileIn, fileOut):
    print "A2T: processingfile ", fileIn
    try:
        doc = s2tParser(fileIn, '')
        doc.builda2tlinks()
        doc.doc.printOut(fileOut)
    except:
        print "A2T Error in process(fileIn, $fileOut)"

def processDirectory(dirName):
    fileList = os.listdir(dirName)
    os.chdir(dirName)
    for fileName in fileList:
        print "  " + os.getcwd() + '/' + fileName
        debug("  " + os.getcwd() + '/' + fileName)
        parser = s2tParser(fileName, OUT + '/' + fileName + FILE_EXTENSION )
        processFile(infilePath, outfilePath)
        #parser.createTLinksFromSLinks()
        #parser.createTLinksFromALinks()
        #parser.printResults()

def processFile(filePath, outFile):
    debug("FILENAME: "+filePath)
    filePathList = string.split(filePath, '/')
    DIR_input = string.join(filePathList[:-1], '/')
    fileName = filePathList[-1]
    if DIR_input:
        os.chdir(DIR_input)
    try:
        parser = s2tParser(fileName, outFile)
    	parser.createTLinksFromSLinks()
    	parser.createTLinksFromALinks()
    	parser.printResults()
    except:
        sys.stderr.write("WARNING: error processing " + filename + "\n")
        sys.stderr.write("  " + str(sys.exc_type) + "\n")
        sys.stderr.write("  " + str(sys.exc_value) + "\n")
        shutil.copy(infile, outfile)



class s2tParser:

    def __init__(self, doc, OUT):
        self.doc = xmlParser.readFileWithEvents(doc)
        self.events = xmlParser.allEvents
        self.instances = xmlParser.allInstances
        self.slinks = xmlParser.allSlinks
        self.alinks = xmlParser.allAlinks
        self.tlinks = xmlParser.allTlinks
        self.a2tlinks = xmlParser.newTlinks
        #self.outFileName = OUT+self.doc.sourceFileName+".s2t_a2t"
        self.outFileName = OUT

    def createTLinksFromALinks(self):
        log("...Printingfile will be: "+self.outFileName)
        log("\nNUM of ALINKs in file: "+str(len(self.alinks)))
        debug("Number of ALINKs: " + str(len(self.alinks)))
        for idx in range(len(self.alinks)):
            alinkList = []
            alinkList = self.alinks.keys()
            try:
                CurrentAlink = Alinks(self.doc, idx, self.alinks[alinkList[idx]].attrs)
                CurrentAlink.lookFora2tlinks(idx)
            except:
                print "Error processing ALINK"

    def createTLinksFromSLinks(self):
        log("...Printingfile will be: "+self.outFileName)
        log("\nNUM of slinks in file: "+str(len(self.slinks)))
        debug("Number of Slinks: " + str(len(self.slinks)))
        for idx in range(len(self.slinks)):
            slinkList = []
            slinkList = self.slinks.keys()
            try:
                CurrentSlink = Slinks(self.doc, idx, self.slinks[slinkList[idx]].attrs)
                CurrentSlink.lookForStlinks(idx)
            except:
                print "Error processing SLINK"

    def printResults(self):
        self.doc.printOut(self.outFileName)
        

            
if __name__ == '__main__':

    a = time.time()
    print "Entering S2T ......................."
    
    if len(sys.argv) > 2:
        IN = os.path.abspath(sys.argv[1])
        OUT = os.path.abspath(sys.argv[2])
    else:
        sys.exit("Error, need two arguments, exiting...");

    if os.path.isdir(IN):
        print "Processing Directory " + IN
        processDirectory(IN)
    else:
        print "Processing file " + IN
        processFile(IN,OUT)

    b = time.time()
    print "Time:", (b - a)/60., "minutes"
