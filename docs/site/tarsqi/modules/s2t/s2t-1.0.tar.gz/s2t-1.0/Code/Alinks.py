from debugging import debug, log
from xmlParser import allAlinks, allTlinks, newTlinks, allSlinks

class Alinks:
    def __init__(self, doc, idx, attrs):
        self.doc = doc
        self.index = idx
        self.attrs = attrs


    def lookFora2tlinks(self, index):
        """Examine each ALINK in the document. If candidateForA2T is true, call createa2tlink."""
        if candidateForA2T(self):
            debug("A2T relType! " + self.attrs['lid'] + " " + self.attrs['relType'])
            #createa2tlink(self)
            patternTest(self)
        else:
            debug("Not an A2T relType: " + self.attrs['lid'] + " " + self.attrs['relType'])


def candidateForA2T(a2tCandidate):
    if a2tCandidate.attrs['relType'] == 'INITIATES':
        return 1 # continue test to check pattern   
    elif a2tCandidate.attrs['relType'] == 'CULMINATES':
        return 1
    elif a2tCandidate.attrs['relType'] == 'TERMINATES':
        return 1
    else:
        return 0


def patternTest(a2tCandidate):
    """Loop through TLINKs to match A2T pattern"""
    debug("ALINK Properties:")
    debug(a2tCandidate.attrs['lid'] + " " + a2tCandidate.attrs['eventInstanceID'] + " " + a2tCandidate.attrs['relatedToEventInstance'] + " " + a2tCandidate.attrs['relType'])
    tlinkList = []
    tlinkList = allTlinks.keys()
    
    for idx in tlinkList:
        tlink = allTlinks[idx]
        debug("Current TLINK ID: " + tlink.attrs['lid'])
        if 'relatedToTime' not in tlink.attrs and 'timeID' not in tlink.attrs:
            if a2tCandidate.attrs['eventInstanceID'] == tlink.attrs['eventInstanceID']:
                #debug(tlink.attrs['relatedToEventInstance'])
                #debug(a2tCandidate.attrs['eventInstanceID'])
                debug("Matched TLINK Properties:")
                debug(tlink.attrs['lid'] + " " + tlink.attrs['eventInstanceID'] + " " + tlink.attrs['relatedToEventInstance'] + " " + tlink.attrs['relType'])
                createa2tlink(a2tCandidate, tlink, 1)
            elif a2tCandidate.attrs['eventInstanceID'] == tlink.attrs['relatedToEventInstance']:
                debug("HERE")
                debug("Matched TLINK Properties:")
                debug(tlink.attrs['lid'] + " " + tlink.attrs['eventInstanceID'] + " " + tlink.attrs['relatedToEventInstance'] + " " + tlink.attrs['relType'])
                createa2tlink(a2tCandidate, tlink, 2)
            else:
                debug("No TLINK match")
        else:
            debug("TLINK with Time, no match")





def createa2tlink(alink, tlink, patternNum):
    #print "Do something!"
    if patternNum == 1:
        debug("Pattern Number: " + str(patternNum))
        alink.doc.document().addTlink(tlink.attrs['relType'], alink.attrs['relatedToEventInstance'], tlink.attrs['relatedToEventInstance'], allAlinks, allTlinks, allSlinks, 'A2T')
    elif patternNum == 2:
        debug("Pattern Number: " + str(patternNum))
        alink.doc.document().addTlink(tlink.attrs['relType'], tlink.attrs['eventInstanceID'], alink.attrs['relatedToEventInstance'], allAlinks, allTlinks, allSlinks, 'A2T')




