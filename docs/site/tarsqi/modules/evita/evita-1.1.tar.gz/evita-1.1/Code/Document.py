import sys
from forms import DEBUG

class Document:
    def __init__(self, fileName):
        self.nodeList = []
        self.sentenceList = []
        self.nodeCounter = 0
        self.sourceFileName = fileName
        self.eventDict = {}
        self.signalDict = {}   
        self.instanceCounter = 0
        self.insertDict = {}
        self.addHeader()
        self.eventCount = 0
        self.positionCount = 0
        
    def addDocNode(self, string):
        self.nodeList.insert(self.nodeCounter, string)
        self.nodeCounter = self.nodeCounter + 1 
        
    def addSentence(self, sentence):
        sentence.setParent(self)
        self.sentenceList.append(sentence)
        self.positionCount += 1
        
    def __len__(self):
        return len(self.sentenceList)
        
    def __getitem__(self, index):
        return self.sentenceList[index]
        
    def __getslice__(self, i, j):
        return self.sentenceList[i:j]

    def document(self):
        return self

    def addEvent(self, event):
        event.attrs["eid"] = self.getNextEventID()
        startLoc = event.tokenList[0].text #- 1:  now EVENT tag is inside lex tag
        endLoc = event.tokenList[-1].text + 1 #+ 2: now EVENT tag is inside lex tag
        self.insertNode(startLoc, startElementString("EVENT", event.attrs))
        self.insertNode(endLoc, endElementString("EVENT"))
        instLoc = endLoc
        for instance in event.instanceList:
            instance.attrs["eiid"] = self.getNextInstanceID()
            instance.attrs["eventID"] = event.attrs["eid"]
            instLoc = instLoc + 1
            self.insertNode(instLoc, emptyContentString("MAKEINSTANCE", instance.attrs))

    def getNextEventID(self):
        self.eventCount = self.eventCount + 1
        return "e"+str(self.eventCount) 
        
    def getNextInstanceID(self):
        self.instanceCounter = self.instanceCounter + 1 
        return "ei"+str(self.instanceCounter)


    def insertNode(self, nodeNo, string):
        if self.insertDict.has_key(nodeNo):
            if DEBUG: print "WARNING: already have tag for node: "+str(nodeNo)+" "+string
            self.insertDict[nodeNo] = string
        else:
            self.insertDict[nodeNo] = string
    
    def insertEventsInText(self): 
        for event in self.eventDict.values():
            startLoc = event.tokenList[0].text - 1
            endLoc = event.tokenList[-1].text + 2
            self.insertNode(startLoc, startElementString("EVENT", event.attrs))
            self.insertNode(endLoc, endElementString("EVENT"))
            instLoc = endLoc
            for instance in event.instanceList:
                instLoc = instLoc + 1
                self.insertNode(instLoc, emptyContentString("MAKEINSTANCE", instance.attrs))
                
        
    def insertSignalsInText(self):                               
        for signal in self.signalDict.values():                  
            startLoc = signal.tokenList[0].text - 1              
            endLoc = signal.tokenList[-1].text + 2
            self.insertNode(startLoc, startElementString("SIGNAL", signal.attrs))  
            self.insertNode(endLoc, endElementString("SIGNAL"))  
            instLoc = endLoc                                     
    
    
    def addHeader(self):
        decString = '<?xml version="1.0" ?>'
        self.addDocNode(decString)
        # Assume we already have a TimeML document, don't add these (MV)
        #rootDict = {
        #    'xmlns:xsi': 'http://www.w3.org/2001/XMLSchema-instance', 
        #    'xsi:noNamespaceSchemaLocation': 'http://www.timeml.org/timeMLdocs/TimeML.xsd'
        #    }
        #rootStart= startElementString('TimeML', rootDict)
        #self.addDocNode(rootStart)
        #self.addDocNode("\n")
    
    def printOut(self, fileName = "STDOUT"):
        outFileName = fileName
        if outFileName == "STDOUT":
            file = sys.stdout
        else:
            file = open(outFileName, "w")
            #print "...Printing to file:", outFileName
        #self.insertEventsInText()
        #self.insertSignalsInText()               
        rootEnd = endElementString("TimeML")
        for i in range(len(self.nodeList)):
            if self.insertDict.has_key(i):
                file.write(self.insertDict[i])
            file.write(self.nodeList[i])
        # Don't add another closing timeml (MV)
        # file.write(rootEnd) 
        self.insertDict = {}

def endElementString(name):
    return '</'+name+'>'

def startElementString(name, attrs):
    string = '<'+name
    for att in attrs.items():
        name = att[0]
        value = att[1]
        if not (name is None or value is None):
            string = string+' '+name+'="'+value+'"'
    string = string+'>' 
    return string

def emptyContentString(name, attrs):
    string = '<'+name
    for att in attrs.items():
        name = att[0]
        value = att[1]
        if not (name is None or value is None):
            string =string+' '+name+'="'+value+'"' 
    string = string+'/>' 
    return string
