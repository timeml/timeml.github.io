#!/usr/bin/python

"""
USAGE:    python evita.py IN_FILE OUT_FILE
       or
          python evita.py IN_DIR OUT_DIR

  Run Evita on file IN_FILE or on all files in IN_DIR.
  Write output to a file OUT_FILE or to a directory OUT_DIR.
  Files created from a directory have a .events extension.
  The output directory needs to exist before executing this script.
"""

NAME = "EVITA"
VERSION = "1.0"
FILE_EXTENSION = "events"

import sys, os, time

a = time.time()

def print_help_message():
    sys.stderr.write(__doc__+"\n")
    sys.exit()
    
def areBothFiles(i,o):
    if os.path.isfile(i) and not os.path.isdir(o):
        return 1
    else: return 0
    
def areBothDirs(i,o):
    if os.path.isdir(i) and os.path.isdir(o):
        return 1
    else: return 0

def areBothSameType(i,o):
    if areBothDirs(i,o):
        return 1
    elif areBothFiles(i,o):
        return 1
    else: return 0

    
# .........................
# CALLING BY process METHOD 
# .........................

def process(inName, outName):
    c = time.time()

    inFile = os.path.abspath(inName)
    outFile = os.path.abspath(outName)
    if not areBothFiles(inFile, outFile):
        sys.stderr.write("\nERROR: IN and OUT should be both files\nMake sure IN is an existing file.\n\n")
        sys.exit()
        
    from forms import PATTERNS

    PATTERNS.loadPatterns()

    processFile(inFile,outFile)

    d = time.time()
    print NAME + ": time was " + str(d - c) + " seconds\n" 

    
# .........................
# CALLING AS __main__
# .........................

# check arguments before loading all the modules


if __name__ == '__main__':
    if (len(sys.argv) < 3):
        print_help_message()
    IN = os.path.abspath(sys.argv[1])
    OUT = os.path.abspath(sys.argv[2])
    if not areBothSameType(IN, OUT):
        print_help_message()

        
# now continue with the real work

import string, shutil
import ppParser
from forms import DEBUG
from chunkAnalyzer import getWordList, getPOSList

def debug(string):
    if DEBUG: print string

def processDirectory(indir,outdir):
    print NAME + ": processing directory " + indir
    indirPath = os.path.abspath(indir)
    outdirPath = os.path.abspath(outdir)
    fileList = os.listdir(indirPath)
    for fileName in fileList:
            infilePath = indirPath + os.sep + fileName
            outfilePath = outdirPath + os.sep + fileName + "." + FILE_EXTENSION
            processFile(infilePath, outfilePath)

def processFile(infile, outfile):
    filename = string.split(infile, os.sep)[-1]
    if filename[-6:] == FILE_EXTENSION:
        sys.stderr.write("\nERROR: IN should not have .events extension\n\n")
        sys.exit()
    print NAME + ": processing file " + filename
    try:
        doc = ppParser.parseFile(infile)
        extractEvents(doc)
        doc.printOut(outfile)
    except:
        sys.stderr.write("WARNING: error processing " + filename + "\n")
        sys.stderr.write("  " + str(sys.exc_type) + "\n")
        sys.stderr.write("  " + str(sys.exc_value) + "\n")
        shutil.copy(infile, outfile)

def extractEvents(doc):
    debug("EVENTS_FILE: " + doc.sourceFileName)
    for sentence in doc:
        debug("\n>>> SENTENCE:" + str(getWordList(sentence)))
        for node in sentence:
            debug("\n>>> NODE:" + str(getWordList(node)) + str(getPOSList(node)));
            debug("FLAG:" + str(node.flagCheckedForEvents))
            if not node.flagCheckedForEvents:
                try:
                    node.createEvent()
                except:
                    debug("WARNING: error when creating event for this node")
            else:
                debug("PASSING, already checked!")


    
if __name__ == '__main__':
    from forms import PATTERNS
    PATTERNS.loadPatterns()
    if os.path.isdir(IN):
        processDirectory(IN,OUT)
    elif os.path.isfile(IN):
        processFile(IN,OUT)
    b = time.time()
    print NAME + ": time was " + str(b - a) + " seconds\n" 
