import cPickle, os, os.path, sys


if  os.path.abspath(os.path.dirname(sys.argv[0]))[-5:] == "evita":
    DIR_PATTERNS = os.path.join(os.path.abspath(os.path.dirname(sys.argv[0])), "/Patterns/")
elif os.path.abspath(os.path.dirname(sys.argv[0]))[-4:] == "Code":
    DIR_PATTERNS = os.path.abspath(os.path.dirname(sys.argv[0]))+'/Patterns/'
else:
    DIR_PATTERNS = os.path.abspath(os.path.dirname(sys.argv[0]))+'/evita/Patterns/'    


class CompiledPatterns:
    
    def loadPatterns(self):
        self.HAVE_FSAs = cPickle.load(open(DIR_PATTERNS+"HAVE_FSAs.pickle"))
        self.MODAL_FSAs = cPickle.load(open(DIR_PATTERNS+"MODAL_FSAs.pickle"))
        self.BE_N_FSAs = cPickle.load(open(DIR_PATTERNS+"BE_N_FSAs.pickle"))
        self.BE_A_FSAs = cPickle.load(open(DIR_PATTERNS+"BE_A_FSAs.pickle"))
        self.BE_FSAs = cPickle.load(open(DIR_PATTERNS+"BE_FSAs.pickle"))
        self.GOINGto_FSAs = cPickle.load(open(DIR_PATTERNS+"GOINGto_FSAs.pickle"))
        self.USEDto_FSAs = cPickle.load(open(DIR_PATTERNS+"USEDto_FSAs.pickle"))
        self.DO_FSAs = cPickle.load(open(DIR_PATTERNS+"DO_FSAs.pickle"))
        self.BECOME_A_FSAs = cPickle.load(open(DIR_PATTERNS+"BECOME_A_FSAs.pickle"))
        self.CONTINUE_A_FSAs = cPickle.load(open(DIR_PATTERNS+"CONTINUE_A_FSAs.pickle"))
        self.KEEP_A_FSAs = cPickle.load(open(DIR_PATTERNS+"KEEP_A_FSAs.pickle"))
       
