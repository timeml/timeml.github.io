import string, sys
import forms
#from timeMLspec import *
from Event import Event
from chunkAnalyzer import GramNChunk, GramAChunk, GramVChunkList  
from types import ListType, TupleType
#from patterns import HAVE_FSAs, BE_FSAs, BE_N_FSAs, BE_A_FSAs, BECOME_A_FSAs, CONTINUE_A_FSAs, KEEP_A_FSAs, GOINGto_FSAs, MODAL_FSAs, USEDto_FSAs, DO_FSAs


def debug(string):
    if forms.DEBUG: print string
    

class Constituent:
    """An abstract class that contains some methods that are identical
    for Chunks and Tokens plus a couple of default methods."""

    def setParent(self, parent):
        self.parent = parent
        self.position = parent.positionCount

    def document(self):
        return self.parent.document()

    def isToken(self): return 0
    def isAdjToken(self): return 0
    def isChunk(self): return 0
    def isVerbChunk(self): return 0
    def isNounChunk(self): return 0
    def isAdjChunk(self): return 0
    def isTimex(self): return 0
    def isNChHead(self): return 0

    def __getattr__(self, name):
        """Used by node._matchChunk. Needs cases for all instance
        variables used in the pattern matching phase."""
        if name == 'nodeType':
            return self.__class__.__name__
        elif name == 'text':
            return None
        elif name == 'pos':
            return None        
        else:
            raise AttributeError, name

    def setFlagCheckedForEvents(self):
        if self.parent.__class__.__name__ == 'Sentence':
            if not self.flagCheckedForEvents:
                self.flagCheckedForEvents = 1
        else:
            self.parent.setFlagCheckedForEvents()

    def nextNode(self):
        """Works only dreamily when called on Sentence elements. If
        called on a token that is embedded in a chunk, then it should
        really look into the next chunk is self is a chunk-final
        token."""
        try:
            return self.parent[self.position+1]
        except IndexError:
            return ''

    def gramChunk(self):
        """Use a cache to increase speed for the code that checks
        patterns (Sentence.lookRight). That patterns code breaks
        because this method appears to return None is certain
        ill-understood cases."""
        if not self.cachedGramChunk:
            self._createGramChunk()
        return self.cachedGramChunk

    def _createGramChunk(self):
        self.cachedGramChunk = 0

    def createEvent(self):
        debug("CreateEvent in Consituent")
        pass

    def _matchChunk(self, chunkDescription):
        """Match chunk to the patterns in chunkDescriptions.
        chunkDescription is a dictionary with keys-values pairs that
        match instance variables and their values on GramChunks.

        The value in key-value pairs can be:
        - an atomic value. E.g., {..., 'headForm':'is', ...}
        - a list of possible values. E.g., {..., headForm': forms.have, ...}
        In this case, _matchChunk checks whether the chunk feature is
        included within this list.
        - a negated value. It is done by introducing it as
        a second constituent of a 2-position tuple whose initial position
        is the caret symbol: '^'. E.g., {..., 'headPos': ('^', 'MD') ...}

        This method is also implemented in the chunkAnalyzer.GramChunk class """
        for feat in chunkDescription.keys():
            value = chunkDescription[feat]
            if forms.DEBUG: print "\n\t\t......PAIR <"+feat+" "+str(value)+">"
            if forms.DEBUG: print "\t\tand MY VALUE:", self.__getattr__(feat)
            if type(value) is TupleType:
                if forms.DEBUG: print "\t\t......TUPLE TYPE"
                if value[0] == '^':
                    value = value[1]
                    if self.__getattr__(feat) in value:
                        return 0
                else:
                    raise "ERROR specifying description of pattern"
            elif type(value) is ListType:
                if forms.DEBUG: print "\t\t......LIST TYPE"
                if self.__getattr__(feat) not in value:
                    return 0
            else:
                if forms.DEBUG: print "\t\t......ELSE TYPE"
                if self.__getattr__(feat) != value:
                    return 0
        if forms.DEBUG: print "\t\tMATCHED! (00)\n"
        return 1


class Chunk(Constituent):

    def __init__(self, phraseType):
        self.phraseType = phraseType
        self.tokenList = []
        self.tokenIndex = 0
        self.positionCount = 0
        self.position = None
        self.parent = None
        self.cachedGramChunk = 0
        self.flagCheckedForEvents = 0

    def __len__(self):
        return len(self.tokenList)

    def __getitem__(self, index):
        return self.tokenList[index]

    def __getslice__(self, i, j):
        return self.tokenList[i:j]

    def __getattr__(self, name):
        """Used by Sentence._match. Needs cases for all instance
        variables used in the pattern matching phase."""
        if name == 'nodeType':
            #print "NODE TYPE:", self.__class__.__name__
            return self.__class__.__name__
        elif name == 'nodeName':
            #print "NODE NAME:", self.phraseType
            return self.phraseType
        elif name == 'text':
            #print "\tTOKEN TEXT:", self.getText()
            return None
        elif name == 'pos':
            #print "TOKEN POS:", self.pos
            return None        
        else:
            #print "NODE NAME:", name
            raise AttributeError, name

    def _createMultiChunk(self, multiChunkEnd): # *** MUST GO to Chunk??
        """Create multi-chunk: """
        multiChunkInit = self.getTokens(self)
        return multiChunkInit + multiChunkEnd

    def _processEventInChunk(self, gramChunk):
        doc = self.document()
        if (gramChunk.head and
            gramChunk.head.getText() not in forms.be and
            gramChunk.head.getText() not in forms.spuriousVerb and
            gramChunk.evClass):
            doc.addEvent(Event(gramChunk))
            

    def addToken(self, token):
        token.setParent(self)
        self.tokenList.append(token)
        self.positionCount += 1

    def getText(self):
        string = ""
        for token in self.tokenList:
            string = string+' '+token.getText()
        return string

    def getTokens(self, sequence):
        """Given a sentence or a piece of it,
        de-chunk it and return a list of plain tokens.
        Used for mapping sentences into RegEx-based patterns.
        """
        tokensList = []
        for item in sequence:
            if item.nodeType[-5:] == 'Token':
                tokensList.append(item)
            elif item.nodeType[-5:] == 'Chunk':
                chunkTokens = self.getTokens(item)
                tokensList = tokensList + chunkTokens
            else:
                raise "ERROR: unknown item type: "+item.nodeType
        return tokensList

    def startHead(self):
        pass

    def isChunk(self): return 1

    def isTimex(self):
        if self.phraseType and self.phraseType[:5] == 'TIMEX':
            return 1
        else: return 0

    def isNChHead(self):
        if self.phraseType and self.phraseType[:4] == 'HEAD':
            return 1
        else: return 0

class AdjChunk(Chunk):
    def __init__(self, phraseType):
        Chunk.__init__(self, phraseType)
        self.head = -1

    def getHead(self):
        return self.tokenList[self.head]

    def isAdjChunk(self):
        return 1
    
class NounChunk(Chunk):

    def __init__(self, phraseType):
        Chunk.__init__(self, phraseType)
        self.head = -1
        self.poss = None

    def getHead(self):
        return self.tokenList[self.head]

    def getPoss(self):
        return self.tokenList[self.poss]

    def startHead(self):
        self.head = len(self.tokenList)

    def startPOSS(self):
        if self.tokenList:
            self.poss = len(self.tokenList)
        else:
            self.poss = 0

    def isNounChunk(self): return 1

    def _createGramChunk(self):
        self.cachedGramChunk = GramNChunk(self)

    def isDefinite(self):
        for token in self.tokenList[:self.head]:
            if token.pos == 'POS' or token.pos == 'PRP$':
                return True
            elif token.pos == 'DET' and token.getText() in ['the', 'this', 'that', 'these', 'those']:
                return True
        return False

    def createEvent(self, verbGramFeat='nil'):
        debug("CreateEvent in NounChunk")
        GramNCh = self.gramChunk()
        """ To percolate gram features from verb
        in case of nominal events that are the head of
        predicative complements"""
        if verbGramFeat !='nil':
            GramNCh.tense = verbGramFeat['tense']
            GramNCh.aspect = verbGramFeat['aspect']
            GramNCh.modality = verbGramFeat['modality']
            GramNCh.polarity = verbGramFeat['polarity']
            if forms.DEBUG: GramNCh.printNChunk('(N_NPC)')
        else:
            if forms.DEBUG: GramNCh.printNChunk('(1)')
        # Even if preceded by a BE or a HAVE form,
        # only tagging N Chunks headed by an eventive noun
        # E.g., "was an intern" will NOT be tagged
        if GramNCh.isEventCandidate_Syn() and GramNCh.isEventCandidate_Sem():
            if forms.DEBUG: print "Accepted Nominal"
            self._processEventInChunk(GramNCh)

        # some initial testing for the look ahead code
        #descs = []
        #descs.append({'class':"OCCURRENCE"})
        #self.parent.lookRight(self.position,descs)


class VerbChunk(Chunk):

    def __init__(self, phraseType):
        Chunk.__init__(self, phraseType)
        self.verbs = [-1,-1]

    def getVerbs(self):
        return self.tokenList[self.verbs[0]:self.verbs[1]]

    def startVerbs(self):
        self.verbs[0] = len(self.tokenList)

    def endVerbs(self):
        self.verbs[1] = len(self.tokenList) -1

    def isVerbChunk(self): return 1

    def _createGramChunk(self):
        self.cachedGramChunk = GramVChunkList(self)   

    def _updatePositionInSentence(self, endPosition):
        pass

    def _identifySubstringInSentence(self, tokenSentence, FSAset):
        fsaCounter=0  # DEBUGGING purposes
        for fsa in FSAset:
            fsaCounter = fsaCounter + 1
            if forms.DEBUG: print "FSA:\n", fsa
            lenSubstring = fsa.acceptsSubstringOf(tokenSentence)
            if lenSubstring:
                return (lenSubstring, fsaCounter)
        else:
            return (0, fsaCounter)

    def _updateFlagCheckedForEvents(self, multiChunkEnd):
        """Update Position in sentence, by marking as already checked for EVENT
        upcoming Tokens and Chunks that are included in multi-chunk """
        for item in multiChunkEnd:
            item.setFlagCheckedForEvents()
            
    def _getRestSent(self, structure):
        """Obtaining the rest of the sentence, which can be
        in a flat, token-based structure, or chunked."""
        if forms.DEBUG: "Entering _getRestSent"
        if structure == 'flat':
            restSentence = self.getTokens(self.parent[self.position+1:])
        elif structure == 'chunked':
            restSentence = self.parent[self.position+1:]
        else:
            raise "ERROR: unknown structure value"
        return restSentence
            
    def _lookForMultiChunk(self, FSA_set, STRUCT='flat'):
        """Default argument 'STRUCT' specifies the structural format
        of the rest of the sentence: either a flat, token-level representation
        or a chunked one."""
        if forms.DEBUG: "Entering _lookForMultiChunk"
        restSentence = self._getRestSent(STRUCT)
        if forms.DEBUG:
            if STRUCT == 'flat':                                                       #DEBUGGING
                for item in restSentence: print "\t "+item.getText()+"\t"+item.pos     #DEBUGGING
            else: pass                                                                 #DEBUGGING
        lenSubstring, fsaNum = self._identifySubstringInSentence(restSentence, FSA_set)
        if lenSubstring:
            if forms.DEBUG: print "\n.....................ACCEPTED!!! LENGTH:", lenSubstring, "FSA:", fsaNum  # DEBUGGING
            if forms.DEBUG: print 70*"*", "\n"
            return restSentence[:lenSubstring]
        else:
            if forms.DEBUG: print "\n.....................REJECTED by FSA:", fsaNum  #DEBUGGING
            if forms.DEBUG: print 70*"*", "\n"
            return 0

    def _processEventInMultiVChunk(self, substring):   
        GramMultiVChunk = GramVChunkList(self._createMultiChunk(substring))[0] 
        if forms.DEBUG: GramMultiVChunk.printVChunk('3')  # DEBUGGING
        self._processEventInChunk(GramMultiVChunk)  #*** make processEventInChunk in GramChunks???
        self._updateFlagCheckedForEvents(substring)

    def _processEventInMultiNChunk(self, GramVCh, substring):
        nounChunk = substring[-1]
        verbGramFeatures = {'tense': GramVCh.tense,
                            'aspect': GramVCh.aspect,
                            'modality': GramVCh.modality,
                            'polarity': GramVCh.polarity}
        nounChunk.createEvent(verbGramFeatures)
        self._updateFlagCheckedForEvents(substring)

    def _processEventInMultiAChunk(self, GramVCh, substring):
        adjToken = substring[-1]
        verbGramFeatures = {'tense': GramVCh.tense,
                            'aspect': GramVCh.aspect,
                            'modality': GramVCh.modality,
                            'polarity': GramVCh.polarity}
        adjToken.createAdjEvent(verbGramFeatures)
        self._updateFlagCheckedForEvents(substring)

    def _processDoubleEventInMultiAChunk(self, GramVCh, substring):
        """Tagging EVENT in VChunk """
        if forms.DEBUG: GramVCh.printVChunk('(V_2Ev)')
        self._processEventInChunk(GramVCh)
        """Tagging EVENT in AdjToken"""
        adjToken = substring[-1]
        adjToken.createAdjEvent()
        self._updateFlagCheckedForEvents(substring)

    def _createEventOnRightmostVerb(self, GramVCh):
        if GramVCh.nodeIsNotEventCandidate():
            pass
        elif GramVCh.nodeIsModalForm(self.nextNode()):
            if forms.DEBUG: print "\nEntering checking for modal pattern............\n"
            substring = self._lookForMultiChunk(forms.PATTERNS.MODAL_FSAs)
            if substring:
                self._processEventInMultiVChunk(substring)

        elif GramVCh.nodeIsBeForm(self.nextNode()):
            if forms.DEBUG: print "\nEntering checking for toBe pattern............\n"
            """Looking for BE + NOM Predicative Complement """
            if forms.DEBUG: print "Looking for BE + NOM Predicative Complement "
            substring = self._lookForMultiChunk(forms.PATTERNS.BE_N_FSAs, 'chunked')
            if substring:
                self._processEventInMultiNChunk(GramVCh, substring)  
            else:
                """Looking for BE + ADJ Predicative Complement """
                if forms.DEBUG: print "Looking for BE + ADJ Predicative Complement "
                substring = self._lookForMultiChunk(forms.PATTERNS.BE_A_FSAs, 'chunked')
                if substring:
                    self._processEventInMultiAChunk(GramVCh, substring)  
                else:
                    """Looking for BE + additional VERBAL structure """
                    if forms.DEBUG: print "Looking for BE + VERB Predicative Complement "
                    substring = self._lookForMultiChunk(forms.PATTERNS.BE_FSAs)
                    if substring:
                        self._processEventInMultiVChunk(substring)
                       
        elif GramVCh.nodeIsHaveForm():
            if forms.DEBUG: print "\nEntering checking for toHave pattern............\n"
            substring = self._lookForMultiChunk(forms.PATTERNS.HAVE_FSAs)
            if substring:
                self._processEventInMultiVChunk(substring)
            else:
                self._processEventInChunk(GramVCh)

        elif GramVCh.nodeIsFutureGoingTo():
            if forms.DEBUG: print "\nEntering checking for futureGoingTo pattern............\n"
            substring = self._lookForMultiChunk(forms.PATTERNS.GOINGto_FSAs)
            if substring:
                self._processEventInMultiVChunk(substring)
            else:
                self._processEventInChunk(GramVCh)

        elif GramVCh.nodeIsPastUsedTo():
            if forms.DEBUG: print "\nEntering checking for pastUsedTo pattern............\n"
            substring = self._lookForMultiChunk(forms.PATTERNS.USEDto_FSAs)
            if substring:
                self._processEventInMultiVChunk(substring)
            else:
                self._processEventInChunk(GramVCh)

        elif GramVCh.nodeIsDoAuxiliar():
            if forms.DEBUG: print "\nEntering checking for doAuxiliar pattern............\n"
            substring = self._lookForMultiChunk(forms.PATTERNS.DO_FSAs)
            if substring:
                self._processEventInMultiVChunk(substring)
            else:
                self._processEventInChunk(GramVCh)

        elif GramVCh.nodeIsBecomeForm(self.nextNode()):
            """Looking for BECOME + ADJ Predicative Complement
            e.g., He became famous at the age of 21"""
            if forms.DEBUG: print "Looking for BECOME + ADJ"
            substring = self._lookForMultiChunk(forms.PATTERNS.BECOME_A_FSAs, 'chunked')
            if substring:
                if forms.DEBUG: print "BECOME + ADJ found"
                self._processDoubleEventInMultiAChunk(GramVCh, substring)  
            else:
                self._processEventInChunk(GramVCh)

        elif GramVCh.nodeIsContinueForm(self.nextNode()):
            """Looking for CONTINUE + ADJ Predicative Complement
            e.g., Interest rate continued low."""
            if forms.DEBUG: print "Looking for CONTINUE + ADJ"
            substring = self._lookForMultiChunk(forms.PATTERNS.CONTINUE_A_FSAs, 'chunked')
            if substring:
                if forms.DEBUG: print "CONTINUE + ADJ found"
                self._processDoubleEventInMultiAChunk(GramVCh, substring)  
            else:
                self._processEventInChunk(GramVCh)

        elif GramVCh.nodeIsKeepForm(self.nextNode()):
            """Looking for KEEP + ADJ Predicative Complement
            e.g., The announcement kept everybody Adj."""
            if forms.DEBUG: print "Looking for KEEP + [NChunk] + ADJ "
            substring = self._lookForMultiChunk(forms.PATTERNS.KEEP_A_FSAs, 'chunked')
            if substring:
                if forms.DEBUG: print "KEEP + ADJ found"
                self._processDoubleEventInMultiAChunk(GramVCh, substring)  
            else:
                self._processEventInChunk(GramVCh)
            
        else:
            if forms.DEBUG: GramVCh.printVChunk('(1)')      
            self._processEventInChunk(GramVCh)

    def createEvent(self):
        debug("createEvent in VerbChunk")
        try:
            GramVChList = self.gramChunk()  
        except:
            if forms.DEBUG:
                print "ERROR: not creating GramVChunk\n"
                raise Exception
            return None
        if len(GramVChList) == 0:
            if forms.DEBUG: print "\nWARNING: Obtaining an empty GramVChList"
        elif len(GramVChList) == 1:
            if forms.DEBUG: print "len(GramVChList) == 1"
            self._createEventOnRightmostVerb(GramVChList[-1])
        else:
            if forms.DEBUG: print "len(GramVChList) > 1:", len(GramVChList)
            lastIdx = len(GramVChList)-1
            for idx in range(len(GramVChList)):
                gramVCh = GramVChList[idx]
                if idx == lastIdx:
                    self._createEventOnRightmostVerb(gramVCh)
                else:
                    if forms.DEBUG: gramVCh.printVChunk('(Not Last)') #Flag for complex VChunks
                    if not gramVCh.isAuxVerb():
                        self._processEventInChunk(gramVCh)
                    

class Token(Constituent):

    def __init__(self, document, pos, markedEvent=None, lemma=None):
        self.pos = pos
        self.text = []
        self.document = document
        self.position = None
        self.parent = None
        self.cachedGramChunk = 0
        self.flagCheckedForEvents = 0

    def __getitem__(self, index):
        if index == 0:
            return self
        else:
            raise IndexError("list index out of range")

    def __len__(self):
        return 1

    def __getattr__(self, name):
        """Used by Sentence._match. Needs cases for all instance
        variables used in the pattern matching phase."""
        if name == 'nodeType':
            #print "TOKEN TYPE:", self.__class__.__name__
            return self.__class__.__name__
        elif name == 'text':
            #print "\tTOKEN TEXT:", self.getText()
            return self.getText()
        elif name == 'pos':
            #print "TOKEN POS:", self.pos
            return self.pos
        else:
            raise AttributeError, name

    def _processEventInToken(self, gramChunk):
        doc = self.document#()
        if (gramChunk.head and
            gramChunk.head.getText() not in forms.be and
            gramChunk.evClass):
            doc.addEvent(Event(gramChunk))

    def setTextNode(self, docLoc):
        self.text = docLoc

    def getText(self):
        return self.document.nodeList[self.text]

    def document(self):
        """For some reason, tokens have a document variable. Use this
        variable and avoid looking all the way up the tree"""
        return self.document

    def isToken(self): return 1

    def createEvent(self):
        debug("createEvent in AdjChunk")
        pass

class AdjectiveToken(Token):

    def _createGramChunk(self):
        self.cachedGramChunk = GramAChunk(self)

    def createEvent(self):
        """Arriving here adjs passed through the main loop
        for createEvent"""
        debug("createEvent in AdjToken")
        pass
    
    def createAdjEvent(self, verbGramFeat='nil'):
        """ only for tokens that are not in a chunk"""
        debug("createAdjEvent in AdjToken")
        if not self.parent.__class__.__name__ == 'Sentence':
            return
        else:
            GramACh = self.gramChunk()
            if verbGramFeat !='nil':
                """ Percolating gram features from copular verb"""
                GramACh.tense = verbGramFeat['tense']
                GramACh.aspect = verbGramFeat['aspect']
                GramACh.modality = verbGramFeat['modality']
                GramACh.polarity = verbGramFeat['polarity']
                if forms.DEBUG: print "Accepted Adjective"
                if forms.DEBUG: GramACh.printAChunk('(A_APC)')
            else:                                                   # DEBUGGING
                if forms.DEBUG: GramACh.printAChunk('(A_2Ev)')      # DEBUGGING
            self._processEventInToken(GramACh)            


    def isAdjToken(self):
        return 1




