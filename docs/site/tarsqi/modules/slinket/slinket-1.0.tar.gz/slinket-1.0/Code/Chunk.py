import string, sys
import forms
from types import ListType, TupleType, StringType
from timeMLspec import *
from debugging import log


class Constituent:
    """An abstract class that contains some methods that are identical
    for Chunks and Tokens plus a couple of default methods."""
    
    def setParent(self, parent):
        self.parent = parent
        self.position = parent.positionCount

    def document(self):
        return self.parent.document()
    
    def isToken(self): return 0
    def isChunk(self): return 0
    def isVerbChunk(self): return 0
    def isNounChunk(self): return 0
    def isTimex(self): return 0
    def isNChHead(self): return 0

    def __getattr__(self, name):
        """Used by node._matchChunk. Needs cases for all instance
        variables used in the pattern matching phase."""
        if name == 'nodeType':
            return self.__class__.__name__
        else:
            raise AttributeError, name
            
    def getText(self):
        pass
        
    def nextNode(self):
        """Works only dreamily when called on Sentence elements. If
        called on a token that is embedded in a chunk, then it should
        really look into the next chunk is self is a chunk-final
        token."""
        try:
            return self.parent[self.position+1]
        except IndexError:
            return ''

    def _hackToSolveProblemsInValue(self, value):
        if type(value) is ListType:
            if len(value) == 2 and value[0] == '' and value[1] == '':
                return [',']
            else:
                return value
        elif type(value) is StringType:
            if value == '':
                return '"'
            else:
                return value
        else:
            return value

    def _matchChunk(self, chunkDescription): 
        """Match the chunk instance to the patterns in chunkDescriptions.
        chunkDescription is a dictionary with keys-values pairs that
        match instance variables and their values on GramChunks.

        The value in key-value pairs can be:
        - an atomic value. E.g., {..., 'headForm':'is', ...} 
        - a list of possible values. E.g., {..., headForm': forms.have, ...}   
        In this case, _matchChunk checks whether the chunk feature is
        included within this list.
        - a negated value. It is done by introducing it as
        a second constituent of a 2-position tuple whose initial position
        is the caret symbol: '^'. E.g., {..., 'headPos': ('^', 'MD') ...}
        
        This method is also implemented in the chunkAnalyzer.GramChunk class """
        for feat in chunkDescription.keys():
            #log("\nVALUE TO MATCH: "+str(feat)+"\t|| VALUE in expression: "+str(self.__getattr__(feat)))
            value = chunkDescription[feat]
            if type(value) is TupleType:
                if value[0] == '^':
                    newvalue = self._hackToSolveProblemsInValue(value[1])
                    if type(newvalue) is ListType:
                        if self.__getattr__(feat) in newvalue:
                            return 0
                    else:
                        if self.__getattr__(feat) == newvalue:
                            return 0
                else:
                    raise "ERROR specifying description of pattern" 
            elif type(value) is ListType:
                if self.__getattr__(feat) not in value:
                    return 0
            else:
                value = self._hackToSolveProblemsInValue(value)
                if self.__getattr__(feat) != value:
                    return 0
        return 1


        

class Chunk(Constituent):

    def __init__(self, phraseType):
        self.phraseType = phraseType
        self.tokenList = []
        self.tokenIndex = 0
        self.positionCount = 0
        self.position = None
        self.parent = None
        self.cachedGramChunk = 0
        self.event = None
        self.eid = None
        self.isEmbedded = 0
        self.createdLexicalSlink = 0
        self.createdAlink = 0
        
    def __len__(self):
        return len(self.tokenList)

    def __getitem__(self, index):
        return self.tokenList[index]

    def __getslice__(self, i, j):
        return self.tokenList[i:j]

    def __getattr__(self, name):
        """Used by Sentence._match. Needs cases for all instance
        variables used in the pattern matching phase."""
        if name == 'nodeType':
            return self.__class__.__name__
        elif name == 'nodeName':
            return self.phraseType
        elif name in ['eventStatus', 'text', FORM, STEM, POS, TENSE, ASPECT, EPOS, MOD, POL, EVENTID, EIID, CLASS]: #NF_MORPH, 
            if not self.event:
                return None
            else:
                doc = self.parent.document()
                if name == 'eventStatus':
                    return '1'
                elif name == TENSE:
                    return doc.taggedEventsDict[self.eid][TENSE]
                elif name == ASPECT:
                    return doc.taggedEventsDict[self.eid][ASPECT]
                elif name == EPOS: #NF_MORPH:
                    return doc.taggedEventsDict[self.eid][EPOS]#[NF_MORPH]
                elif name == MOD:
                    try: mod = doc.taggedEventsDict[self.eid][MOD]
                    except: mod = 'NONE'
                    return mod
                elif name == POL:
                    try: pol = doc.taggedEventsDict[self.eid][POL]
                    except: pol = 'POS'
                    return pol
                elif name == EVENTID:
                    return doc.taggedEventsDict[self.eid][EVENTID]
                elif name == EIID:
                    return doc.taggedEventsDict[self.eid][EIID]
                elif name == CLASS:
                    return doc.taggedEventsDict[self.eid][CLASS]
                elif name == 'text' or name == FORM:
                    return doc.taggedEventsDict[self.eid][FORM] 
                elif name == STEM:
                    return doc.taggedEventsDict[self.eid][STEM] 
                elif name == POS:
                    try:
                        return doc.taggedEventsDict[self.eid][POS] #self.token.pos
                    except:
                        return 'NONE'
        else:
            raise AttributeError, name

    def _matchChunk(self, chunkDescription): 
        """Match the chunk instance to the patterns in chunkDescriptions.
        chunkDescription is a dictionary with keys-values pairs that
        match instance variables and their values on GramChunks.

        The value in key-value pairs can be:
        - an atomic value. E.g., {..., 'headForm':'is', ...} 
        - a list of possible values. E.g., {..., headForm': forms.have, ...}   
        In this case, _matchChunk checks whether the chunk feature is
        included within this list.
        - a negated value. It is done by introducing it as
        a second constituent of a 2-position tuple whose initial position
        is the caret symbol: '^'. E.g., {..., 'headPos': ('^', 'MD') ...}
        
        This method is also implemented in the chunkAnalyzer.GramChunk class """
        for feat in chunkDescription.keys():
            #log("\nVALUE TO MATCH: "+str(feat)+"\t|| VALUE in expression: "+str(self.__getattr__(feat)))
            value = chunkDescription[feat]
            if type(value) is TupleType:
                if value[0] == '^':
                    newvalue = self._hackToSolveProblemsInValue(value[1])
                    if type(newvalue) is ListType:
                        if self.__getattr__(feat) in newvalue:
                            return 0
                    else:
                        if self.__getattr__(feat) == newvalue:
                            return 0
                else:
                    raise "ERROR specifying description of pattern" 
            elif type(value) is ListType:
                if self.__getattr__(feat) not in value:
                    if feat != 'text':
                        return 0
                    else:
                        self._getHeadText()
                        if self._getHeadText() not in value:
                            return 0
            else:
                value = self._hackToSolveProblemsInValue(value)
                if self.__getattr__(feat) != value:
                    return 0
        return 1

    def _getHeadText(self):
        headText = string.split(self.getText())[-1]
        return string.strip(headText)
    
    def _printSequence(self, sequence, depth):          # DEBUGGING method
        """Given a sentence or a piece of it,
        print the list of chunks and tokens it contains.
        'depth' establishes the number of tabs to be printed
        for each item, in order to display it in a hierarchical manner.
        """
        for item in sequence:
            #log("\nITEM: "+str(item.getText())+" || type"+str(item.nodeType))
            #log("ITEM type"+str(item.nodeType))
            if item.nodeType[-14:] == 'AdjectiveToken':
                try:
                    log("\n"+depth*"\t"+"ADJ TOKEN: "+item.getText()+"\t"+item.pos+"\t\tEvent:"+str(item.event))
                except:
                    log("\n"+depth*"\t"+"TOKEN: "+item.getText()+"\t"+item.pos+"\t\tEvent: None")
                    #log("\nWARNING: possibly a NoneType here. (1)")
            
            elif item.nodeType[-5:] == 'Token':
                try:
                    log("\n"+depth*"\t"+"TOKEN: "+item.getText()+"\t"+item.pos+"\t\tEvent:"+str(item.event))
                except:
                    log("\n"+depth*"\t"+"TOKEN: "+item.getText()+"\t"+item.pos)
                    #log("\nWARNING: possibly a NoneType here. (1)")
            elif item.nodeType[-5:] == 'Chunk':
                try:
                    log("\n"+depth*"\t"+"CHUNK: "+item.nodeType+"\t\tEvent:"+str(item.event))
                    #log("\n"+depth*"\t===>"+str(len(item)))
                    self._printSequence(item, depth+1)
                except:
                    log("\nWARNING: possibly a NoneType here. (2)")
            elif item.nodeType == EVENT:
                try:
                    log("\n"+depth*"\t"+"EVENT: "+item.text+"\t"+item.pos)
                except:
                    log("\nWARNING: possibly a NoneType here. (3)")
            elif item.nodeType == TIMEX:
                try:
                    log("\n"+depth*"\t"+"TIMEX: "+item.getText())
                except:
                    log("\nWARNING: possibly a NoneType here. (4)")
            else:
                raise "ERROR: unknown item type: "+item.nodeType


    def setEmbedded(self):
        """Keeping track of chunks embedded
        within other chunks, for parsing purposes"""
        self.isEmbedded = 1

    def resetEmbedded(self):
        self.isEmbedded = 0
        
    def startHead(self):
        pass

    def startVerbs(self):
        pass

    def endVerbs(self):
        pass
    
    def addToken(self, token):
        token.setParent(self)
        self.tokenList.append(token)
        self.positionCount += 1

    def setEventInfo(self, eid):
        self.event = 1
        self.eid = eid
        
    def getText(self):
        string = ""
        for token in self.tokenList:
            string = string+' '+str(token.getText())
        return string

    def getToken(self, sequence):
        """Given a sentence or a piece of it,
        de-chunk it and return a list of plain tokens.
        Used for mapping sentences into RegEx-based patterns.
        """
        tokensList = []
        for item in sequence:
            if item.nodeType[-5:] == 'Token':
                tokensList.append(item)
            elif item.nodeType[-5:] == 'Chunk':
                chunkTokens = self.getTokens(item)
                tokensList = tokensList + chunkTokens
            elif item.nodeType == 'EVENT':
                tokensList.append(item)
            else:
                raise "ERROR: unknown item type: "+item.nodeType
        return tokensList
    
    def _identifySubstringInSentence(self, tokenSentence, FSAset):
        fsaCounter=-1  # DEBUGGING purposes
        for fsa in FSAset:
            fsaCounter = fsaCounter + 1
            log("\nFSA:\n"+str(fsa))
            lenSubstring = fsa.acceptsShortestSubstringOf(tokenSentence)
            if lenSubstring:
                return (lenSubstring, fsaCounter)
        else:
            return (0, fsaCounter)

    def _lookForLink(self, restSentence, FSA_set):
        # Eventually, if we want to merge EVITA and SLINKET common stuff,
        # this method should call self._lookForStructuralPattern(FSA_set)
        # But careful: _lookForLink MUST return also fsaNum
        # and that will have effects on Evita code. 
        lenSubstring, fsaNum = self._identifySubstringInSentence(restSentence, FSA_set) #tokenSentence, FSA_set)
        if lenSubstring: 
            return (lenSubstring, fsaNum)   #return (tokenSentence[:lenSubstring], fsaNum)
        else:
            return 0

    def _extractQuotation(self, fragment):
        for idx in range(len(fragment)):
            try:
                # For some reason, it may break here (though rarely)
                if (fragment[idx].getText() == "''" and
                    (fragment[idx-1].getText() == "," or
                     fragment[idx+1].getText() == ",")):
                    return fragment[1:idx]
            except:
                pass
        else:
            return None
        
    def createForwardAlink(self, forwardAlinks):
        alinkedEventContext = self.parent[self.position+1:] # chunks following the currEvent
        self.createAlink(alinkedEventContext, forwardAlinks[0], forwardAlinks[1]) # forwardSlinks[0]:pattern name, forwardSlinks[1]: relType
        if self.createdAlink: log("\nFORWARD ALINK CREATED")

    def createBackwardAlink(self, backwardAlinks):
        """Backward Alinks also check for the adequacy (e.g., in terms of TENSE
        or ASPECT) of the Subordinating Event. For cases such as
        'the <EVENT>transaction</EVENT> has been <EVENT>initiated</EVENT>'
        """
        log("TRYING backward alink")
        alinkedEventContext = self.parent[:self.position+1]
        alinkedEventContext.reverse()
        self.createAlink(alinkedEventContext, backwardAlinks[0], backwardAlinks[1])
        if self.createdAlink: log("\nBACKWARD ALINK CREATED")

        
    def createAlink(self, alinkedEventContext, syntaxPatternLists, relTypeList):
        for i in range(len(syntaxPatternLists)):
            self._printSequence(alinkedEventContext, 1)   # DEBUGGING method
            substring = self._lookForLink(alinkedEventContext, syntaxPatternLists[i])
            if substring:
                #log("substring\n"+str(substring)+"\n")
                substringLength = substring[0]
                subpatternNum = substring[1]
                relType = relTypeList[i]
                #patterns = syntaxPatternLists[i]  # should be ith nested list in syntaxPatternLists
                #patternName = patterns[subpatternNum] # should be subpatternNumth item in the list
                patternName = syntaxPatternLists[i][subpatternNum]
                log("\n"+21*"."+"ACCEPTED ALINK!!! LENGTH: "+str(substringLength)+" "+str(relType)+
                      " || FSA: "+str(i)+"."+str(subpatternNum)+" PatternName: "+patternName.fsaname)     # DEBUGGING
                log("\n"+70*"*"+"\n")                          # DEBUGGING
                alinkAttrs = { 'eventInstanceID': self.eiid, 
                               'relatedToEventInstance': alinkedEventContext[substringLength-1].eiid,
                               'relType': relType,
                               'syntax': patternName.fsaname
                             }
                self.document().addLink(alinkAttrs, "ALINK")#relType, self.eiid, alinkedEventContext[substringLength-1].eiid, patternName.fsaname)
                self.createdAlink = 1
                break    
            else:
                log("\n.....................REJECTED ALINK by FSA: "+str(i)+".?")    # DEBUGGING
                log("\n"+70*"*"+"\n")                                                # DEBUGGING

                
    def createForwardSlink(self, forwardSlinks):
        slinkedEventContext = self.parent[self.position+1:] # chunks following the currEvent
        self.createSlink(slinkedEventContext, forwardSlinks[0], forwardSlinks[1]) # forwardSlinks[0]:pattern name, forwardSlinks[1]: relType
        if self.createdLexicalSlink:
            log("\nFORWARD SLINK CREATED")

    def createBackwardSlink(self, backwardSlinks):
        """Backward Slinks also check for the adequacy (e.g., in terms of TENSE
        or ASPECT) of the Subordinating Event. For cases such as
        'the <EVENT>transaction</EVENT> has been <EVENT>approved</EVENT>'
        """
        log("TRYING backward slink")
        slinkedEventContext = self.parent[:self.position+1]
        slinkedEventContext.reverse()
        self.createSlink(slinkedEventContext, backwardSlinks[0], backwardSlinks[1]) 
        if self.createdLexicalSlink:
            log("\nBACKWARD SLINK CREATED")
        
    def createReportingSlink(self, reportingSlink):
        """Reporting Slinks are applied to reporting predicates ('say', 'told', etc)
        that link an event in a preceeding quoted sentence which is
        separated from the clause of the reporting event by a comma; e.g.,
            ``I <EVENT>want</EVENT> a referendum,'' Howard <EVENT class='REPORTING'>said</EVENT>.
        Slinket assumes that these quoted clauses always initiate the main sentence.
        Therefore, the first item in the sentence are quotation marks.
        """
        sentenceBeginning = self.parent[:self.position]
        if len(sentenceBeginning) > 0 and sentenceBeginning[0].getText() == "``":
            """quotation does not contain quotation marks"""
            quotation = self._extractQuotation(sentenceBeginning)
            if quotation is not None:
                log("\nTRYING reporting slink")
                self.createSlink(quotation, reportingSlink[0], reportingSlink[1])
        
    def createSlink(self, slinkedEventContext, syntaxPatternLists, relTypeList):
        for i in range(len(syntaxPatternLists)):
            self._printSequence(slinkedEventContext, 1)   # DEBUGGING method
            substring = self._lookForLink(slinkedEventContext, syntaxPatternLists[i])
            if substring:
                #log("substring\n"+str(substring)+"\n")
                substringLength = substring[0]
                subpatternNum = substring[1]
                relType = relTypeList[i]
                #patterns = syntaxPatternLists[i]  # should be ith nested list in syntaxPatternLists
                #patternName = patterns[subpatternNum] # should be subpatternNumth item in the list
                patternName = syntaxPatternLists[i][subpatternNum]
                log("\n"+21*"."+"ACCEPTED SLINK!!! LENGTH: "+str(substringLength)+" "+str(relType)+
                      " || FSA: "+str(i)+"."+str(subpatternNum)+" PatternName: "+patternName.fsaname)     # DEBUGGING
                log("\n"+70*"*"+"\n")                          # DEBUGGING
                slinkAttrs = { 'eventInstanceID': self.eiid, 
                               'subordinatedEventInstance': slinkedEventContext[substringLength-1].eiid,
                               'relType': relType,
                               'syntax': patternName.fsaname
                             }
                self.document().addLink(slinkAttrs, "SLINK")#relType, self.eiid, alinkedEventContext[substringLength-1].eiid, patternName.fsaname)
                self.createdLexicalSlink = 1
                break    
            else:
                log("\n.....................REJECTED SLINK by FSA: "+str(i)+".?")    # DEBUGGING
                log("\n"+70*"*"+"\n")                                                # DEBUGGING

    def createSlink3(self, slinkedEventContext, syntaxPatternLists, relTypeList):
        for i in range(len(syntaxPatternLists)):
            self._printSequence(slinkedEventContext, 1)   # DEBUGGING method
            substring = self._lookForLink(slinkedEventContext, syntaxPatternLists[i])
            if substring:
                #log("substring\n"+str(substring)+"\n")
                substringLength = substring[0]
                subpatternNum = substring[1]
                relType = relTypeList[i]
                #patterns = syntaxPatternLists[i]  # should be ith nested list in syntaxPatternLists
                #patternName = patterns[subpatternNum] # should be subpatternNumth item in the list
                patternName = syntaxPatternLists[i][subpatternNum]
                
                log("\n"+21*"."+"ACCEPTED SLINK!!! LENGTH: "+str(substringLength)+" "+str(relType)+
                      " || FSA: "+str(i)+"."+str(subpatternNum)+" PatternName: "+patternName.fsaname)     # DEBUGGING
                log("\n"+70*"*"+"\n")                          # DEBUGGING
                self.document().addSlink(relType, self.eiid, slinkedEventContext[substringLength-1].eiid, patternName.fsaname)
                self.createdLexicalSlink = 1
                break    
            else:
                log("\n.....................REJECTED SLINK by FSA: "+str(i)+".?")    # DEBUGGING
                log("\n"+70*"*"+"\n")                                                # DEBUGGING

    def isChunk(self):
        return 1

    def isTimex(self):
        if self.phraseType and self.phraseType[:5] == 'TIMEX':
            return 1
        else: return 0

    def isNChHead(self):
        if self.phraseType and self.phraseType[:4] == 'HEAD':
            return 1
        else: return 0


    
class NounChunk(Chunk):

    def __init__(self, phraseType):
        Chunk.__init__(self, phraseType)
        self.head = -1
        self.poss = None

    def getHead(self):
        return self.tokenList[self.head]

    def getPoss(self):
        return self.tokenList[self.poss]

    def startHead(self):
        self.head = len(self.tokenList)

    def startPOSS(self):
        if self.tokenList:
            self.poss = len(self.tokenList)
        else:
            self.poss = 0

    def isNounChunk(self): return 1

    def isDefinite(self):
        for token in self.tokenList[:self.head]:
            if token.pos == 'POS' or token.pos == 'PRP$':
                return True
            elif token.pos == 'DET' and token.getText() in ['the', 'this', 'that', 'these', 'those']:
                return True
            else:
                return False

        
class VerbChunk(Chunk):

    def __init__(self, phraseType):
        Chunk.__init__(self, phraseType)
        self.verbs = [-1,-1]
        
    def getVerbs(self):
        return self.tokenList[self.verbs[0]:self.verbs[1]]

    def startVerbs(self):
        self.verbs[0] = len(self.tokenList)
        
    def endVerbs(self):
        self.verbs[1] = len(self.tokenList) -1

    def isVerbChunk(self): return 1

    def _updatePositionInSentence(self, endPosition):
        pass

            
class Token(Constituent):
    
    def __init__(self, document, pos):
        self.pos = pos
        self.textIdx = []
        self.document = document
        self.position = None
        self.parent = None
        self.cachedGramChunk = 0
        
    def __getitem__(self, index):
        if index == 0:
            return self
        else:
            raise IndexError("list index out of range")
            
    def __len__(self):
        return 1

    def __getattr__(self, name):
        """Used by Sentence._match. Needs cases for all instance
        variables used in the pattern matching phase."""
        if name == 'nodeType':
            return self.__class__.__name__
        elif name == 'text':
            return self.getText()
        elif name == 'pos':
            return self.pos
        elif name in ['eventStatus', FORM, STEM, TENSE, ASPECT, EPOS, MOD, POL, EVENTID, EIID, CLASS]: #NF_MORPH, 
            return None
        else:
            raise AttributeError, name

    def setTextNode(self, docLoc):
        self.textIdx = docLoc
        
    def getText(self):
        return self.document.nodeList[self.textIdx]

    def document(self):
        """For some reason, tokens have a document variable. Use this
        variable and avoid looking all the way up the tree"""
        return self.document
    
    def isToken(self):
        return 1

    def isAdjToken(self):
        return 0

                
class AdjectiveToken(Token):

    def __init__(self, document, pos):
        Token.__init__(self, document, pos)
        self.pos = pos
        self.event = None
        self.eid = None
        self.createdLexicalSlink = 0
        self.createdAlink = 0

    def __getattr__(self, name):
        """Used by Sentence._match. Needs cases for all instance
        variables used in the pattern matching phase."""
        if name == 'nodeType':
            return self.__class__.__name__
        elif name == 'nodeName':
            return self.pos
        elif name in ['eventStatus', 'text', FORM, STEM, POS, TENSE, ASPECT, EPOS, MOD, POL, EVENTID, EIID, CLASS]: #NF_MORPH, 
            if not self.event:
                return None
            else:
                doc = self.parent.document()
                if name == 'eventStatus':
                    return '1'
                elif name == TENSE:
                    return doc.taggedEventsDict[self.eid][TENSE]
                elif name == ASPECT:
                    return doc.taggedEventsDict[self.eid][ASPECT]
                elif name == EPOS: #NF_MORPH:
                    return doc.taggedEventsDict[self.eid][EPOS]#[NF_MORPH]
                elif name == MOD:
                    try: mod = doc.taggedEventsDict[self.eid][MOD]
                    except: mod = 'NONE'
                    return mod
                elif name == POL:
                    try: pol = doc.taggedEventsDict[self.eid][POL]
                    except: pol = 'POS'
                    return pol
                elif name == EVENTID:
                    return doc.taggedEventsDict[self.eid][EVENTID]
                elif name == EIID:
                    return doc.taggedEventsDict[self.eid][EIID]
                elif name == CLASS:
                    return doc.taggedEventsDict[self.eid][CLASS]
                elif name == 'text' or name == FORM:
                    return doc.taggedEventsDict[self.eid][FORM] 
                elif name == STEM:
                    return doc.taggedEventsDict[self.eid][STEM] 
                elif name == POS:
                    try:
                        return doc.taggedEventsDict[self.eid][POS] #self.token.pos
                    except:
                        return 'NONE'
        else:
            raise AttributeError, name


        
    def createEvent(self):
        pass    
##        """ only for tokens that are not in a chunk"""
##        if not self.parent.__class__.__name__ == 'Sentence':
##            return

    def isAdjToken(self):
        return 1

    def isToken(self):
        return 1

    def doc(self):
        log("RETURNING document")
        return self.parent.document()
    
    def setEventInfo(self, eid):
        self.event = 1
        self.eid = eid

        
    def createForwardAlink(self, forwardAlinks):
        alinkedEventContext = self.parent[self.position+1:] # chunks following the currEvent
        self.createAlink(alinkedEventContext, forwardAlinks[0], forwardAlinks[1]) # forwardSlinks[0]:pattern name, forwardSlinks[1]: relType
        if self.createdAlink: log("\nFORWARD ALINK CREATED")

    def createBackwardAlink(self, backwardAlinks):
        """Backward Alinks also check for the adequacy (e.g., in terms of TENSE
        or ASPECT) of the Subordinating Event. For cases such as
        'the <EVENT>transaction</EVENT> has been <EVENT>initiated</EVENT>'
        """
        log("TRYING backward alink")
        alinkedEventContext = self.parent[:self.position+1]
        alinkedEventContext.reverse()
        self.createAlink(alinkedEventContext, backwardAlinks[0], backwardAlinks[1])
        if self.createdAlink: log("\nBACKWARD ALINK CREATED")

        
    def createAlink(self, alinkedEventContext, syntaxPatternLists, relTypeList):
        for i in range(len(syntaxPatternLists)):
            self._printSequence(alinkedEventContext, 1)   # DEBUGGING method
            substring = self._lookForLink(alinkedEventContext, syntaxPatternLists[i])
            if substring:
                #log("substring\n"+str(substring)+"\n")
                substringLength = substring[0]
                subpatternNum = substring[1]
                relType = relTypeList[i]
                #patterns = syntaxPatternLists[i]  # should be ith nested list in syntaxPatternLists
                #patternName = patterns[subpatternNum] # should be subpatternNumth item in the list
                patternName = syntaxPatternLists[i][subpatternNum]
                log("\n"+21*"."+"ACCEPTED ALINK!!! LENGTH: "+str(substringLength)+" "+str(relType)+
                      " || FSA: "+str(i)+"."+str(subpatternNum)+" PatternName: "+patternName.fsaname)     # DEBUGGING
                log("\n"+70*"*"+"\n")                          # DEBUGGING
                alinkAttrs = { 'eventInstanceID': self.eiid, 
                               'relatedToEventInstance': alinkedEventContext[substringLength-1].eiid,
                               'relType': relType,
                               'syntax': patternName.fsaname
                             }
                self.document().addLink(alinkAttrs, "ALINK")#relType, self.eiid, alinkedEventContext[substringLength-1].eiid, patternName.fsaname)
                self.createdAlink = 1
                break    
            else:
                log("\n.....................REJECTED ALINK by FSA: "+str(i)+".?")    # DEBUGGING
                log("\n"+70*"*"+"\n")                                                # DEBUGGING

    def createForwardSlink(self, forwardSlinks):
        """Only used if doc is chunked with Alembic;
        that is, Adj tokens do not belong to any chunk"""
        slinkedEventContext = self.parent[self.position+1:] # chunks following the currEvent
        self.createSlink(slinkedEventContext, forwardSlinks[0], forwardSlinks[1]) # forwardSlinks[0]:pattern name, forwardSlinks[1]: relType
        if self.createdLexicalSlink:
            log("\nFORWARD SLINK CREATED")

    def createBackwardSlink(self, backwardSlinks):
        """Backward Slinks also check for the adequacy (e.g., in terms of TENSE
        or ASPECT) of the Subordinating Event. For cases such as
        'the <EVENT>transaction</EVENT> has been <EVENT>approved</EVENT>'
        Only used if doc is chunked with Alembic;
        that is, Adj tokens do not belong to any chunk"""
        
        log("TRYING backward slink")
        slinkedEventContext = self.parent[:self.position+1]
        slinkedEventContext.reverse()
        self.createSlink(slinkedEventContext, backwardSlinks[0], backwardSlinks[1]) 
        if self.createdLexicalSlink:
            log("\nBACKWARD SLINK CREATED")
        
    def createReportingSlink(self, reportingSlink):
        """Reporting Slinks are applied to reporting predicates ('say', 'told', etc)
        that link an event in a preceeding quoted sentence which is
        separated from the clause of the reporting event by a comma; e.g.,
            ``I <EVENT>want</EVENT> a referendum,'' Howard <EVENT class='REPORTING'>said</EVENT>.
        Slinket assumes that these quoted clauses always initiate the main sentence.
        Therefore, the first item in the sentence are quotation marks.
        Only used if doc is chunked with Alembic;
        that is, Adj tokens do not belong to any chunk
        """
        sentenceBeginning = self.parent[:self.position]
        if len(sentenceBeginning) > 0 and sentenceBeginning[0].getText() == "``":
            """quotation does not contain quotation marks"""
            quotation = self._extractQuotation(sentenceBeginning)
            if quotation is not None:
                log("\nTRYING reporting slink")
                self.createSlink(quotation, reportingSlink[0], reportingSlink[1])
        
    def createSlink(self, slinkedEventContext, syntaxPatternLists, relTypeList):
       """Only used if doc is chunked with Alembic;
       that is, Adj tokens do not belong to any chunk
       """
       for i in range(len(syntaxPatternLists)):
            self._printSequence(slinkedEventContext, 1)   # DEBUGGING method
            substring = self._lookForLink(slinkedEventContext, syntaxPatternLists[i])
            if substring:
                #log("substring\n"+str(substring)+"\n")
                substringLength = substring[0]
                subpatternNum = substring[1]
                relType = relTypeList[i]
                #patterns = syntaxPatternLists[i]  # should be ith nested list in syntaxPatternLists
                #patternName = patterns[subpatternNum] # should be subpatternNumth item in the list
                patternName = syntaxPatternLists[i][subpatternNum]
                log("\n"+21*"."+"ACCEPTED SLINK!!! LENGTH: "+str(substringLength)+" "+str(relType)+
                      " || FSA: "+str(i)+"."+str(subpatternNum)+" PatternName: "+patternName.fsaname)     # DEBUGGING
                log("\n"+70*"*"+"\n")                          # DEBUGGING
                slinkAttrs = { 'eventInstanceID': self.eiid, 
                               'subordinatedEventInstance': slinkedEventContext[substringLength-1].eiid,
                               'relType': relType,
                               'syntax': patternName.fsaname
                             }
                self.doc().addLink(slinkAttrs, "SLINK")#relType, self.eiid, alinkedEventContext[substringLength-1].eiid, patternName.fsaname)
                self.createdLexicalSlink = 1
                break    
            else:
                log("\n.....................REJECTED SLINK by FSA: "+str(i)+".?")    # DEBUGGING
                log("\n"+70*"*"+"\n")                                                # DEBUGGING


    def _printSequence(self, sequence, depth):          # DEBUGGING method
        """Given a sentence or a piece of it,
        print the list of chunks and tokens it contains.
        'depth' establishes the number of tabs to be printed
        for each item, in order to display it in a hierarchical manner.
        """
        for item in sequence:
            #log("\nITEM: "+str(item.getText())+" || type"+str(item.nodeType)+"\t"+str(item))
            if item.nodeType[-14:] == 'AdjectiveToken':
                try:
                    log("\n"+depth*"\t"+"ADJ TOKEN: "+item.getText()+"\t"+item.pos+"\t\tEvent:"+str(item.event))
                except:
                    log("\n"+depth*"\t"+"TOKEN: "+item.getText()+"\t"+item.pos+"\t\tEvent: None")
                    #log("\nWARNING: possibly a NoneType here. (1)")
            elif item.nodeType[-5:] == 'Token':
                try:
                    log("\n"+depth*"\t"+"TOKEN: "+item.getText()+"\t"+item.pos+"\t\tEvent:"+str(item.event))
                except:
                    log("\n"+depth*"\t"+"TOKEN: "+item.getText()+"\t"+item.pos)
                    #log("\nWARNING: possibly a NoneType here. (1)")
            elif item.nodeType[-5:] == 'Chunk':
                try:
                    log("\n"+depth*"\t"+"CHUNK: "+item.nodeType+"\t\tEvent:"+str(item.event))
                    #log("\n"+depth*"\t===>"+str(len(item)))
                    self._printSequence(item, depth+1)
                except:
                    log("\nWARNING: possibly a NoneType here. (2)")
            elif item.nodeType == EVENT:
                try:
                    log("\n"+depth*"\t"+"EVENT: "+item.text+"\t"+item.pos)
                except:
                    log("\nWARNING: possibly a NoneType here. (3)")
            elif item.nodeType == TIMEX:
                try:
                    log("\n"+depth*"\t"+"TIMEX: "+item.getText())
                except:
                    log("\nWARNING: possibly a NoneType here. (4)")
            else:
                raise "ERROR: unknown item type: "+item.nodeType

    def _lookForLink(self, restSentence, FSA_set):
        # Eventually, if we want to merge EVITA and SLINKET common stuff,
        # this method should call self._lookForStructuralPattern(FSA_set)
        # But careful: _lookForLink MUST return also fsaNum
        # and that will have effects on Evita code. 
        lenSubstring, fsaNum = self._identifySubstringInSentence(restSentence, FSA_set) #tokenSentence, FSA_set)
        if lenSubstring: 
            return (lenSubstring, fsaNum)   #return (tokenSentence[:lenSubstring], fsaNum)
        else:
            return 0

    def _identifySubstringInSentence(self, tokenSentence, FSAset):
        fsaCounter=-1  # DEBUGGING purposes
        for fsa in FSAset:
            fsaCounter = fsaCounter + 1
            log("\nFSA:\n"+str(fsa))
            lenSubstring = fsa.acceptsShortestSubstringOf(tokenSentence)
            if lenSubstring:
                return (lenSubstring, fsaCounter)
        else:
            return (0, fsaCounter)

    def _extractQuotation(self, fragment):
        for idx in range(len(fragment)):
            try:
                # For some reason, it may break here (though rarely)
                if (fragment[idx].getText() == "''" and
                    (fragment[idx-1].getText() == "," or
                     fragment[idx+1].getText() == ",")):
                    return fragment[1:idx]
            except:
                pass
        else:
            return None
        
        
