from debugging import log
from EventExpression import *


class SentenceWindow:
    def __init__(self, doc, idx):
        self.doc = doc
        self.prevSent = self.previousSentence(idx) 
        self.currSent = self.doc[idx]
        self.nextSent = self.nextSentence(idx)
        self.currSentFullParsed = None
        log("\n\nSENTENCE num: "+str(idx))
        
    def nextSentence(self, idx):
        if idx+1 < len(self.doc):
            return self.doc[idx+1]
        else:
            return None

    def previousSentence(self, idx):
        if idx-1 >= 0:
            return self.doc[idx-1]
        else:
            return None

    def lookForSlinks(self):
        log("\nSENTENCE events: "+str(self.currSent.eventList))
        for idx in range(len(self.currSent.eventList)):
            eLocation = self.currSent.eventList[idx][0] 
            eId = self.currSent.eventList[idx][1]
            log("\n\n-- eLocation: "+str(eLocation))               
            currEvent = EventExpression(eId, eLocation, idx, self.doc.taggedEventsDict[eId])
            #currEvent.printEvent() #DEBUG
            """1. LEXICALLY-BASED SLINKS"""
            if currEvent.isCandidateToSlinking() :
                log("\n\n........ACCEPTED EVENT: '"+currEvent.form+"' is candidate to Slinking")
                self.lookForLexicallyBasedSlinks(currEvent)
            """2. PURPOSE CLAUSES"""
            self.lookForPurposeClauseSlinks(currEvent)
            """3. CONDITIONAL CONSTRUCTIONS"""
            self.lookForConditionalSlinks(currEvent)
            """4. ALINKS """
            if currEvent.isCandidateToAlinking():
                log("\n\n........ACCEPTED EVENT: '"+currEvent.form+"' is candidate to Alinking")
                self.lookForAlinks(currEvent)
                
    def lookForAlinks(self, currEvent):
        evNode = self.currSent[currEvent.locInSent]
        if evNode is None: log("\nWARNING: event index is None (alink process)")
        else:
            try: forwardAlinks = currEvent.alinkingContexts('forward')
            except: forwardAlinks = []
            
            try: backwardAlinks = currEvent.alinkingContexts('backwards')
            except: backwardAlinks = []
            
            for alinkPattern in ['F', 'B']:
                if alinkPattern == 'F' and forwardAlinks:
                    log("\nPROCESS for FORWARD alinks")
                    evNode.createForwardAlink(forwardAlinks)
                    if evNode.createdAlink:
                        evNode.createdAlink = 0
                        break
                elif alinkPattern == 'B' and backwardAlinks:
                    log("\nPROCESS for BACKWARD alinks")
                    evNode.createBackwardAlink(backwardAlinks)
                    if evNode.createdAlink:
                        evNode.createdAlink = 0
                        break
                
    def lookForLexicallyBasedSlinks(self, currEvent):
        evNode = self.currSent[currEvent.locInSent]
        if evNode is None: log("\nWARNING: event index is None (slink process)")
        else:
            try: forwardSlinks = currEvent.slinkingContexts('forward')
            except: forwardSlinks = []
            
            try: backwardSlinks = currEvent.slinkingContexts('backwards')
            except: backwardSlinks = []
            
            try: reportingSlinks = currEvent.slinkingContexts('reporting')
            except: reportingSlinks = []

            for slinkPattern in ['F', 'B', 'R']:
                if slinkPattern == 'F' and forwardSlinks:
                    log("\nPROCESS for FORWARD slinks")
                    evNode.createForwardSlink(forwardSlinks)
                    if evNode.createdLexicalSlink:
                        evNode.createdLexicalSlink = 0
                        break
                elif slinkPattern == 'B' and backwardSlinks:
                    log("\nPROCESS for BACKWARD slinks")
                    evNode.createBackwardSlink(backwardSlinks)
                    if evNode.createdLexicalSlink:
                        evNode.createdLexicalSlink = 0
                        break
                elif slinkPattern == 'R' and reportingSlinks:
                    log("\nPROCESS for REPORTING slinks")
                    evNode.createReportingSlink(reportingSlinks)
                    if evNode.createdLexicalSlink:
                        evNode.createdLexicalSlink = 0
                        break

    def lookForPurposeClauseSlinks(self, currEvent):
        """Some purpose clause SLINKS are already introduced
        in the lexically-triggered process. This is so for
        those events that discoursively tend to appear 
        modified by a Purpose Clause (e.g., 'address').
        The data are based on TimeBank."""
        pass

    def lookForConditionalSlinks(self, currEvent):
        pass
    
