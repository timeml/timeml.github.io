import cPickle, os.path, sys

if  os.path.abspath(os.path.dirname(sys.argv[0]))[-7:] == "slinket":
    DIR_DICTS = os.path.join(os.path.abspath(os.path.dirname(sys.argv[0])), "Dicts/")
elif os.path.abspath(os.path.dirname(sys.argv[0]))[-4:] == "Code":
    DIR_DICTS = os.path.join(os.path.abspath(os.path.dirname(sys.argv[0])), "Dicts/")
else:
    DIR_DICTS = os.path.abspath(os.path.dirname(sys.argv[0]))+'/slinket/Dicts/'


class Dicts:
    def loadDicts(self):
        self.slinkVerbsDict = cPickle.load(open(DIR_DICTS+"slinkVerbs.pickle"))
        self.slinkNounsDict = cPickle.load(open(DIR_DICTS+"slinkNouns.pickle"))
        self.slinkAdjsDict = cPickle.load(open(DIR_DICTS+"slinkAdjs.pickle"))
        self.alinkVerbsDict = cPickle.load(open(DIR_DICTS+"alinkVerbs.pickle"))
        self.alinkNounsDict = cPickle.load(open(DIR_DICTS+"alinkNouns.pickle"))
        
DICTS = Dicts()
