from string import lower
from timeMLspec import *
from debugging import log
from Dicts import DICTS


class EventExpression:

    def __init__(self, eid, locInSent, eventNum, dict):
        self.isSlinking = 0
        self.dict = dict
        log("\nDICT VALUE:"+str(self.dict))
        self.eid = eid
        self.eiid = self.getEiid()
        self.tense = self.getTense()
        self.aspect = self.getAspect()
        self.nf_morph = self.getNf_morph()
        self.polarity = self.getPolarity()
        self.modality = self.getModality()
        self.evClass = self.getEvClass()
        self.pos = self.getPos()
        self.form = self.getForm()
        #self.stem = self.getStem()
        self.locInSent = locInSent # idx of node bearing event tag in the document, wrt to its sentence parent node.
        self.eventNum = eventNum # position of event in sentence.eventList (needed for potential slinking w/ previous or next events in list)
        #log("\nEVENT info: "+str(self.dict))

    def getEiid(self):
        try:
            eiid = self.dict[EIID]
            #if not eiid: print "WARNING: 'eiid' value is empty"
            return eiid
        except:
            raise "ERROR: No 'eiid' attribute for current event"
        
    def getTense(self):
        try:
            tense = self.dict[TENSE]
            #if not tense: print "WARNING: 'tense' value is empty"
            return tense
        except:
            raise "ERROR: No 'tense' attribute for current event"

    def getAspect(self):
        try:
            aspect = self.dict[ASPECT]
            #if not aspect: print "WARNING: 'aspect' value is empty"
            return aspect
        except:
            raise "ERROR: No 'aspect' attribute for current event"

    def getNf_morph(self):
        try:
            nf_morph = self.dict[EPOS]#[NF_MORPH]
            #if not nf_morph: print "WARNING: 'nf_morph' value is empty"
            return nf_morph
        except:
            raise "ERROR: No 'nf_morph' attribute for current event"
        
    def getPolarity(self):
        try:
            polarity = self.dict[POL]
            return polarity
        except:
            #print "WARNING: No 'polarity' attribute for current event"
            return 'POS'

    def getModality(self):
        try:
            modality = self.dict[MOD]
            return modality
        except:
            #print "WARNING: 'modality' value is empty"
            return None

    def getEvClass(self):
        try:
            evClass = self.dict[CLASS]
            #if not evClass: print "WARNING: 'evClass' value is empty"
            return evClass
        except:
            raise "ERROR: No 'evClass' attribute for current event"

    def getPos(self):
        try:
            pos = self.dict[POS]
            return pos
        except:
            raise "ERROR: No 'epos' attribute for current event"
        
#    def getPos_OLD(self):
#        if self.nf_morph in [NOUN, ADJECTIVE]:
#            return self.nf_morph
#        else:
#            return VERB

    def getForm(self):
        try:
            form = self.dict[FORM]
            #if not form: print "WARNING: 'form' value is empty"
            return form
        except:
            raise "ERROR: No 'form' attribute for current event"

    def getStem(self):
        try:
            stem = self.dict[STEM]
        except:
            stem = mLemmatiser.lemmatise_word(self.form, self.pos)
        #if not stem: print "WARNING: 'stem' value is empty"
        return stem

    def printEvent(self):
        log("\neid: "+self.eid)
        log("\neiid: "+self.eiid)
        log("\ntense: "+self.tense)
        log("\naspect: "+self.aspect)
        log("\nepos: "+self.nf_morph) #("nf_morph: "+self.nf_morph)
        log("\npolarity: "+str(self.polarity))
        log("\nmodality: "+str(self.modality))
        log("\nevClass: "+self.evClass)
        log("\npos: "+self.pos)
        log("\nform: "+self.form)
        #log("\nstem: "+self.stem
        log("\nlocInSent: "+str(self.locInSent)) # idx of node bearing event tag in the document, wrt to its sentence parent node.
        log("\neventNum: "+str(self.eventNum))

    def isCandidateToAlinking(self):
        #log("\nEPOS event:"+self.nf_morph)  #DEBUG
        if self.nf_morph == VERB and lower(self.form) in DICTS.alinkVerbsDict.keys():
            return 1
        elif self.nf_morph == NOUN and lower(self.form) in DICTS.alinkNounsDict.keys():
            return 1
        else:
            return 0

    def alinkingContexts(self, key):
        form = lower(self.form)
        if self.nf_morph == VERB:
            return DICTS.alinkVerbsDict[form][key]
        elif self.nf_morph == NOUN:
            return DICTS.alinkNounsDict[form][key]
        else:
            raise "ERROR: ALINKS of type "+str(key)+" for EVENT form "+str(form)+" should be in the dict"
        
        
    def isCandidateToSlinking(self):
        if self.nf_morph == VERB and lower(self.form) in DICTS.slinkVerbsDict.keys():
            return 1
        elif self.nf_morph == NOUN and lower(self.form) in DICTS.slinkNounsDict.keys():
            return 1
        elif self.nf_morph == ADJECTIVE and lower(self.form) in DICTS.slinkAdjsDict.keys():
            return 1
        else:
            return 0

    def slinkingContexts(self, key):
        form = lower(self.form)
        if self.nf_morph == VERB:
            return DICTS.slinkVerbsDict[form][key]
        elif self.nf_morph == NOUN:
            return DICTS.slinkNounsDict[form][key]
        elif self.nf_morph == ADJECTIVE:
            return DICTS.slinkAdjsDict[form][key]
        else:
            raise "ERROR: SLINKS of type "+str(key)+" for EVENT form "+str(form)+" should be in the dict"

    
