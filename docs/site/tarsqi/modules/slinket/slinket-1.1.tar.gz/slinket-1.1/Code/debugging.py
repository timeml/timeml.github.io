

"""==============================

      DEBUGGING UTILITIES

=============================="""


logFlag = 0#1#



def log(inputString):
    if logFlag:
        if inputString[0] == '\n':
            print inputString[1:]
        else:
            print inputString
