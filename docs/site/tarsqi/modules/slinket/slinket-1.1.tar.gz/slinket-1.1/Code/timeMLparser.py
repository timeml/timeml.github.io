#!/usr/bin/python

"""========================================

TimeBank parser


Author: Roser
Last Modified: Apr 14, 2005
========================================"""



import sys, os, xml.parsers.expat
from sys import stdout
from types import *  
from timeMLspec import *
from Tag import *

CurrentDoc = None
parser = None


def readFile(fileName):
    global currentDoc
    global parser

    initializeModification()
    currentDoc = Document(fileName)
    if os.path.exists(fileName):
        file = open(fileName, 'r')
        print "FILE:", fileName
        parser.ParseFile(file)
        file.close()
        return currentDoc
    else:
        print "not a real path", fileName 

def initializeModification():
    global currentDoc
    global parser

    parser = xml.parsers.expat.ParserCreate()
    parser.StartElementHandler = start_element
    parser.EndElementHandler = end_element
    parser.CharacterDataHandler = charData
    parser.XmlDeclHandler = xmlDec
    parserDefaultHandler = default
    currentDoc = None

def start_element(name, attrs):
    #print "NAME:", name, attrs
    currentTag = ''
    if name == EVENT:
        currentTag = EventTag(attrs)
    elif name == INSTANCE:
        currentTag = InstanceTag(attrs)
    elif name == TIMEX:
        currentTag = TimexTag(attrs)
    elif name == SIGNAL:
        currentTag = SignalTag()
    elif name == TLINK:
        currentTag = TlinkTag(attrs)
    elif name == SLINK:
        currentTag = SlinkTag(attrs)
    elif name == ALINK:
        currentTag = AlinkTag(attrs)
        
    if currentTag:
        currentDoc.addDocTag((currentTag, currentDoc.nodeCounter))

    if name in EMPTY_TAGS:
        currentDoc.addDocNode(emptyContentString(name, attrs))
    else:
        currentDoc.addDocNode(startElementString(name, attrs))

def end_element(name):
    #print "NAME END:", name
    if name not in EMPTY_TAGS: currentDoc.addDocNode(endElementString(name))

def charData(string):
    #print "DATA:", string
    currentDoc.addDocNode(string)

def default(string):
    #print "DEFAULT:", string
    currentDoc.addDocNode(string)

def xmlDec(version, encoding, standalone):
    #print "SML:", version, encoding, standalone
    pass


class Document:
    def __init__(self, fileName):
        self.tagList = []      # all TimeML entities (as objects)
        self.nodeList = []     # everything in the doc (as string), to be printed
        self.nodeCounter = 0   # position of each node in source doc
        self.sourceFileWholeName = fileName
        self.sourceFileOnlyName = os.path.basename(fileName)

    def __len__(self):
        return len(self.tagList)

    def __getitem__(self, index):
        return self.tagList[index]

    def __getslice__(self, i, j):
        return tagList[i:j]

    def addDocNode(self, string):
        self.nodeList.append(string)
        self.nodeCounter = self.nodeCounter + 1

    def addDocTag(self, tagTuple):
        self.tagList.append(tagTuple)

    def modifyDocNode(self, idx, string):
        self.nodeList[idx] = string
    
    def printOut(self, fileName = "STDOUT"):
        outFileName = fileName
        if outFileName == "STDOUT":
            file = sys.stdout
        else:
            file = open(outFileName, "w")
            print "...Printing to file:", outFileName

        decString = '<?xml version="1.0" ?>\n'
        file.write(decString)
        for item in self.nodeList:
            if item and type(item) is not IntType:
                file.write(item)

def endElementString(name):
    return '</'+name+'>'

def startElementString(name, attrs):
    string = '<'+name
    for att in attrs.items():
        name = att[0]
        value = att[1]
        if not (name is None or value is None):
            string = string+' '+name+'="'+value+'"'
    string = string+'>'
    return string

def emptyContentString(name, attrs):
    string = '<'+name
    print "\nTAG: "+name
    for att in attrs.items():
        nameAtt = att[0]
        value = att[1]
        print "\tATT: "+att[0]+"\t"+att[1]
        if not (name is None or value is None):
            string =string+' '+nameAtt+'="'+value+'"'
        #else:
        #    print "\nTAG:"+name+"ATT:"+att[0]+"\t"+att[1]
    string = string+'/>' 
    return string


     
class Error(Exception):
    def __init__(self, text):
        self.text = text

    def __str__(self):
        return self.text

