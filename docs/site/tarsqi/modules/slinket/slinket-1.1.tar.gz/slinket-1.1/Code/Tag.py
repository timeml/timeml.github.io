
"""==============================================

         Classes for TimeML tags

Author: Roser
Last Modified: April 14, 2005
==============================================="""

from timeMLspec import *
from Chunk import Constituent
from debugging import log

class EventTag(Constituent):
    def __init__(self, attrs):
        self.name = EVENT
        self.attrs = attrs
        self.eid = attrs[EID]
        self.eClass = attrs[CLASS]
        self.token = None

    def __getattr__(self, name):
        #print "self.parent:", type(self.parent)
        #print "self.parent.parent:", self.parent.parent
        #doc = self.parent.parent.document()
        doc = self.document()
        if name == 'nodeType':
            return self.name
        elif name == 'eventStatus':
            return '1'
        elif name == TENSE:
            #print "TENSE:", doc.taggedEventsDict[self.eid][TENSE]
            return doc.taggedEventsDict[self.eid][TENSE]
        elif name == ASPECT:
            return doc.taggedEventsDict[self.eid][ASPECT]
        elif name == EPOS: #NF_MORPH:
            return doc.taggedEventsDict[self.eid][EPOS]#[NF_MORPH]
        elif name == MOD:
            try: mod = doc.taggedEventsDict[self.eid][MOD]
            except: mod = 'NONE'
            return mod
        elif name == POL:
            try: pol = doc.taggedEventsDict[self.eid][POL]
            except: pol = 'POS'
            return pol
        elif name == EVENTID:
            return doc.taggedEventsDict[self.eid][EVENTID]
        elif name == EIID:
            return doc.taggedEventsDict[self.eid][EIID]
        elif name == CLASS:
            return doc.taggedEventsDict[self.eid][CLASS]
        elif name == 'text' or name == FORM:
            return doc.taggedEventsDict[self.eid][FORM] 
        elif name == STEM:
                    return doc.taggedEventsDict[self.eid][STEM] 
        elif name == POS:
            try:
                return doc.taggedEventsDict[self.eid][POS]
            except:
                # I don't remember whether POS has a particular use here
                # or is a left over from prior times
                log("\nWARNING: Returning 'epos' instead of 'pos' value")  
                return doc.taggedEventsDict[self.eid][EPOS]
        else:
            raise AttributeError, name

    def addTokenInfo(self, token):   
        #log("\nMY CURRENT attrs: "+str(self.attrs))
        self.token = token
        self._addValueToAttr(POS, self.token.pos)
        self._addValueToAttr(FORM, self.token.getText())

    def _addValueToAttr(self, attr, value):
        if not self._isValueAlreadySet(attr):
            self.attrs[attr] = value
        else:
            #log( "\nVALUE already ASSIGNED to event: "+str(self.attrs[POS]))
            pass

    def _isValueAlreadySet(self, att):
        try:
            val = self.attrs[att]
            return 1
        except:
            return 0
        
    def loadValuesIntoEventDict(self):
        #***
        pass

class InstanceTag(Constituent):
    def __init__(self, attrs):
        self.name = INSTANCE
        self.attrs = attrs
        #self.tense = attrs[TENSE]
        #self.aspect = attrs[ASPECT]
        #self.polarity = attrs[POL]
        #self.modality = attrs[MOD]

    def loadValuesIntoEventDict(self):
        #***
        pass
    
class TimexTag(Constituent):
    def __init__(self, attrs):
        self.name = TIMEX
        self.attrs = attrs
        self.nodeList = []
        self.positionCount = 0
        self.isEmbedded = 0
                
    def __getattr__(self, name):
        #print "self.parent:", type(self.parent)
        #print "self.parent.parent:", self.parent.parent
        doc = self.document()#parent.parent.document()
        if name == 'nodeType':
            return self.name
        elif name == 'eventStatus':
            return '0'
        elif name in ['text', FORM, STEM, POS, TENSE, ASPECT, EPOS, MOD, POL, EVENTID, EIID, CLASS]: #NF_MORPH, 
            return None

    def add(self, chunkOrToken):
        chunkOrToken.setParent(self)
        self.nodeList.append(chunkOrToken)
        self.positionCount += 1

    def setParent(self, parent):
        self.parent = parent
        self.position = parent.positionCount

    def getText(self):
        string = ""
        for node in self.nodeList:
            if node.nodeType[-5:] == 'Token':
                string = string+' '+str(node.getText())
                #log("\tPrinting TOKEN "+str(node.getText()))

            elif node.nodeType[-5:] == 'Chunk':
                #log("\tPrinting CHUNK")
                atring = string+' '+str(node.getText())
        return string

    def setEmbedded(self):
        self.isEmbedded = 1

    def resetEmbedded(self):
        self.isEmbedded = 0
    
class SignalTag(Constituent):
    def __init__(self):
        self.name = SIGNAL

class TlinkTag(Constituent):
    def __init__(self, attrs):
        self.name = TLINK
        self.attrs = attrs

class SlinkTag(Constituent):
    def __init__(self, attrs):
        self.name = SLINK
        self.attrs = attrs

class AlinkTag(Constituent):
    def __init__(self, attrs):
        self.name = ALINK
        self.attrs = attrs

class TimeMLTag(Constituent):
    def __init__(self, doc):
        self.setParent(doc)
        print "TimeML tag LOC:", self.position
