import sys
from timeMLspec import *
from debugging import log

class Document:
    def __init__(self, fileName):
        self.nodeList = []
        self.sentenceList = []
        self.nodeCounter = 0
        self.sourceFileName = fileName
        self.taggedEventsDict = {} # containing values of each tagged event in input doc
        self.eventDict = {}
        self.signalDict = {}   
        self.instanceCounter = 0
        self.insertDict = {}
        self.addHeader()   
        self.eventCount = 0
        self.alinkCount = 0
        self.slinkCount = 0 
        self.positionCount = 0
        
    def addDocNode(self, string):
        self.nodeList.insert(self.nodeCounter, string)
        self.nodeCounter = self.nodeCounter + 1 

    def addDocLink(self, loc, string):
        """Same as addDocNode, but here adding nodes
        that are not in the input text, but added
        from some postprocess; e.g., by SLINKET"""
        self.nodeList.insert(loc, string)
        self.nodeCounter = self.nodeCounter + 1
        
        
    def addSentence(self, sentence):
        sentence.setParent(self)
        self.sentenceList.append(sentence)
        self.positionCount += 1

    def addTimex(self, timex):
        timex.setParent(self)
        self.positionCount += 1
    
    def hasAttributeValue(self, eid, att):
        try:
            dictVal = self.taggedEventsDict[eid][att]
            if dictVal:
                return 1
            else:
                return 0
        except:
            return 0

    def storeEventValues(self, pairs):
        #print "PAIRS:", pairs
        try: eid = pairs[EID]
        except: eid = pairs[EVENTID]
        try:
            eventInfo = self.taggedEventsDict[eid]
            """ There is already info for that event.
            Therefore, tag is an INSTANCE tag or STRING data"""
            #print "Presumably an INSTANCE tag or STRING data"
            for att in pairs.keys():
                if att == EID: pass
                # Added this if-line to store pos internally as epos,
                # to avoid confusion with the lex.pos attribute. This
                # does not impact the string that is stored. It is a
                # bit hackish.
                self.taggedEventsDict[eid][att] = pairs[att]
        except:
            """ tag is an EVENT tag"""
            #print "Presumably an EVENT tag"
            for att in pairs.keys():
                evInfo = {}
                if att == EID: pass
                else: evInfo[att] = pairs[att]
                self.taggedEventsDict[eid] = evInfo

    
    def __len__(self):
        return len(self.sentenceList)
        
    def __getitem__(self, index):
        return self.sentenceList[index]
        
    def __getslice__(self, i, j):
        return sentenceList[i:j]

    def document(self):
        return self

#    def setEndDocLoc(self): #, lengthAddedTag):
#        """Set up the position of </TimeML> tag,
#        after A- or SLINKs are added"""
#        self.endDocLoc = self.endDocLoc + 1 #lengthAddedTag
    
    def addEvent(self, event):
        event.attrs["eid"] = self.getNextEventID()
        startLoc = event.tokenList[0].text - 1
        endLoc = event.tokenList[-1].text + 2
        self.insertNode(startLoc, startElementString("EVENT", event.attrs))
        self.insertNode(endLoc, endElementString("EVENT"))
        instLoc = endLoc
        for instance in event.instanceList:
            instance.attrs["eiid"] = self.getNextInstanceID()
            instance.attrs["eventID"] = event.attrs["eid"]
            instLoc = instLoc + 1
            self.insertNode(instLoc, emptyContentString("MAKEINSTANCE", instance.attrs))
            
    def addLink(self, linkAttrs, linkType):
        linkAttrs['lid'] = self.getNextLinkID(linkType)
        self.addDocNode(emptyContentString(linkType, linkAttrs))
        self.addDocNode("\n")
#        self.addSyntax(lid, patternName)      # Creates the SYNTAX tag that corresponds to this slink
    
    def addSlink(self, relType, slinkingEid, slinkedEid, patternName):
        lid = self.getNextSlinkID()
        slinkAttrs = {'eventInstanceID': slinkingEid,
                      'subordinatedEventInstance': slinkedEid,
                      'relType': relType, 'lid': lid, 'syntax': patternName}
        self.addDocNode(emptyContentString("SLINK", slinkAttrs))
        self.addDocNode("\n")
#        self.addSyntax(lid, patternName)      # Creates the SYNTAX tag that corresponds to this slink
    
#    def addSyntax(self, linkID, syntaxName): 
#        syntaxAttrs = {'linkID': linkID, 'syntaxPattern': syntaxName}
#        self.addDocNode(emptyContentString("SYNTAX", syntaxAttrs))
#        self.addDocNode("\n")
        #print "SYNTAX ", linkID, "+", syntaxName

    def getNextEventID(self):
        self.eventCount = self.eventCount + 1
        return "e"+str(self.eventCount) 
        
    def getNextInstanceID(self):
        self.instanceCounter = self.instanceCounter + 1 
        return "ei"+str(self.instanceCounter)

    def getNextLinkID(self, linkType):
        if linkType == "ALINK":
            return self.getNextAlinkID()
        elif linkType == "SLINK":
            return self.getNextSlinkID()
        else:
            raise "ERROR specifying link type"
        
    def getNextAlinkID(self):
        self.alinkCount = self.alinkCount + 1
        return "l"+str(self.alinkCount)
    
    def getNextSlinkID(self):
        self.slinkCount = self.slinkCount + 1
        return "l"+str(self.slinkCount)

    def insertNode(self, nodeNo, string):
        if self.insertDict.has_key(nodeNo):
            raise Error("already have tag for node: "+str(nodeNo))
        else:
            self.insertDict[nodeNo] = string
    
    def insertEventsInText(self): 
        for event in self.eventDict.values():
            startLoc = event.tokenList[0].text - 1
            endLoc = event.tokenList[-1].text + 2
            self.insertNode(startLoc, startElementString("EVENT", event.attrs))
            self.insertNode(endLoc, endElementString("EVENT"))
            instLoc = endLoc
            for instance in event.instanceList:
                instLoc = instLoc + 1 
                self.insertNode(instLoc, emptyContentString("MAKEINSTANCE", instance.attrs))
                
        
    def insertSignalsInText(self):                               
        for signal in self.signalDict.values():                  
            startLoc = signal.tokenList[0].text - 1              
            endLoc = signal.tokenList[-1].text + 2               
            self.insertNode(startLoc, startElementString("SIGNAL", signal.attrs))  
            self.insertNode(endLoc, endElementString("SIGNAL"))  
            instLoc = endLoc                                     
    
    
    def addHeader(self):
        decString = '<?xml version="1.0" ?>\n'
        self.addDocNode(decString)
        rootDict = {
            'xmlns:xsi': 'http://www.w3.org/2001/XMLSchema-instance', 
            'xsi:noNamespaceSchemaLocation': 'http://www.timeml.org/timeMLdocs/TimeML.xsd'
            }
        rootStart= startElementString('TimeML', rootDict)
        self.addDocNode(rootStart)
        self.addDocNode("\n")
    
    def printOut(self, fileName = "STDOUT"):
        outFileName = fileName
        if outFileName == "STDOUT":
            file = sys.stdout
        else:
            file = open(outFileName, "w")
        rootEnd = endElementString("TimeML")

        for i in range(len(self.nodeList)):
            if self.insertDict.has_key(i):
                file.write(self.insertDict[i])
            token = self.nodeList[i]
            if  token[0:5] == '<?xml':
                file.write(token)
            else:
                # The XML parser replaces &amp; etc with the one-character
                # equivalents, which means that the result is not XML.
                # Protect &, < and >. A hack.
                if token[0] != '<' or token[-1] != '>':
                    token = token.replace('&','&amp;')
                    token = token.replace('<','&lt;')
                    token = token.replace('>','&gt;')
                file.write(token)

        # Need to write TimeML tags for slinket because slinks are
        # added to end. This is a mess and document printing for evita
        # and slinket needs to be revisisted.
        file.write("\n"+rootEnd)
        self.insertDict = {}


def endElementString(name):
    return '</'+name+'>'

def startElementString(name, attrs):
    string = '<'+name
    for att in attrs.items():
        name = att[0]
        value = att[1]
        if not (name is None or value is None):
            string = string+' '+name+'="'+value+'"'
    string = string+'>'
    return string

def emptyContentString(name, attrs):
    string = '<'+name
    log("\nTAG: "+name)
    for att in attrs.items():
        nameAtt = att[0]
        value = att[1]
        log("\n\tATT: "+str(att[0])+"\t"+str(att[1]))
        if not (name is None or value is None):
            string =string+' '+nameAtt+'="'+value+'"'
    string = string+'/>' 
    return string

