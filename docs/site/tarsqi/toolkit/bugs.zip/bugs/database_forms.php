<?php

$status_choices = array('open', 'fixed', 'workaround', 're-opened');

$bugtypes = array('error', 'feature_request', 'coverage', 'redesign', 'other');

$components = array('unknown', 'gui', 'preprocessing', 'gutime', 'evita', 'slinket', 's2t', 'blinker', 
		'classifier', 'arglinker', 'docmodel', 'utilities', 'other');

?>